# Momentum — Personal Habit Tracker for Two

Momentum is a private two-person habit tracker with daily rituals, streaks,
weekly progress, a consistency heatmap, a Wallet money ledger, and an Ascend
XP / level / quest system.

## Storage

The app persists everything in **PostgreSQL through Drizzle ORM** — no external
service, no API keys, no Supabase project required.

| Table | Purpose |
| --- | --- |
| `profiles` | The two account seats (name, color, email, password hash) |
| `sessions` | HttpOnly cookie sessions |
| `habits` | Each owner's rituals |
| `habit_logs` | Completion / skip history (streak source data) |
| `wallet_txns` | Income & expense ledger |
| `xp_events` | Immutable, idempotent XP ledger |
| `progress_state` | Cached total XP + level |
| `quest_claims`, `achievements` | Claim history derived from XP keys |

## Configuration

Only one environment variable is needed:

```
DATABASE_URL=postgresql://user:password@host:5432/database
```

Apply the schema with:

```bash
npx drizzle-kit push
```

## Accounts

- The tracker is capped at **exactly two accounts**; the third signup is rejected.
- Create them at `/create-account` (name, email, password, color).
- Passwords are stored only as salted **scrypt** hashes and are never logged.
- Sessions are HttpOnly, SameSite=Lax cookies that live for 60 days.
- Each owner can only read/write their own habits, logs and wallet rows. The
  partner view is a controlled, read-only consistency + XP snapshot.

## Commands

```bash
npm run dev      # local development
npm run build    # production build
npm run start    # production server
npm run lint     # eslint
npm run typecheck
```

## Health

`GET /api/health` returns `{ "ok": true, "storage": "postgres" }` when the app
can reach the database.
