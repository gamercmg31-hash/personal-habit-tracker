import { NextResponse } from "next/server";
import { MAX_ACCOUNTS } from "@/lib/accounts";
import { createAccount, listAccounts } from "@/lib/server/accounts";

export const dynamic = "force-dynamic";

/** Public names/colors for the two-seat picker; emails are never returned. */
export async function GET() {
  try {
    const accounts = await listAccounts();
    return NextResponse.json({
      accounts,
      slotsOpen: Math.max(0, MAX_ACCOUNTS - accounts.length),
      maxAccounts: MAX_ACCOUNTS,
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "The database is unavailable." },
      { status: 503 }
    );
  }
}

/** Create one of exactly two accounts. */
export async function POST(req: Request) {
  let body: { name?: string; email?: string; password?: string; color?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Bad request." }, { status: 400 });
  }
  const result = await createAccount({
    name: typeof body.name === "string" ? body.name : "",
    email: typeof body.email === "string" ? body.email : "",
    password: typeof body.password === "string" ? body.password : "",
    color: typeof body.color === "string" ? body.color : undefined,
  });
  if (!result.ok) {
    return NextResponse.json({ ok: false, error: result.error }, { status: result.status });
  }
  return NextResponse.json(
    {
      ok: true,
      user: result.user,
      requiresConfirmation: result.requiresConfirmation,
    },
    { status: 201 }
  );
}
