import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import {
  getSessionContext,
  hashPassword,
  verifyPassword,
} from "@/lib/server/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const session = await getSessionContext();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = (await req.json().catch(() => null)) as {
    currentPassword?: string;
    newPassword?: string;
  } | null;
  const currentPassword =
    typeof body?.currentPassword === "string" ? body.currentPassword : "";
  const newPassword = typeof body?.newPassword === "string" ? body.newPassword : "";

  if (newPassword.length < 6 || newPassword.length > 100) {
    return NextResponse.json(
      { ok: false, error: "New password must be 6–100 characters." },
      { status: 400 }
    );
  }
  if (!(await verifyPassword(currentPassword, session.passwordHash))) {
    return NextResponse.json(
      { ok: false, error: "Current password is wrong." },
      { status: 401 }
    );
  }

  await db
    .update(profiles)
    .set({ passwordHash: await hashPassword(newPassword), updatedAt: new Date() })
    .where(eq(profiles.userId, session.user.id));
  return NextResponse.json({ ok: true });
}
