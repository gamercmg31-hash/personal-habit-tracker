import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { createSession, verifyPassword } from "@/lib/server/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as {
    email?: string;
    password?: string;
    selectedUserId?: string;
  } | null;
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  if (!email || !password) {
    return NextResponse.json(
      { ok: false, error: "Email and password are required." },
      { status: 400 }
    );
  }

  try {
    const rows = await db
      .select()
      .from(profiles)
      .where(eq(profiles.email, email))
      .limit(1);
    const row = rows[0];
    if (!row || !(await verifyPassword(password, row.passwordHash))) {
      return NextResponse.json(
        { ok: false, error: "Wrong email or password." },
        { status: 401 }
      );
    }

    // When a tile was selected, prevent accidentally entering the other account.
    if (body?.selectedUserId && row.userId !== body.selectedUserId) {
      return NextResponse.json(
        { ok: false, error: "That email belongs to the other Momentum account." },
        { status: 401 }
      );
    }

    await createSession(row.userId);
    return NextResponse.json({
      ok: true,
      user: { id: row.userId, key: row.userId, name: row.name, color: row.color },
    });
  } catch {
    return NextResponse.json(
      { ok: false, error: "The database is unavailable. Try again in a moment." },
      { status: 503 }
    );
  }
}
