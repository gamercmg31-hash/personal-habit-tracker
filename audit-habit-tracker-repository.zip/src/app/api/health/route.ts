import { sql } from "drizzle-orm";
import { db } from "@/db";

export const dynamic = "force-dynamic";

/** Health verifies the app can reach its PostgreSQL database. */
export async function GET() {
  try {
    await db.execute(sql`select 1`);
    return Response.json({ ok: true, storage: "postgres" });
  } catch {
    return Response.json({ ok: false, storage: "postgres" }, { status: 503 });
  }
}
