import type { Metadata } from "next";
import CreateAccountScreen from "@/components/create-account-screen";

export const metadata: Metadata = {
  title: "Create your account — Momentum",
  description:
    "Claim one of the two seats in this private habit tracker. Once both accounts exist, creation closes forever.",
};

export default function CreateAccountPage() {
  return <CreateAccountScreen />;
}
