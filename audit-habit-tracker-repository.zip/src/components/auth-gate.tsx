"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Check } from "lucide-react";
import type { AccountUser, AccountsState } from "@/lib/accounts";
import { apiWithWakeRetry } from "@/lib/api";
import LoginScreen from "@/components/login-screen";
import DatabaseSetupNotice from "@/components/database-setup-notice";

/** Load the two public profile tiles, or show the one-time schema setup gate. */
export default function AuthGate({
  onSuccess,
}: {
  onSuccess: (user: AccountUser) => void;
}) {
  const [state, setState] = useState<AccountsState | null>(null);
  const [setupError, setSetupError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    apiWithWakeRetry<AccountsState>("/api/accounts")
      .then((res) => {
        if (alive) setState(res);
      })
      .catch((error) => {
        if (alive) {
          setSetupError(
            error instanceof Error ? error.message : "The database is unavailable."
          );
        }
      });
    return () => {
      alive = false;
    };
  }, []);

  if (setupError) return <DatabaseSetupNotice message={setupError} />;

  if (!state) {
    return (
      <main className="grid min-h-screen place-items-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="grid size-12 place-items-center rounded-2xl bg-lime-400 text-lime-950 shadow-[0_0_40px_rgba(163,230,53,0.35)]"
          aria-hidden
        >
          <Check size={26} strokeWidth={3.2} />
        </motion.div>
      </main>
    );
  }

  return (
    <LoginScreen
      users={state.accounts}
      slotsOpen={state.slotsOpen}
      onSuccess={onSuccess}
    />
  );
}
