"use client";

import { motion } from "framer-motion";
import { Database, RefreshCw, ShieldCheck } from "lucide-react";

/**
 * Shown when the PostgreSQL-backed API cannot be reached. Momentum keeps every
 * habit, wallet and XP record in the database, so this is the only blocking
 * failure the sign-in flow can hit.
 */
export default function DatabaseSetupNotice({ message }: { message?: string }) {
  return (
    <main className="relative grid min-h-screen place-items-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        className="w-full max-w-md rounded-3xl border border-white/[0.08] bg-white/[0.03] p-7 text-center backdrop-blur"
      >
        <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-amber-400/15 text-amber-300">
          <Database size={25} />
        </div>
        <p className="mt-4 text-[10px] font-bold tracking-[0.2em] text-amber-400 uppercase">
          Database unreachable
        </p>
        <h1 className="font-display mt-1.5 text-2xl font-semibold tracking-tight text-white">
          Momentum can&rsquo;t reach storage
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-zinc-500">
          The app is running, but the PostgreSQL database did not answer. This is
          usually temporary while the server wakes up.
        </p>

        {message ? (
          <p className="mt-4 rounded-2xl border border-white/[0.06] bg-black/30 p-3 text-left text-xs leading-relaxed text-zinc-400">
            {message}
          </p>
        ) : null}

        <button
          type="button"
          onClick={() => window.location.reload()}
          className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-lime-400 px-4 py-3 text-sm font-semibold text-lime-950 transition hover:bg-lime-300"
        >
          <RefreshCw size={16} />
          Try again
        </button>

        <p className="mt-5 flex items-center justify-center gap-1.5 text-[11px] text-zinc-600">
          <ShieldCheck size={13} />
          Your data stays private to the two accounts.
        </p>
      </motion.div>
    </main>
  );
}
