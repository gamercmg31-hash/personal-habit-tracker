import {
  bigint,
  boolean,
  index,
  integer,
  jsonb,
  numeric,
  pgTable,
  primaryKey,
  serial,
  smallint,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/* ---- accounts (exactly two seats) ---------------------------------------- */

export const profiles = pgTable("profiles", {
  userId: text("user_id").primaryKey(),
  slot: smallint("slot").notNull().unique(),
  name: text("name").notNull(),
  nameKey: text("name_key").notNull().unique(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  color: text("color").notNull(),
  seeded: boolean("seeded").notNull().default(false),
  settings: jsonb("settings").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable(
  "sessions",
  {
    token: text("token").primaryKey(),
    userId: text("user_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (table) => [index("sessions_user_idx").on(table.userId)]
);

/* ---- habits + history ----------------------------------------------------- */

export const habits = pgTable(
  "habits",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    name: text("name").notNull(),
    icon: text("icon").notNull(),
    color: text("color").notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
    createdKey: text("created_key").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("habits_user_idx").on(table.userId)]
);

export const habitLogs = pgTable(
  "habit_logs",
  {
    userId: text("user_id").notNull(),
    habitId: integer("habit_id").notNull(),
    date: text("date").notNull(),
    status: text("status").notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    primaryKey({ columns: [table.userId, table.habitId, table.date] }),
    index("habit_logs_user_date_idx").on(table.userId, table.date),
  ]
);

/* ---- wallet ---------------------------------------------------------------- */

export const walletTxns = pgTable(
  "wallet_txns",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull(),
    name: text("name").notNull(),
    category: text("category").notNull(),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
    type: text("type").notNull(),
    date: text("date").notNull(),
    createdAt: bigint("created_at", { mode: "number" }).notNull(),
  },
  (table) => [index("wallet_user_idx").on(table.userId)]
);

/* ---- XP / levels ------------------------------------------------------------ */

export const xpEvents = pgTable(
  "xp_events",
  {
    userId: text("user_id").notNull(),
    key: text("key").notNull(),
    label: text("label").notNull(),
    amount: integer("amount").notNull(),
    day: text("day").notNull(),
    atMs: bigint("at_ms", { mode: "number" }).notNull(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.key] })]
);

export const progressState = pgTable("progress_state", {
  userId: text("user_id").primaryKey(),
  totalXp: bigint("total_xp", { mode: "number" }).notNull().default(0),
  level: integer("level").notNull().default(1),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const questClaims = pgTable(
  "quest_claims",
  {
    userId: text("user_id").notNull(),
    eventKey: text("event_key").notNull(),
    questId: text("quest_id").notNull(),
    periodKey: text("period_key").notNull(),
    xpAwarded: integer("xp_awarded").notNull(),
    claimedAt: bigint("claimed_at", { mode: "number" }).notNull(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.eventKey] })]
);

export const achievements = pgTable(
  "achievements",
  {
    userId: text("user_id").notNull(),
    achievementId: text("achievement_id").notNull(),
    unlockedAt: bigint("unlocked_at", { mode: "number" }).notNull(),
    metadata: jsonb("metadata").notNull().default({}),
  },
  (table) => [primaryKey({ columns: [table.userId, table.achievementId] })]
);
