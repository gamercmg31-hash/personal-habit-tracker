// Server-only account registry (PostgreSQL). Passwords are stored as salted
// scrypt hashes — never in plain text, never logged.

import { asc, eq, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import {
  ACCOUNT_COLORS,
  MAX_ACCOUNTS,
  nameKey,
  type AccountUser,
} from "@/lib/accounts";
import { createSession, hashPassword, newUserId } from "@/lib/server/session";

function toUser(row: {
  userId: string;
  name: string;
  color: string;
}): AccountUser {
  return { id: row.userId, key: row.userId, name: row.name, color: row.color };
}

/** Public pre-login list: names, colors and ids only — emails stay private. */
export async function listAccounts(): Promise<AccountUser[]> {
  const rows = await db
    .select({ userId: profiles.userId, name: profiles.name, color: profiles.color })
    .from(profiles)
    .orderBy(asc(profiles.slot));
  return rows.map(toUser);
}

export async function accountById(userId: string): Promise<AccountUser | null> {
  const rows = await db
    .select({ userId: profiles.userId, name: profiles.name, color: profiles.color })
    .from(profiles)
    .where(eq(profiles.userId, userId))
    .limit(1);
  return rows[0] ? toUser(rows[0]) : null;
}

export async function partnerOf(userId: string): Promise<AccountUser | null> {
  const rows = await db
    .select({ userId: profiles.userId, name: profiles.name, color: profiles.color })
    .from(profiles)
    .where(ne(profiles.userId, userId))
    .limit(1);
  return rows[0] ? toUser(rows[0]) : null;
}

export type CreateAccountResult =
  | { ok: true; user: AccountUser; requiresConfirmation: boolean }
  | { ok: false; status: number; error: string };

/** Create one of exactly two accounts and sign the new owner straight in. */
export async function createAccount(input: {
  name: string;
  email: string;
  password: string;
  color?: string;
}): Promise<CreateAccountResult> {
  const name = input.name.trim().replace(/\s+/g, " ");
  const email = input.email.trim().toLowerCase();
  if (name.length < 2 || name.length > 24) {
    return { ok: false, status: 400, error: "Name must be 2–24 characters." };
  }
  if (!/^\S+@\S+\.\S+$/.test(email) || email.length > 254) {
    return { ok: false, status: 400, error: "Enter a valid email address." };
  }
  if (input.password.length < 6 || input.password.length > 100) {
    return { ok: false, status: 400, error: "Password must be 6–100 characters." };
  }

  const existing = await listAccounts();
  if (existing.length >= MAX_ACCOUNTS) {
    return {
      ok: false,
      status: 409,
      error: "Both accounts already exist — this tracker is full.",
    };
  }
  if (existing.some((user) => user.name.toLowerCase() === name.toLowerCase())) {
    return {
      ok: false,
      status: 409,
      error: `“${name}” is already taken — the two accounts can't share a name.`,
    };
  }

  const slot = existing.length + 1;
  const color =
    input.color && /^#[0-9a-fA-F]{6}$/.test(input.color)
      ? input.color.toLowerCase()
      : ACCOUNT_COLORS[slot - 1] ?? ACCOUNT_COLORS[0];
  const userId = newUserId();

  try {
    // A conditional insert keeps the two-seat cap atomic even when both owners
    // sign up at the same instant.
    const inserted = await db
      .insert(profiles)
      .values({
        userId,
        slot,
        name,
        nameKey: nameKey(name),
        email,
        passwordHash: await hashPassword(input.password),
        color,
      })
      .onConflictDoNothing()
      .returning({
        userId: profiles.userId,
        name: profiles.name,
        color: profiles.color,
      });

    const row = inserted[0];
    if (!row) {
      return {
        ok: false,
        status: 409,
        error: "That seat was just taken — reload and try again.",
      };
    }

    // Guard against a rare race creating a third row.
    const countRows = await db
      .select({ total: sql<number>`count(*)::int` })
      .from(profiles);
    if ((countRows[0]?.total ?? 0) > MAX_ACCOUNTS) {
      await db.delete(profiles).where(eq(profiles.userId, userId));
      return {
        ok: false,
        status: 409,
        error: "Both accounts already exist — this tracker is full.",
      };
    }

    await createSession(userId);
    return { ok: true, user: toUser(row), requiresConfirmation: false };
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (/profiles_email/.test(message)) {
      return { ok: false, status: 409, error: "That email is already registered." };
    }
    if (/name_key/.test(message)) {
      return { ok: false, status: 409, error: "That name is already taken." };
    }
    if (/slot/.test(message)) {
      return {
        ok: false,
        status: 409,
        error: "Both accounts already exist — this tracker is full.",
      };
    }
    return {
      ok: false,
      status: 500,
      error: "Could not create the account. Please try again.",
    };
  }
}
