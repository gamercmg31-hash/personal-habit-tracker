// Server-only data layer. PostgreSQL (via Drizzle) is the single source of
// truth; every function verifies that the caller owns the rows it touches.

import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  achievements as achievementsTable,
  habitLogs,
  habits as habitsTable,
  profiles,
  progressState,
  questClaims,
  walletTxns,
  xpEvents,
} from "@/db/schema";
import { dateKey } from "@/lib/dates";
import type { HabitRecord, LogRecord, LogStatusValue } from "@/lib/types";
import type { Txn } from "@/lib/wallet";
import { levelInfo, type XpEvent } from "@/lib/xp";
import type { AccountUser } from "@/lib/accounts";
import { getSessionContext } from "@/lib/server/session";
import { partnerOf } from "@/lib/server/accounts";

async function assertOwner(userId: string): Promise<void> {
  const ctx = await getSessionContext();
  if (!ctx || ctx.user.id !== userId) throw new Error("Unauthorized");
}

async function assertSignedIn(): Promise<AccountUser> {
  const ctx = await getSessionContext();
  if (!ctx) throw new Error("Unauthorized");
  return ctx.user;
}

/* ---- row mappers ----------------------------------------------------------- */

type HabitRow = typeof habitsTable.$inferSelect;
type LogRow = typeof habitLogs.$inferSelect;
type TxnRow = typeof walletTxns.$inferSelect;
type XpRow = typeof xpEvents.$inferSelect;

function habitRow(row: HabitRow): HabitRecord {
  return {
    id: Number(row.id),
    userId: row.userId,
    name: row.name,
    icon: row.icon,
    color: row.color,
    sortOrder: Number(row.sortOrder),
    createdKey: row.createdKey,
  };
}

function logRow(row: LogRow): LogRecord {
  return {
    userId: row.userId,
    habitId: Number(row.habitId),
    date: row.date,
    status: row.status as LogStatusValue,
  };
}

function txnRow(row: TxnRow): Txn {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    amount: Number(row.amount),
    type: row.type as Txn["type"],
    date: row.date,
    createdAt: Number(row.createdAt),
  };
}

function xpRow(row: XpRow): XpEvent {
  return {
    key: row.key,
    label: row.label,
    amount: Number(row.amount),
    day: row.day,
    at: Number(row.atMs),
  };
}

/* ---- profiles / fresh defaults --------------------------------------------- */

export async function ensureProfile(): Promise<void> {}

// Mirrors DEFAULT_HABITS in src/lib/visuals.tsx (icon + color keys must exist
// there so every seeded ritual renders a real icon).
const DEFAULT_HABITS: { name: string; icon: string; color: string }[] = [
  { name: "Study today", icon: "book-open", color: "violet" },
  { name: "Go to school", icon: "school", color: "sky" },
  { name: "Go to coaching", icon: "graduation-cap", color: "amber" },
  { name: "Eat breakfast", icon: "coffee", color: "orange" },
  { name: "Eat lunch", icon: "utensils-crossed", color: "emerald" },
  { name: "Eat dinner", icon: "soup", color: "rose" },
  { name: "Sleep before 3:00 AM", icon: "moon-star", color: "indigo" },
];

/** Seed the starter rituals exactly once per account. */
export async function ensureSeeded(userId: string): Promise<void> {
  await assertOwner(userId);
  const rows = await db
    .select({ seeded: profiles.seeded })
    .from(profiles)
    .where(eq(profiles.userId, userId))
    .limit(1);
  if (rows[0]?.seeded) return;

  const existing = await db
    .select({ id: habitsTable.id })
    .from(habitsTable)
    .where(eq(habitsTable.userId, userId))
    .limit(1);
  if (!existing.length) {
    const today = dateKey(new Date());
    await db.insert(habitsTable).values(
      DEFAULT_HABITS.map((habit, index) => ({
        userId,
        name: habit.name,
        icon: habit.icon,
        color: habit.color,
        sortOrder: index + 1,
        createdKey: today,
      }))
    );
  }
  await db
    .update(profiles)
    .set({ seeded: true, updatedAt: new Date() })
    .where(eq(profiles.userId, userId));
}

/* ---- habits + logs ---------------------------------------------------------- */

async function readHabits(userId: string): Promise<HabitRecord[]> {
  const rows = await db
    .select()
    .from(habitsTable)
    .where(eq(habitsTable.userId, userId))
    .orderBy(asc(habitsTable.sortOrder), asc(habitsTable.id));
  return rows.map(habitRow);
}

async function readLogs(userId: string): Promise<LogRecord[]> {
  const rows = await db
    .select()
    .from(habitLogs)
    .where(eq(habitLogs.userId, userId))
    .orderBy(asc(habitLogs.date));
  return rows.map(logRow);
}

export async function getHabits(userId: string): Promise<HabitRecord[]> {
  await assertOwner(userId);
  return readHabits(userId);
}

export async function getLogs(userId: string): Promise<LogRecord[]> {
  await assertOwner(userId);
  return readLogs(userId);
}

export async function createHabit(
  userId: string,
  input: { name: string; icon: string; color: string }
): Promise<HabitRecord> {
  await assertOwner(userId);
  const tail = await db
    .select({ sortOrder: habitsTable.sortOrder })
    .from(habitsTable)
    .where(eq(habitsTable.userId, userId))
    .orderBy(desc(habitsTable.sortOrder))
    .limit(1);
  const sortOrder = Number(tail[0]?.sortOrder ?? 0) + 1;
  const inserted = await db
    .insert(habitsTable)
    .values({
      userId,
      name: input.name,
      icon: input.icon,
      color: input.color,
      sortOrder,
      createdKey: dateKey(new Date()),
    })
    .returning();
  return habitRow(inserted[0]);
}

export async function updateHabit(
  userId: string,
  habitId: number,
  patch: { name?: string; icon?: string; color?: string }
): Promise<void> {
  await assertOwner(userId);
  if (!Object.keys(patch).length) return;
  await db
    .update(habitsTable)
    .set(patch)
    .where(and(eq(habitsTable.userId, userId), eq(habitsTable.id, habitId)));
}

export async function deleteHabit(userId: string, habitId: number): Promise<void> {
  await assertOwner(userId);
  await db
    .delete(habitLogs)
    .where(and(eq(habitLogs.userId, userId), eq(habitLogs.habitId, habitId)));
  await db
    .delete(habitsTable)
    .where(and(eq(habitsTable.userId, userId), eq(habitsTable.id, habitId)));
}

export async function setLog(
  userId: string,
  habitId: number,
  date: string,
  status: LogStatusValue | null
): Promise<void> {
  await assertOwner(userId);
  const owns = await db
    .select({ id: habitsTable.id })
    .from(habitsTable)
    .where(and(eq(habitsTable.userId, userId), eq(habitsTable.id, habitId)))
    .limit(1);
  if (!owns.length) return;

  if (status === null) {
    await db
      .delete(habitLogs)
      .where(
        and(
          eq(habitLogs.userId, userId),
          eq(habitLogs.habitId, habitId),
          eq(habitLogs.date, date)
        )
      );
    return;
  }
  await db
    .insert(habitLogs)
    .values({ userId, habitId, date, status, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: [habitLogs.userId, habitLogs.habitId, habitLogs.date],
      set: { status, updatedAt: new Date() },
    });
}

/* ---- wallet ---------------------------------------------------------------- */

export async function getTxns(userId: string): Promise<Txn[]> {
  await assertOwner(userId);
  const rows = await db
    .select()
    .from(walletTxns)
    .where(eq(walletTxns.userId, userId))
    .orderBy(desc(walletTxns.createdAt));
  return rows.map(txnRow);
}

export async function createTxn(userId: string, txn: Txn): Promise<Txn> {
  await assertOwner(userId);
  const values = {
    id: txn.id,
    userId,
    name: txn.name,
    category: txn.category,
    amount: txn.amount.toFixed(2),
    type: txn.type,
    date: txn.date,
    createdAt: txn.createdAt,
  };
  const inserted = await db
    .insert(walletTxns)
    .values(values)
    .onConflictDoUpdate({
      target: walletTxns.id,
      set: {
        name: values.name,
        category: values.category,
        amount: values.amount,
        type: values.type,
        date: values.date,
      },
    })
    .returning();
  return txnRow(inserted[0]);
}

export async function updateTxn(
  userId: string,
  id: string,
  patch: Partial<Omit<Txn, "id" | "createdAt">>
): Promise<void> {
  await assertOwner(userId);
  const set: Record<string, unknown> = {};
  if (patch.name !== undefined) set.name = patch.name;
  if (patch.category !== undefined) set.category = patch.category;
  if (patch.amount !== undefined) set.amount = patch.amount.toFixed(2);
  if (patch.type !== undefined) set.type = patch.type;
  if (patch.date !== undefined) set.date = patch.date;
  if (!Object.keys(set).length) return;
  await db
    .update(walletTxns)
    .set(set)
    .where(and(eq(walletTxns.userId, userId), eq(walletTxns.id, id)));
}

export async function deleteTxn(userId: string, id: string): Promise<void> {
  await assertOwner(userId);
  await db
    .delete(walletTxns)
    .where(and(eq(walletTxns.userId, userId), eq(walletTxns.id, id)));
}

/* ---- XP, levels, quests, achievements -------------------------------------- */

async function readXpEvents(userId: string): Promise<XpEvent[]> {
  const rows = await db
    .select()
    .from(xpEvents)
    .where(eq(xpEvents.userId, userId))
    .orderBy(asc(xpEvents.atMs));
  return rows.map(xpRow);
}

export async function getXpEvents(userId: string): Promise<XpEvent[]> {
  // Both owners may read either XP ledger — the tracker is shared by design.
  await assertSignedIn();
  return readXpEvents(userId);
}

export interface ServerGrant {
  key: string;
  label: string;
  amount: number;
}

async function syncProgress(userId: string): Promise<number> {
  const rows = await db
    .select({ total: sql<number>`coalesce(sum(${xpEvents.amount}), 0)::int` })
    .from(xpEvents)
    .where(eq(xpEvents.userId, userId));
  const totalXp = Number(rows[0]?.total ?? 0);
  const level = levelInfo(totalXp).level;
  await db
    .insert(progressState)
    .values({ userId, totalXp, level, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: progressState.userId,
      set: { totalXp, level, updatedAt: new Date() },
    });
  return totalXp;
}

/** Idempotent XP grants: a key is only ever awarded once per user. */
export async function grantXp(
  userId: string,
  grants: ServerGrant[],
  day: string,
  nowMs: number
): Promise<{ gained: XpEvent[]; totalXp: number }> {
  await assertOwner(userId);
  const clean = grants
    .filter(
      (grant) =>
        grant &&
        typeof grant.key === "string" &&
        grant.key.length > 0 &&
        grant.key.length <= 200 &&
        typeof grant.label === "string" &&
        Number.isFinite(grant.amount)
    )
    .map((grant) => ({
      userId,
      key: grant.key.slice(0, 200),
      label: String(grant.label).slice(0, 200),
      amount: Math.max(-100000, Math.min(100000, Math.trunc(grant.amount))),
      day,
      atMs: nowMs,
    }));

  let gained: XpEvent[] = [];
  if (clean.length) {
    const inserted = await db
      .insert(xpEvents)
      .values(clean)
      .onConflictDoNothing({ target: [xpEvents.userId, xpEvents.key] })
      .returning();
    gained = inserted.map(xpRow);

    // Mirror quest claims + achievements derived from the granted keys.
    const questRows = gained
      .filter((event) => event.key.startsWith("quest:"))
      .map((event) => {
        const parts = event.key.split(":");
        return {
          userId,
          eventKey: event.key,
          questId: parts[1] ?? "quest",
          periodKey: parts.slice(2).join(":") || day,
          xpAwarded: event.amount,
          claimedAt: event.at,
        };
      });
    if (questRows.length) {
      await db
        .insert(questClaims)
        .values(questRows)
        .onConflictDoNothing({ target: [questClaims.userId, questClaims.eventKey] });
    }

    const achievementRows = gained
      .filter(
        (event) =>
          event.key.startsWith("achievement:") || event.key.startsWith("ach:")
      )
      .map((event) => ({
        userId,
        achievementId: event.key.split(":").slice(1).join(":") || event.key,
        unlockedAt: event.at,
        metadata: { label: event.label, amount: event.amount },
      }));
    if (achievementRows.length) {
      await db
        .insert(achievementsTable)
        .values(achievementRows)
        .onConflictDoNothing({
          target: [achievementsTable.userId, achievementsTable.achievementId],
        });
    }
  }

  const totalXp = await syncProgress(userId);
  return { gained, totalXp };
}

async function readProgress(userId: string) {
  const rows = await db
    .select({ totalXp: progressState.totalXp, level: progressState.level })
    .from(progressState)
    .where(eq(progressState.userId, userId))
    .limit(1);
  const row = rows[0];
  if (row) return { totalXp: Number(row.totalXp), level: Number(row.level) };
  const totals = await db
    .select({ total: sql<number>`coalesce(sum(${xpEvents.amount}), 0)::int` })
    .from(xpEvents)
    .where(eq(xpEvents.userId, userId));
  const totalXp = Number(totals[0]?.total ?? 0);
  return { totalXp, level: levelInfo(totalXp).level };
}

export async function getProgressState(userId: string) {
  await assertSignedIn();
  return readProgress(userId);
}

export async function getOwnedProgressDetails(userId: string) {
  await assertOwner(userId);
  const [quests, achievements] = await Promise.all([
    db.select().from(questClaims).where(eq(questClaims.userId, userId)),
    db
      .select()
      .from(achievementsTable)
      .where(eq(achievementsTable.userId, userId)),
  ]);
  return { quests, achievements };
}

/* ---- controlled partner view ---------------------------------------------- */

export interface PartnerDataSnapshot {
  user: AccountUser;
  slice: { seeded: boolean; habits: HabitRecord[]; logs: LogRecord[] };
  xp: { totalXp: number; level?: number; events: XpEvent[] };
}

export async function getPartnerSnapshot(): Promise<PartnerDataSnapshot | null> {
  const me = await assertSignedIn();
  const partner = await partnerOf(me.id);
  if (!partner) return null;
  const [habits, logs, events, progress] = await Promise.all([
    readHabits(partner.id),
    readLogs(partner.id),
    readXpEvents(partner.id),
    readProgress(partner.id),
  ]);
  return {
    user: partner,
    slice: { seeded: true, habits, logs },
    xp: { totalXp: progress.totalXp, level: progress.level, events },
  };
}

/* ---- fresh-start import policy -------------------------------------------- */

export interface ImportPayload {
  habits?: HabitRecord[];
  logs?: LogRecord[];
  txns?: Txn[];
  xpEvents?: XpEvent[];
}

/** Existing browser data is intentionally not imported into the fresh install. */
export async function importLegacy() {
  return { habits: 0, logs: 0, txns: 0, xpEvents: 0, reset: true };
}

/* ---- backup / restore ------------------------------------------------------ */

export interface BackupDump {
  format: "momentum-backup";
  version: 1;
  exportedAt: string;
  user: { userId: string; name: string; color: string };
  profile: Record<string, unknown> | null;
  habits: HabitRecord[];
  logs: LogRecord[];
  txns: Txn[];
  xpEvents: XpEvent[];
}

export async function exportUser(userId: string): Promise<BackupDump> {
  const ctx = await getSessionContext();
  if (!ctx || ctx.user.id !== userId) throw new Error("Unauthorized");
  const [habits, logs, txns, events] = await Promise.all([
    readHabits(userId),
    readLogs(userId),
    getTxns(userId),
    readXpEvents(userId),
  ]);
  return {
    format: "momentum-backup",
    version: 1,
    exportedAt: new Date().toISOString(),
    user: { userId, name: ctx.user.name, color: ctx.user.color },
    profile: null,
    habits,
    logs,
    txns,
    xpEvents: events,
  };
}

/** Replace only the caller's own rows, inside one transaction. */
export async function restoreUser(userId: string, dump: BackupDump) {
  await assertOwner(userId);

  await db.transaction(async (tx) => {
    await tx.delete(habitLogs).where(eq(habitLogs.userId, userId));
    await tx.delete(walletTxns).where(eq(walletTxns.userId, userId));
    await tx.delete(xpEvents).where(eq(xpEvents.userId, userId));
    await tx.delete(questClaims).where(eq(questClaims.userId, userId));
    await tx
      .delete(achievementsTable)
      .where(eq(achievementsTable.userId, userId));
    await tx.delete(habitsTable).where(eq(habitsTable.userId, userId));

    const habitIds = new Set<number>();
    if (dump.habits.length) {
      const rows = dump.habits.slice(0, 500).map((habit) => {
        const id = Number(habit.id);
        habitIds.add(id);
        return {
          id,
          userId,
          name: String(habit.name).slice(0, 200),
          icon: String(habit.icon).slice(0, 60),
          color: String(habit.color).slice(0, 40),
          sortOrder: Number(habit.sortOrder ?? id) || id,
          createdKey: String(habit.createdKey ?? dateKey(new Date())),
        };
      });
      await tx.insert(habitsTable).values(rows).onConflictDoNothing();
      // Keep the shared sequence ahead of the restored ids.
      await tx.execute(
        sql`select setval(pg_get_serial_sequence('habits', 'id'), greatest((select coalesce(max(id), 1) from habits), 1))`
      );
    }

    const logs = dump.logs
      .slice(0, 20000)
      .filter((log) => habitIds.has(Number(log.habitId)))
      .map((log) => ({
        userId,
        habitId: Number(log.habitId),
        date: String(log.date),
        status: log.status === "skipped" ? "skipped" : "completed",
      }));
    if (logs.length) {
      await tx.insert(habitLogs).values(logs).onConflictDoNothing();
    }

    const txns = dump.txns.slice(0, 20000).map((txn) => ({
      id: String(txn.id),
      userId,
      name: String(txn.name).slice(0, 200),
      category: String(txn.category).slice(0, 60),
      amount: Number(txn.amount || 0).toFixed(2),
      type: txn.type === "income" ? "income" : "expense",
      date: String(txn.date),
      createdAt: Number(txn.createdAt) || Date.now(),
    }));
    if (txns.length) {
      await tx.insert(walletTxns).values(txns).onConflictDoNothing();
    }

    const events = dump.xpEvents.slice(0, 20000).map((event) => ({
      userId,
      key: String(event.key).slice(0, 200),
      label: String(event.label).slice(0, 200),
      amount: Math.trunc(Number(event.amount) || 0),
      day: String(event.day),
      atMs: Number(event.at) || Date.now(),
    }));
    if (events.length) {
      await tx.insert(xpEvents).values(events).onConflictDoNothing();
    }
  });

  await syncProgress(userId);
}

/** Remove every row belonging to the given habit ids (used by tests/tools). */
export async function purgeHabits(userId: string, ids: number[]) {
  await assertOwner(userId);
  if (!ids.length) return;
  await db
    .delete(habitsTable)
    .where(and(eq(habitsTable.userId, userId), inArray(habitsTable.id, ids)));
}
