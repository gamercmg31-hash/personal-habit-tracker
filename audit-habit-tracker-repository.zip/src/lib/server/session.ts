// Server-only session handling backed by PostgreSQL + an HttpOnly cookie.

import { cookies } from "next/headers";
import { randomBytes, randomUUID, scrypt as scryptCb, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { and, eq, gt, lt } from "drizzle-orm";
import { db } from "@/db";
import { profiles, sessions } from "@/db/schema";
import type { AccountUser } from "@/lib/accounts";

const scrypt = promisify(scryptCb) as (
  password: string,
  salt: string,
  keylen: number
) => Promise<Buffer>;

export const SESSION_COOKIE = "momentum_session";
const SESSION_DAYS = 60;

/* ---- password hashing (scrypt, no external dependency) -------------------- */

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = await scrypt(password, salt, 64);
  return `scrypt:${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(
  password: string,
  stored: string
): Promise<boolean> {
  const [scheme, salt, hex] = stored.split(":");
  if (scheme !== "scrypt" || !salt || !hex) return false;
  const derived = await scrypt(password, salt, 64);
  const expected = Buffer.from(hex, "hex");
  if (expected.length !== derived.length) return false;
  return timingSafeEqual(expected, derived);
}

/* ---- session lifecycle ----------------------------------------------------- */

export function newUserId(): string {
  return randomUUID();
}

export async function createSession(userId: string): Promise<void> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86_400_000);
  await db.insert(sessions).values({ token, userId, expiresAt });
  // Opportunistic cleanup of expired rows.
  await db.delete(sessions).where(lt(sessions.expiresAt, new Date()));
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_DAYS * 86_400,
  });
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.token, token));
  store.set(SESSION_COOKIE, "", { path: "/", maxAge: 0 });
}

export interface SessionContext {
  user: AccountUser;
  email: string;
  passwordHash: string;
}

export async function getSessionContext(): Promise<SessionContext | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({
      userId: profiles.userId,
      name: profiles.name,
      color: profiles.color,
      email: profiles.email,
      passwordHash: profiles.passwordHash,
    })
    .from(sessions)
    .innerJoin(profiles, eq(profiles.userId, sessions.userId))
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
    .limit(1);
  const row = rows[0];
  if (!row) return null;
  return {
    user: { id: row.userId, key: row.userId, name: row.name, color: row.color },
    email: row.email,
    passwordHash: row.passwordHash,
  };
}

export async function getSessionUser(): Promise<AccountUser | null> {
  return (await getSessionContext())?.user ?? null;
}

export async function requireUserId(userId: string): Promise<void> {
  const ctx = await getSessionContext();
  if (!ctx || ctx.user.id !== userId) throw new Error("Unauthorized");
}
