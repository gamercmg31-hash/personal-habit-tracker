import { getSupabaseAnon } from "@/lib/supabase/server";
import {
  SUPABASE_URL,
  isMissingSchemaError,
  isSupabaseConfigured,
} from "@/lib/supabase/config";

export const dynamic = "force-dynamic";

/** Health verifies the app can reach its Supabase project. */
export async function GET() {
  if (!isSupabaseConfigured()) {
    return Response.json(
      {
        ok: false,
        storage: "supabase",
        error:
          "Missing NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY.",
      },
      { status: 503 }
    );
  }

  const project = SUPABASE_URL.replace(/^https?:\/\//, "").split(".")[0];

  try {
    const { error } = await getSupabaseAnon()
      .from("public_profiles")
      .select("id")
      .limit(1);

    if (error && isMissingSchemaError(error)) {
      // Reachable, but supabase/schema.sql has not been applied yet.
      return Response.json({
        ok: true,
        storage: "supabase",
        project,
        schema: "missing",
        setupUrl: "/api/setup",
      });
    }
    if (error) {
      return Response.json(
        { ok: false, storage: "supabase", project, error: error.message },
        { status: 503 }
      );
    }
    return Response.json({
      ok: true,
      storage: "supabase",
      project,
      schema: "ready",
    });
  } catch (error) {
    return Response.json(
      {
        ok: false,
        storage: "supabase",
        project,
        error: error instanceof Error ? error.message : "unreachable",
      },
      { status: 503 }
    );
  }
}
