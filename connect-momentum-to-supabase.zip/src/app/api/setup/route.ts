import { NextResponse } from "next/server";
import { getSupabaseAnon } from "@/lib/supabase/server";
import {
  SUPABASE_URL,
  isMissingSchemaError,
  isSupabaseConfigured,
} from "@/lib/supabase/config";
import { MOMENTUM_SCHEMA_SQL } from "@/lib/supabase/schema-sql";

export const dynamic = "force-dynamic";

export interface SetupStatus {
  configured: boolean;
  reachable: boolean;
  schemaReady: boolean;
  projectRef: string | null;
  sqlEditorUrl: string | null;
  authProvidersUrl: string | null;
  accounts: number;
  maxAccounts: number;
  sql: string;
  error: string | null;
}

/** Tells the UI whether supabase/schema.sql still has to be applied. */
export async function GET() {
  const projectRef = isSupabaseConfigured()
    ? SUPABASE_URL.replace(/^https?:\/\//, "").split(".")[0]
    : null;

  const base: SetupStatus = {
    configured: isSupabaseConfigured(),
    reachable: false,
    schemaReady: false,
    projectRef,
    sqlEditorUrl: projectRef
      ? `https://supabase.com/dashboard/project/${projectRef}/sql/new`
      : null,
    authProvidersUrl: projectRef
      ? `https://supabase.com/dashboard/project/${projectRef}/auth/providers`
      : null,
    accounts: 0,
    maxAccounts: 2,
    sql: MOMENTUM_SCHEMA_SQL,
    error: null,
  };

  if (!base.configured) {
    return NextResponse.json({
      ...base,
      error:
        "Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY in your environment.",
    });
  }

  try {
    const { data, error } = await getSupabaseAnon()
      .from("public_profiles")
      .select("id");

    if (error) {
      if (isMissingSchemaError(error)) {
        return NextResponse.json({
          ...base,
          reachable: true,
          error:
            "Momentum's tables do not exist in this Supabase project yet. Run the SQL below once.",
        });
      }
      return NextResponse.json({ ...base, reachable: true, error: error.message });
    }

    return NextResponse.json({
      ...base,
      reachable: true,
      schemaReady: true,
      accounts: data?.length ?? 0,
    });
  } catch (error) {
    return NextResponse.json({
      ...base,
      error: error instanceof Error ? error.message : "Supabase is unreachable.",
    });
  }
}
