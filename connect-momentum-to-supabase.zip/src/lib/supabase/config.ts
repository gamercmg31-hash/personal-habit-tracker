// Supabase connection settings.
//
// Credentials are ALWAYS read from environment variables — the project URL and
// the publishable/anon key are never hard-coded anywhere in this repository.
// Only the publishable (anon) key is used; the service-role key is never
// required, never read and never shipped.

export const SUPABASE_URL = (process.env.NEXT_PUBLIC_SUPABASE_URL ?? "").trim();
export const SUPABASE_ANON_KEY = (
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? ""
).trim();

export function isSupabaseConfigured(): boolean {
  return SUPABASE_URL.length > 0 && SUPABASE_ANON_KEY.length > 0;
}

export function assertSupabaseConfigured(): void {
  if (!isSupabaseConfigured()) {
    throw new Error(
      "Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY."
    );
  }
}

/** Every table + view Momentum needs inside the Supabase `public` schema. */
export const REQUIRED_TABLES = [
  "profiles",
  "habits",
  "habit_logs",
  "wallet_txns",
  "xp_events",
  "progress_state",
  "quest_claims",
  "achievements",
  "public_profiles",
  "momentum_partner_progress",
] as const;

export interface PostgrestLikeError {
  code?: string | null;
  message?: string | null;
  details?: string | null;
  hint?: string | null;
}

/** True when PostgREST/Postgres says the Momentum schema has not been applied. */
export function isMissingSchemaError(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  const err = error as PostgrestLikeError;
  const code = err.code ?? "";
  if (code === "PGRST205" || code === "PGRST202" || code === "42P01") return true;
  const message = `${err.message ?? ""}`;
  return (
    /could not find the table/i.test(message) ||
    /schema cache/i.test(message) ||
    /relation .* does not exist/i.test(message)
  );
}

export const SCHEMA_MISSING_MESSAGE =
  "Momentum's tables are missing from your Supabase project. Run supabase/schema.sql in the Supabase SQL editor once, then reload.";
