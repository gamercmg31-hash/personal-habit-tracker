import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import {
  SUPABASE_ANON_KEY,
  SUPABASE_URL,
  assertSupabaseConfigured,
} from "@/lib/supabase/config";

/**
 * Request-scoped Supabase client.
 *
 * The Supabase Auth session lives in HttpOnly cookies, so every query made
 * through this client runs as the signed-in user and is filtered by the Row
 * Level Security policies in `supabase/schema.sql`.
 */
export async function getSupabaseServer(): Promise<SupabaseClient> {
  assertSupabaseConfigured();
  const store = await cookies();

  return createServerClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    cookies: {
      getAll() {
        return store.getAll().map(({ name, value }) => ({ name, value }));
      },
      setAll(cookiesToSet) {
        try {
          for (const { name, value, options } of cookiesToSet) {
            store.set(name, value, options);
          }
        } catch {
          // Called from a Server Component render — the middleware/route
          // handlers refresh the cookies instead. Safe to ignore.
        }
      },
    },
  });
}

/**
 * Anonymous client (no user session). Only used for the pre-login seat picker,
 * which reads the `public_profiles` view — names and colors, never emails.
 */
export function getSupabaseAnon(): SupabaseClient {
  assertSupabaseConfigured();
  return createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
