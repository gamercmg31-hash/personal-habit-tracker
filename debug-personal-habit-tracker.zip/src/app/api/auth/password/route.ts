import { NextResponse } from "next/server";
import { getSupabaseServer } from "@/lib/supabase/server";
import { getSessionContext } from "@/lib/server/session";

export const dynamic = "force-dynamic";

/**
 * Change the signed-in owner's password through Supabase Auth.
 * The current password is re-verified first so a hijacked tab cannot rotate it.
 */
export async function POST(req: Request) {
  const session = await getSessionContext();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = (await req.json().catch(() => null)) as {
    currentPassword?: string;
    newPassword?: string;
  } | null;
  const currentPassword =
    typeof body?.currentPassword === "string" ? body.currentPassword : "";
  const newPassword = typeof body?.newPassword === "string" ? body.newPassword : "";

  if (newPassword.length < 6 || newPassword.length > 100) {
    return NextResponse.json(
      { ok: false, error: "New password must be 6–100 characters." },
      { status: 400 }
    );
  }

  const supabase = await getSupabaseServer();
  const check = await supabase.auth.signInWithPassword({
    email: session.email,
    password: currentPassword,
  });
  if (check.error || !check.data.user) {
    return NextResponse.json(
      { ok: false, error: "Current password is wrong." },
      { status: 401 }
    );
  }

  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) {
    return NextResponse.json(
      { ok: false, error: error.message || "Could not update the password." },
      { status: 400 }
    );
  }
  return NextResponse.json({ ok: true });
}
