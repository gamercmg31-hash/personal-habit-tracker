import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/server/session";
import { restoreUser, type BackupDump } from "@/lib/server/data";

export const dynamic = "force-dynamic";

/**
 * Restore the signed-in user's data from a backup file.
 * Replaces only the caller's own rows, inside a single transaction —
 * the partner's data is never touched.
 */
export async function POST(req: Request) {
  const me = await getSessionUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const dump = (await req.json().catch(() => null)) as BackupDump | null;
  if (
    !dump ||
    dump.format !== "momentum-backup" ||
    dump.version !== 1 ||
    !Array.isArray(dump.habits) ||
    !Array.isArray(dump.logs) ||
    !Array.isArray(dump.txns) ||
    !Array.isArray(dump.xpEvents)
  ) {
    return NextResponse.json(
      { error: "That file is not a valid Momentum backup." },
      { status: 400 }
    );
  }
  await restoreUser(me.id, dump);
  return NextResponse.json({ ok: true });
}
