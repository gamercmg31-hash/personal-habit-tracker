import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/server/session";
import { exportUser } from "@/lib/server/data";

export const dynamic = "force-dynamic";

/** Download a complete JSON backup of the signed-in user's data. */
export async function GET() {
  const me = await getSessionUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const dump = await exportUser(me.id);
  const stamp = new Date().toISOString().slice(0, 10);
  return new NextResponse(JSON.stringify(dump, null, 2), {
    headers: {
      "content-type": "application/json; charset=utf-8",
      "content-disposition": `attachment; filename="momentum-backup-${me.name.toLowerCase()}-${stamp}.json"`,
    },
  });
}
