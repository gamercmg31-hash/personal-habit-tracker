import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/server/session";
import { setLog } from "@/lib/server/data";

export const dynamic = "force-dynamic";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export async function PUT(
  req: Request,
  ctx: { params: Promise<{ id: string }> }
) {
  const me = await getSessionUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const id = Number((await ctx.params).id);
  if (!Number.isInteger(id) || id <= 0) {
    return NextResponse.json({ error: "Invalid id." }, { status: 400 });
  }
  const body = await req.json().catch(() => null);
  const date = body?.date;
  const status = body?.status;
  if (typeof date !== "string" || !DATE_RE.test(date)) {
    return NextResponse.json({ error: "Invalid date." }, { status: 400 });
  }
  if (status !== "completed" && status !== "skipped" && status !== null) {
    return NextResponse.json({ error: "Invalid status." }, { status: 400 });
  }
  await setLog(me.id, id, date, status);
  return NextResponse.json({ ok: true });
}
