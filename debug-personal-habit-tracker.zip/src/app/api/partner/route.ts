import { NextResponse } from "next/server";
import { getSessionContext } from "@/lib/server/session";
import { getPartnerSnapshot } from "@/lib/server/data";

export const dynamic = "force-dynamic";

/** Controlled read-only partner consistency + XP/level snapshot. */
export async function GET() {
  const session = await getSessionContext();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    return NextResponse.json({ partner: await getPartnerSnapshot() });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not load partner data." },
      { status: 503 }
    );
  }
}
