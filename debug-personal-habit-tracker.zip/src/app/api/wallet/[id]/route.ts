import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/server/session";
import { deleteTxn, updateTxn } from "@/lib/server/data";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  const me = await getSessionUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const id = (await ctx.params).id;
  if (!id) return NextResponse.json({ error: "Invalid id." }, { status: 400 });

  const body = await req.json().catch(() => null);
  const patch: Record<string, unknown> = {};
  if (typeof body?.name === "string" && body.name.trim()) patch.name = body.name.trim().slice(0, 200);
  if (typeof body?.category === "string") patch.category = body.category.slice(0, 60);
  if (typeof body?.amount === "number" && Number.isFinite(body.amount)) patch.amount = body.amount;
  if (body?.type === "income" || body?.type === "expense") patch.type = body.type;
  if (typeof body?.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(body.date)) patch.date = body.date;
  await updateTxn(me.id, id, patch);
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const me = await getSessionUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const id = (await ctx.params).id;
  if (!id) return NextResponse.json({ error: "Invalid id." }, { status: 400 });
  await deleteTxn(me.id, id);
  return NextResponse.json({ ok: true });
}
