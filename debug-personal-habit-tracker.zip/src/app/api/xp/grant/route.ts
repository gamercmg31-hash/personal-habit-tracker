import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/server/session";
import { grantXp, type ServerGrant } from "@/lib/server/data";
import { dateKey } from "@/lib/dates";

export const dynamic = "force-dynamic";

/**
 * Idempotent XP grants. The client proposes awards with their idempotency
 * keys; the server writes only keys it has never seen for this user, so
 * retries, double-clicks and re-imports can never duplicate XP.
 */
export async function POST(req: Request) {
  const me = await getSessionUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => null);
  const grants = body?.grants as ServerGrant[] | undefined;
  if (!Array.isArray(grants) || grants.length > 50) {
    return NextResponse.json({ error: "Invalid grants." }, { status: 400 });
  }
  const result = await grantXp(me.id, grants, dateKey(new Date()), Date.now());
  return NextResponse.json(result);
}
