# Momentum — Supabase Habit Tracker for Two

Momentum is a private two-person habit tracker with daily rituals, history,
streaks, consistency heatmaps, the original **Wallet money-bag + Cash design**,
and Ascend XP/levels/quests/achievements.

The application now uses **Supabase Auth + PostgreSQL + Row Level Security** as
its only persistence layer. Data survives refreshes, sign-out/sign-in,
deployments, and GitHub updates.

## Connected Supabase project

- Project URL: `https://uxawqcrwbkckhldtdiwv.supabase.co`
- Client credential: Supabase **publishable key** (`sb_publishable_…`)
- No database password is used.
- No service-role/secret key is used.

The publishable key is intentionally safe to expose in browser bundles. Security
comes from authenticated JWTs and the RLS policies in the migration.

## Required one-time Supabase setup

The supplied publishable key can use Auth and RLS-protected tables, but by design
it cannot create database tables or policies. Run the repository migration once:

1. Open the project's SQL Editor:
   <https://supabase.com/dashboard/project/uxawqcrwbkckhldtdiwv/sql/new>
2. Open `supabase/migrations/0001_momentum_fresh.sql` in this repository.
3. Copy all SQL, paste it into the SQL Editor, and press **Run**.
4. Reload Momentum. The first account can now be created at `/create-account`.

> **Destructive fresh start:** this migration deletes existing Momentum tables,
> records, and Supabase Auth users before rebuilding everything. That is
> intentional for the requested reset. Do not rerun it after entering real data.

The app displays a setup gate with these same instructions until the migration
exists, so an account cannot be created into an unsecured/unconfigured project.

## Exactly two Supabase Auth users

- Account creation uses email + password through Supabase Auth.
- The first signup gets seat 1; the second gets seat 2.
- A database trigger uses a transaction advisory lock and rejects every third
  signup, including concurrent signup attempts.
- Display names are unique case-insensitively.
- Emails stay in `auth.users`; the public pre-login account picker exposes only
  profile name, color, slot, and UUID.
- This project currently has email confirmation enabled. Each new user confirms
  the signup email once before signing in.

## Data persisted in Supabase

| Table | Purpose |
| --- | --- |
| `profiles` | Two profile seats, names, colors, settings |
| `habits` | Each user's rituals |
| `habit_logs` | Completion/skip history and streak source data |
| `wallet_txns` | Income/expense ledger for the existing Wallet UI |
| `xp_events` | Immutable, idempotent XP event ledger |
| `progress_state` | Persisted total XP and level |
| `quest_claims` | Persisted claimed daily/weekly quests |
| `achievements` | Persisted unlocked achievements |

Default habits are seeded exactly once by an authenticated database function.
Levels and achievements are recalculated from the XP ledger by a database
trigger, including after backup restoration or XP deletion.

## RLS security model

RLS is enabled on every public table.

- Habits, habit history, wallet, quest claims, and achievements are readable and
  writable only by their owner (`auth.uid() = user_id`).
- Both authenticated Momentum users may read each other's XP event ledger and
  persisted level/total XP.
- Users may insert/delete only their own XP events; persisted level state is
  trigger-managed and cannot be directly modified by clients.
- Profile updates are restricted to the profile owner.
- Partner consistency is provided through a read-only, authenticated,
  `SECURITY DEFINER` snapshot function. This preserves the existing partner
  consistency UI without granting direct table access to private habit rows.
- Anonymous users can call only the narrow account-picker function, which never
  returns email or progress data.

## Environment variables

Create `.env.local` in development or configure these in your hosting provider:

```env
NEXT_PUBLIC_SUPABASE_URL=https://uxawqcrwbkckhldtdiwv.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_your_key
```

Do **not** add `DATABASE_URL`, a database password, or
`SUPABASE_SERVICE_ROLE_KEY`. They are not needed.

## GitHub / deployment

```bash
npm install
npm run build
npm run dev
```

For Vercel/Netlify/another host:

1. Push this repository to GitHub.
2. Import the repository into the host.
3. Add the two public Supabase environment variables above.
4. Deploy.
5. In Supabase Auth URL Configuration, add the production website URL to the
   allowed redirect URLs so confirmation links return to the deployed site.

No migration runs during deployment; the one-time SQL Editor migration remains
in Supabase permanently and all later website redeploys preserve data.

## Runtime APIs

The existing UI continues using same-origin route handlers, now backed by a
cookie-authenticated Supabase client:

- `GET|POST /api/accounts`
- `POST /api/auth/signin`, `POST /api/auth/signout`, `GET /api/auth/me`
- `POST /api/auth/password`
- `GET /api/bootstrap`, `GET /api/partner`
- Habit/log CRUD under `/api/habits`
- Wallet CRUD under `/api/wallet`
- Idempotent XP grants at `/api/xp/grant`
- Per-user backup/restore under `/api/backup`
- Supabase connectivity healthcheck at `/api/health`

The legacy localStorage importer is intentionally disabled so reset data cannot
reappear after first login.
