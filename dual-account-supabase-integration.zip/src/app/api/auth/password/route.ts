import { NextResponse } from "next/server";
import { getSessionContext } from "@/lib/server/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const session = await getSessionContext();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = (await req.json().catch(() => null)) as {
    currentPassword?: string;
    newPassword?: string;
  } | null;
  const currentPassword = typeof body?.currentPassword === "string" ? body.currentPassword : "";
  const newPassword = typeof body?.newPassword === "string" ? body.newPassword : "";
  if (newPassword.length < 6 || newPassword.length > 100) {
    return NextResponse.json(
      { ok: false, error: "New password must be 6–100 characters." },
      { status: 400 }
    );
  }
  if (!session.authUser.email) {
    return NextResponse.json({ ok: false, error: "Account email is unavailable." }, { status: 400 });
  }

  const verify = await session.supabase.auth.signInWithPassword({
    email: session.authUser.email,
    password: currentPassword,
  });
  if (verify.error) {
    return NextResponse.json({ ok: false, error: "Current password is wrong." }, { status: 401 });
  }
  const { error } = await session.supabase.auth.updateUser({ password: newPassword });
  if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
