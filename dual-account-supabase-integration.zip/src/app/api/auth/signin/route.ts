import { NextResponse } from "next/server";
import { accountById } from "@/lib/server/accounts";
import { getSupabaseServerClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as {
    email?: string;
    password?: string;
    selectedUserId?: string;
  } | null;
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  if (!email || !password) {
    return NextResponse.json({ ok: false, error: "Email and password are required." }, { status: 400 });
  }

  const supabase = await getSupabaseServerClient();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error || !data.user) {
    return NextResponse.json(
      { ok: false, error: error?.message ?? "Wrong email or password." },
      { status: 401 }
    );
  }

  // When a tile was selected, prevent accidentally entering the other account.
  if (body?.selectedUserId && data.user.id !== body.selectedUserId) {
    await supabase.auth.signOut();
    return NextResponse.json(
      { ok: false, error: "That email belongs to the other Momentum account." },
      { status: 401 }
    );
  }

  const user = await accountById(data.user.id, supabase);
  if (!user) {
    await supabase.auth.signOut();
    return NextResponse.json({ ok: false, error: "Momentum profile not found." }, { status: 500 });
  }
  return NextResponse.json({ ok: true, user });
}
