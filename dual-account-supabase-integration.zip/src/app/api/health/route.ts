import { SUPABASE_PUBLISHABLE_KEY, SUPABASE_URL } from "@/lib/supabase/config";

export const dynamic = "force-dynamic";

/** Health verifies the supplied Supabase project, without secret credentials. */
export async function GET() {
  try {
    const response = await fetch(`${SUPABASE_URL}/auth/v1/settings`, {
      headers: { apikey: SUPABASE_PUBLISHABLE_KEY },
      cache: "no-store",
    });
    if (!response.ok) throw new Error("Supabase Auth unavailable");
    return Response.json({ ok: true, storage: "supabase", project: "uxawqcrwbkckhldtdiwv" });
  } catch {
    return Response.json({ ok: false, storage: "supabase" }, { status: 503 });
  }
}
