import { NextResponse } from "next/server";
import { getSessionContext } from "@/lib/server/session";

export const dynamic = "force-dynamic";

/**
 * Fresh Supabase starts never import old localStorage progress. Keeping this
 * endpoint as a harmless no-op prevents older browser bundles from failing.
 */
export async function POST() {
  const session = await getSessionContext();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json({
    ok: true,
    reset: true,
    counts: { habits: 0, logs: 0, txns: 0, xpEvents: 0 },
  });
}
