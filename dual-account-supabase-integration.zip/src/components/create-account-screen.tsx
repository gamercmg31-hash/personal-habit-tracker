"use client";

import { useEffect, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  Check,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  Mail,
  ShieldCheck,
  User,
  UserPlus,
} from "lucide-react";
import {
  ACCOUNT_COLOR_CHOICES,
  nameKey,
  type AccountUser,
  type AccountsState,
} from "@/lib/accounts";
import { api, apiWithWakeRetry } from "@/lib/api";
import SupabaseSetupNotice from "@/components/supabase-setup-notice";

/**
 * The separate account-creation page (/create-account).
 *
 * Shows which of the two seats are claimed, and lets the owner claim the
 * remaining one. Once both seats are taken, creation closes forever — the
 * server enforces this too, so racing requests can't bypass it.
 */
export default function CreateAccountScreen() {
  const [state, setState] = useState<AccountsState | null>(null);
  const [setupError, setSetupError] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [color, setColor] = useState<string | null>(null);
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<{
    user: AccountUser;
    requiresConfirmation: boolean;
  } | null>(null);

  useEffect(() => {
    let alive = true;
    apiWithWakeRetry<AccountsState>("/api/accounts")
      .then((res) => {
        if (!alive) return;
        setState(res);
        const used = new Set(res.accounts.map((a) => a.color));
        const free = ACCOUNT_COLOR_CHOICES.find((c) => !used.has(c));
        setColor(free ?? ACCOUNT_COLOR_CHOICES[0]);
      })
      .catch((failure) => {
        if (alive)
          setSetupError(
            failure instanceof Error ? failure.message : "Supabase schema is unavailable."
          );
      });
    return () => {
      alive = false;
    };
  }, []);

  const takenKeys = new Set((state?.accounts ?? []).map((a) => nameKey(a.name)));
  const full = state ? state.slotsOpen <= 0 : false;

  const clientError = (() => {
    const n = name.trim().replace(/\s+/g, " ");
    if (n.length > 0 && n.length < 2) return "Name must be at least 2 characters.";
    if (n.length > 24) return "Name must be at most 24 characters.";
    if (takenKeys.has(nameKey(n)))
      return `“${n}” is already taken — the two accounts can't share a name.`;
    if (email.length > 0 && !/^\S+@\S+\.\S+$/.test(email.trim()))
      return "Enter a valid email address.";
    if (password.length > 0 && password.length < 6)
      return "Password must be at least 6 characters.";
    if (confirm.length > 0 && password !== confirm) return "Passwords don't match.";
    return null;
  })();

  const canSubmit =
    !loading &&
    !full &&
    state !== null &&
    name.trim().length >= 2 &&
    /^\S+@\S+\.\S+$/.test(email.trim()) &&
    password.length >= 6 &&
    confirm === password;

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!canSubmit || !color) return;
    setLoading(true);
    setError(null);
    window.setTimeout(() => {
      api<{
        ok: boolean;
        user: AccountUser;
        requiresConfirmation: boolean;
      }>("/api/accounts", {
        method: "POST",
        body: JSON.stringify({ name: name.trim(), email: email.trim(), password, color }),
      })
        .then((res) =>
          setDone({ user: res.user, requiresConfirmation: res.requiresConfirmation })
        )
        .catch((err) => {
          setError(err instanceof Error ? err.message : "Could not create the account.");
          setLoading(false);
          // account count may have changed while the form was open — refresh
          apiWithWakeRetry<AccountsState>("/api/accounts").then(setState).catch(() => {});
        });
    }, 350);
  };

  if (setupError) return <SupabaseSetupNotice message={setupError} />;

  return (
    <main className="grain relative grid min-h-screen place-items-center bg-[#0a0a0c] px-4 py-12">
      <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden>
        <div className="ambient-blob absolute -top-32 left-[15%] h-[380px] w-[520px] rounded-full bg-lime-400/[0.06] blur-[120px]" />
        <div
          className="ambient-blob absolute right-[10%] bottom-[10%] h-[320px] w-[420px] rounded-full bg-sky-400/[0.05] blur-[120px]"
          style={{ animationDelay: "-5s" }}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-md"
      >
        <a
          href="/"
          className="mb-5 inline-flex items-center gap-1.5 text-xs font-medium text-zinc-500 transition hover:text-zinc-200"
        >
          <ArrowLeft size={13} />
          Back to sign in
        </a>

        {/* brand */}
        <div className="mb-8 text-center">
          <motion.div
            initial={{ scale: 0, rotate: -20 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 18, delay: 0.15 }}
            className="mx-auto grid size-14 place-items-center rounded-2xl bg-lime-400 text-lime-950 shadow-[0_0_40px_rgba(163,230,53,0.4)]"
          >
            <UserPlus size={26} strokeWidth={2.6} />
          </motion.div>
          <h1 className="font-display mt-5 text-3xl font-semibold tracking-tight text-white">
            {full ? "Seats are filled" : "Claim your seat"}
          </h1>
          <p className="mt-1.5 text-sm text-zinc-500">
            {full
              ? "Both accounts already exist — this tracker is full."
              : "Momentum holds exactly two accounts. One of them is yours."}
          </p>
        </div>

        {/* seat status */}
        <div className="mb-4 grid grid-cols-2 gap-3">
          {[0, 1].map((i) => {
            const holder = state?.accounts[i] ?? null;
            const seatLabel = i === 0 ? "Seat one" : "Seat two";
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + i * 0.08 }}
                className={`flex items-center gap-3 rounded-2xl border px-4 py-3.5 ${
                  holder
                    ? "border-white/[0.08] bg-white/[0.03]"
                    : "border-dashed border-white/[0.14] bg-white/[0.01]"
                }`}
              >
                <span
                  className={`font-display grid size-9 shrink-0 place-items-center rounded-full text-sm font-semibold ${
                    holder ? "text-zinc-950" : "text-zinc-600"
                  }`}
                  style={
                    holder
                      ? { background: holder.color }
                      : { border: "1px dashed rgba(255,255,255,0.14)" }
                  }
                >
                  {holder ? holder.name.charAt(0).toUpperCase() : <UserPlus size={14} />}
                </span>
                <span className="min-w-0">
                  <span className="block text-[10px] font-semibold tracking-[0.14em] text-zinc-500 uppercase">
                    {seatLabel}
                  </span>
                  <span
                    className={`block truncate text-sm font-medium ${
                      holder ? "text-white" : "text-zinc-500"
                    }`}
                  >
                    {holder ? holder.name : state ? "Open" : "…"}
                  </span>
                </span>
              </motion.div>
            );
          })}
        </div>

        <div className="rounded-3xl border border-white/[0.08] bg-white/[0.03] p-6 backdrop-blur sm:p-7">
          <AnimatePresence mode="wait">
            {done ? (
              /* ---- success -------------------------------------------------- */
              <motion.div
                key="done"
                initial={{ opacity: 0, scale: 0.97 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 300, damping: 16, delay: 0.1 }}
                  className="mx-auto grid size-14 place-items-center rounded-full text-zinc-950"
                  style={{ background: done.user.color }}
                >
                  <Check size={26} strokeWidth={3} />
                </motion.div>
                <h2 className="font-display mt-4 text-xl font-semibold text-white">
                  Welcome, {done.user.name}
                </h2>
                <p className="mt-1.5 text-sm leading-relaxed text-zinc-500">
                  {done.requiresConfirmation
                    ? `Check ${email} and confirm your Supabase email, then return here to sign in.`
                    : "Your Supabase account is created and you’re signed in."}
                </p>
                <a
                  href="/"
                  className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-lime-400 py-3 text-sm font-semibold text-lime-950 transition hover:bg-lime-300 active:scale-[0.98]"
                >
                  {done.requiresConfirmation ? "Return to sign in" : "Enter Momentum"}
                </a>
              </motion.div>
            ) : full ? (
              /* ---- closed ---------------------------------------------------- */
              <motion.div
                key="full"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center"
              >
                <div className="mx-auto grid size-14 place-items-center rounded-full bg-white/[0.05] text-zinc-400">
                  <ShieldCheck size={24} />
                </div>
                <p className="mt-4 text-sm leading-relaxed text-zinc-400">
                  No further accounts can ever be created.
                  {state && state.accounts.length > 0
                    ? ` ${state.accounts.map((a) => a.name).join(" and ")} already hold both seats.`
                    : ""}
                </p>
                <a
                  href="/"
                  className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] py-3 text-sm font-semibold text-white transition hover:bg-white/[0.08] active:scale-[0.98]"
                >
                  <ArrowLeft size={15} />
                  Go to sign in
                </a>
              </motion.div>
            ) : (
              /* ---- creation form --------------------------------------------- */
              <motion.form
                key="form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                onSubmit={submit}
                noValidate
              >
                <label
                  htmlFor="create-name"
                  className="text-[11px] font-semibold tracking-[0.16em] text-zinc-500 uppercase"
                >
                  Your name
                </label>
                <div className="relative mt-2">
                  <User
                    size={15}
                    className="absolute top-1/2 left-4 -translate-y-1/2 text-zinc-500"
                  />
                  <input
                    id="create-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    autoFocus
                    autoComplete="off"
                    maxLength={24}
                    placeholder="e.g. Riley"
                    className="w-full rounded-xl border border-white/10 bg-white/[0.04] py-3 pl-11 pr-4 text-[15px] text-white placeholder-zinc-600 transition outline-none focus:border-lime-400/50 focus:ring-2 focus:ring-lime-400/20"
                  />
                </div>

                <label
                  htmlFor="create-email"
                  className="mt-4 block text-[11px] font-semibold tracking-[0.16em] text-zinc-500 uppercase"
                >
                  Email
                </label>
                <div className="relative mt-2">
                  <Mail
                    size={15}
                    className="absolute top-1/2 left-4 -translate-y-1/2 text-zinc-500"
                  />
                  <input
                    id="create-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    autoComplete="email"
                    placeholder="you@example.com"
                    className="w-full rounded-xl border border-white/10 bg-white/[0.04] py-3 pl-11 pr-4 text-[15px] text-white placeholder-zinc-600 transition outline-none focus:border-lime-400/50 focus:ring-2 focus:ring-lime-400/20"
                  />
                </div>

                <label
                  htmlFor="create-password"
                  className="mt-4 block text-[11px] font-semibold tracking-[0.16em] text-zinc-500 uppercase"
                >
                  Password
                </label>
                <div className="relative mt-2">
                  <Lock
                    size={15}
                    className="absolute top-1/2 left-4 -translate-y-1/2 text-zinc-500"
                  />
                  <input
                    id="create-password"
                    type={showPw ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="new-password"
                    placeholder="At least 6 characters"
                    className="w-full rounded-xl border border-white/10 bg-white/[0.04] py-3 pr-12 pl-11 text-[15px] text-white placeholder-zinc-600 transition outline-none focus:border-lime-400/50 focus:ring-2 focus:ring-lime-400/20"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw((v) => !v)}
                    aria-label={showPw ? "Hide password" : "Show password"}
                    className="absolute top-1/2 right-3 grid size-8 -translate-y-1/2 place-items-center rounded-full text-zinc-500 transition hover:text-white"
                  >
                    {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>

                <label
                  htmlFor="create-confirm"
                  className="mt-4 block text-[11px] font-semibold tracking-[0.16em] text-zinc-500 uppercase"
                >
                  Confirm password
                </label>
                <div className="relative mt-2">
                  <Lock
                    size={15}
                    className="absolute top-1/2 left-4 -translate-y-1/2 text-zinc-500"
                  />
                  <input
                    id="create-confirm"
                    type={showPw ? "text" : "password"}
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    autoComplete="new-password"
                    placeholder="Repeat it once more"
                    className="w-full rounded-xl border border-white/10 bg-white/[0.04] py-3 pl-11 pr-4 text-[15px] text-white placeholder-zinc-600 transition outline-none focus:border-lime-400/50 focus:ring-2 focus:ring-lime-400/20"
                  />
                </div>

                {/* color choice */}
                <p className="mt-4 text-[11px] font-semibold tracking-[0.16em] text-zinc-500 uppercase">
                  Your color
                </p>
                <div className="mt-2.5 flex flex-wrap gap-2.5">
                  {ACCOUNT_COLOR_CHOICES.map((c) => {
                    const usedByPartner = state?.accounts.some((a) => a.color === c);
                    const active = color === c;
                    return (
                      <button
                        key={c}
                        type="button"
                        disabled={usedByPartner}
                        onClick={() => setColor(c)}
                        aria-label={`Choose color ${c}`}
                        className={`grid size-9 rounded-full transition-transform ${
                          usedByPartner
                            ? "cursor-not-allowed opacity-25"
                            : "hover:scale-110"
                        } ${active ? "scale-110" : ""}`}
                        style={{
                          background: c,
                          boxShadow: active
                            ? `0 0 0 2px #0a0a0c, 0 0 0 4px ${c}`
                            : undefined,
                        }}
                      >
                        {active && <Check size={15} strokeWidth={3} className="m-auto text-zinc-950" />}
                      </button>
                    );
                  })}
                </div>

                {(error ?? clientError) &&
                  name.length + email.length + password.length + confirm.length > 0 && (
                  <motion.p
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-4 text-xs font-medium text-rose-400"
                  >
                    {error ?? clientError}
                  </motion.p>
                )}

                <button
                  type="submit"
                  disabled={!canSubmit || !color}
                  className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-lime-400 py-3 text-sm font-semibold text-lime-950 transition hover:bg-lime-300 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
                >
                  {loading ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : (
                    <ShieldCheck size={16} />
                  )}
                  {loading ? "Creating your account…" : "Create my account"}
                </button>

                <p className="mt-4 text-center text-[11px] leading-relaxed text-zinc-600">
                  Supabase Auth protects the login. If email confirmation is enabled,
                  confirm once from your inbox. The other seat then stays open for
                  exactly one more person.
                </p>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </main>
  );
}
