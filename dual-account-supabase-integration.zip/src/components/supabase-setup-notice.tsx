"use client";

import { motion } from "framer-motion";
import { Check, Copy, Database, ExternalLink, ShieldCheck } from "lucide-react";
import { useState } from "react";

const SQL_EDITOR =
  "https://supabase.com/dashboard/project/uxawqcrwbkckhldtdiwv/sql/new";

export default function SupabaseSetupNotice({ message }: { message?: string }) {
  const [copied, setCopied] = useState(false);
  const path = "supabase/migrations/0001_momentum_fresh.sql";

  const copyPath = () => {
    void navigator.clipboard.writeText(path);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <main className="relative grid min-h-screen place-items-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        className="w-full max-w-md rounded-3xl border border-white/[0.08] bg-white/[0.03] p-7 text-center backdrop-blur"
      >
        <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-emerald-400/15 text-emerald-300">
          <Database size={25} />
        </div>
        <p className="mt-4 text-[10px] font-bold tracking-[0.2em] text-emerald-400 uppercase">
          Project connected
        </p>
        <h1 className="font-display mt-1.5 text-2xl font-semibold tracking-tight text-white">
          Install the secure schema
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-zinc-500">
          Your Project URL and publishable key work. Supabase still needs the
          Momentum tables and RLS policies installed once before signup.
        </p>

        <div className="mt-5 rounded-2xl border border-white/[0.08] bg-black/20 p-4 text-left">
          <div className="flex gap-3">
            <span className="grid size-6 shrink-0 place-items-center rounded-full bg-lime-400 text-[11px] font-bold text-lime-950">1</span>
            <p className="text-xs leading-relaxed text-zinc-400">
              Open the migration file in this repository and copy all its SQL.
            </p>
          </div>
          <button
            onClick={copyPath}
            className="mt-3 flex w-full items-center justify-between gap-3 rounded-xl border border-white/[0.08] bg-white/[0.03] px-3.5 py-3 text-left font-mono text-[11px] text-zinc-300 transition hover:bg-white/[0.06]"
          >
            <span className="truncate">{path}</span>
            {copied ? <Check size={14} className="shrink-0 text-lime-300" /> : <Copy size={14} className="shrink-0 text-zinc-500" />}
          </button>

          <div className="mt-4 flex gap-3">
            <span className="grid size-6 shrink-0 place-items-center rounded-full bg-lime-400 text-[11px] font-bold text-lime-950">2</span>
            <p className="text-xs leading-relaxed text-zinc-400">
              Paste it into your Supabase SQL Editor and press Run. It performs
              the requested fresh reset and creates all RLS policies.
            </p>
          </div>
        </div>

        <a
          href={SQL_EDITOR}
          target="_blank"
          rel="noreferrer"
          className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-lime-400 py-3 text-sm font-semibold text-lime-950 transition hover:bg-lime-300 active:scale-[0.98]"
        >
          Open this project’s SQL Editor
          <ExternalLink size={14} />
        </a>
        <button
          onClick={() => window.location.reload()}
          className="mt-2.5 flex w-full items-center justify-center gap-2 rounded-xl border border-white/[0.08] bg-white/[0.03] py-3 text-sm font-medium text-zinc-300 transition hover:bg-white/[0.07]"
        >
          <ShieldCheck size={14} className="text-emerald-300" />
          I ran it — check again
        </button>
        {message && (
          <p className="mt-4 text-[10px] leading-relaxed text-zinc-700">{message}</p>
        )}
      </motion.div>
    </main>
  );
}
