// Typed fetch helpers for Momentum's API routes.
// Cookies (session) flow automatically via same-origin requests.

export class ApiError extends Error {
  status: number;

  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    credentials: "same-origin",
    cache: "no-store",
    ...init,
    headers: {
      ...(init?.body ? { "content-type": "application/json" } : {}),
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const data = await res.json();
      if (data?.error) message = data.error;
    } catch {
      /* keep default message */
    }
    throw new ApiError(message, res.status);
  }
  return (await res.json()) as T;
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

/**
 * GET helper for cold-start-sensitive reads. Preview/serverless runtimes can
 * need a few seconds to wake up; retry network errors and 5xx responses, but
 * never retry real client/auth errors (400/401/403/404/409).
 */
export async function apiWithWakeRetry<T>(
  path: string,
  attempts = 6
): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      return await api<T>(path);
    } catch (error) {
      lastError = error;
      const schemaMissing =
        error instanceof Error && error.message.includes("Supabase tables are not installed");
      const retryable =
        !schemaMissing && (!(error instanceof ApiError) || error.status >= 500);
      if (!retryable || attempt === attempts - 1) throw error;
      // 1s, 2s, 3s, 4s, 5s — enough time for the runtime + DB to wake.
      await wait((attempt + 1) * 1000);
    }
  }
  throw lastError;
}
