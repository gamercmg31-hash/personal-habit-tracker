// Server-only Supabase account registry.
// Passwords belong exclusively to Supabase Auth; Momentum never hashes, stores,
// logs, or reads password hashes and never uses a service-role key.

import type { SupabaseClient } from "@supabase/supabase-js";
import { MAX_ACCOUNTS, type AccountUser } from "@/lib/accounts";
import { getSupabaseServerClient } from "@/lib/supabase/server";
import { supabaseError } from "@/lib/supabase/errors";

interface ProfileRow {
  user_id: string;
  slot: number;
  name: string;
  color: string;
}

function toUser(row: ProfileRow): AccountUser {
  return {
    id: row.user_id,
    key: row.user_id,
    name: row.name,
    color: row.color,
  };
}

/** Public pre-login list: the RPC reveals names/colors/slots, never emails. */
export async function listAccounts(
  client?: SupabaseClient
): Promise<AccountUser[]> {
  const supabase = client ?? (await getSupabaseServerClient());
  const { data, error } = await supabase.rpc("momentum_account_status");
  if (error) supabaseError(error);
  return ((data ?? []) as ProfileRow[]).map(toUser);
}

export async function accountById(
  userId: string,
  client?: SupabaseClient
): Promise<AccountUser | null> {
  const supabase = client ?? (await getSupabaseServerClient());
  const { data, error } = await supabase
    .from("profiles")
    .select("user_id,slot,name,color")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) supabaseError(error);
  return data ? toUser(data as ProfileRow) : null;
}

export async function partnerOf(
  userId: string,
  client?: SupabaseClient
): Promise<AccountUser | null> {
  const all = await listAccounts(client);
  return all.find((user) => user.id !== userId) ?? null;
}

export type CreateAccountResult =
  | { ok: true; user: AccountUser; requiresConfirmation: boolean }
  | { ok: false; status: number; error: string };

/** Supabase Auth signup; the SQL trigger atomically enforces the two-seat cap. */
export async function createAccount(input: {
  name: string;
  email: string;
  password: string;
  color?: string;
}): Promise<CreateAccountResult> {
  const name = input.name.trim().replace(/\s+/g, " ");
  const email = input.email.trim().toLowerCase();
  if (name.length < 2 || name.length > 24) {
    return { ok: false, status: 400, error: "Name must be 2–24 characters." };
  }
  if (!/^\S+@\S+\.\S+$/.test(email) || email.length > 254) {
    return { ok: false, status: 400, error: "Enter a valid email address." };
  }
  if (input.password.length < 6 || input.password.length > 100) {
    return { ok: false, status: 400, error: "Password must be 6–100 characters." };
  }

  const existing = await listAccounts();
  if (existing.length >= MAX_ACCOUNTS) {
    return {
      ok: false,
      status: 409,
      error: "Both accounts already exist — this tracker is full.",
    };
  }
  if (existing.some((user) => user.name.toLowerCase() === name.toLowerCase())) {
    return {
      ok: false,
      status: 409,
      error: `“${name}” is already taken — the two accounts can't share a name.`,
    };
  }

  const supabase = await getSupabaseServerClient();
  const { data, error } = await supabase.auth.signUp({
    email,
    password: input.password,
    options: {
      data: {
        name,
        color:
          input.color && /^#[0-9a-fA-F]{6}$/.test(input.color)
            ? input.color.toLowerCase()
            : undefined,
      },
    },
  });

  if (error || !data.user) {
    const message = error?.message ?? "Could not create the Supabase account.";
    const full = /two users|two user|already has/i.test(message);
    return {
      ok: false,
      status: full ? 409 : 400,
      error: full ? "Both accounts already exist — this tracker is full." : message,
    };
  }

  const accounts = await listAccounts(supabase);
  const user = accounts.find((item) => item.id === data.user!.id);
  if (!user) {
    return {
      ok: false,
      status: 500,
      error: "Supabase created the login but the Momentum profile is missing.",
    };
  }
  return { ok: true, user, requiresConfirmation: !data.session };
}
