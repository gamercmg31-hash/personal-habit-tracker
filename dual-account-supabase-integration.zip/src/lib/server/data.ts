// Server-only Supabase data layer.
//
// Every request is authenticated with Supabase Auth cookies. PostgreSQL RLS is
// the final authorization boundary: private tables can only be read/written by
// their owner; XP/level is readable by both users; partner consistency comes
// through the controlled momentum_partner_snapshot() function.

import type { SupabaseClient } from "@supabase/supabase-js";
import { dateKey } from "@/lib/dates";
import type { HabitRecord, LogRecord, LogStatusValue } from "@/lib/types";
import type { Txn } from "@/lib/wallet";
import type { XpEvent } from "@/lib/xp";
import type { AccountUser } from "@/lib/accounts";
import { getSessionContext } from "@/lib/server/session";
import { supabaseError } from "@/lib/supabase/errors";

async function ownClient(userId: string): Promise<SupabaseClient> {
  const ctx = await getSessionContext();
  if (!ctx || ctx.user.id !== userId) throw new Error("Unauthorized");
  return ctx.supabase;
}

interface HabitRow {
  id: number | string;
  user_id: string;
  name: string;
  icon: string;
  color: string;
  sort_order: number;
  created_key: string;
}

interface LogRow {
  user_id: string;
  habit_id: number | string;
  date: string;
  status: string;
}

interface TxnRow {
  id: string;
  user_id: string;
  name: string;
  category: string;
  amount: number;
  type: string;
  date: string;
  created_at: number | string;
}

interface XpRow {
  user_id: string;
  key: string;
  label: string;
  amount: number;
  day: string;
  at_ms: number | string;
}

function habitRow(row: HabitRow): HabitRecord {
  return {
    id: Number(row.id),
    userId: row.user_id,
    name: row.name,
    icon: row.icon,
    color: row.color,
    sortOrder: row.sort_order,
    createdKey: row.created_key,
  };
}

function logRow(row: LogRow): LogRecord {
  return {
    userId: row.user_id,
    habitId: Number(row.habit_id),
    date: row.date,
    status: row.status as LogStatusValue,
  };
}

function txnRow(row: TxnRow): Txn {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    amount: Number(row.amount),
    type: row.type as Txn["type"],
    date: row.date,
    createdAt: Number(row.created_at),
  };
}

function xpRow(row: XpRow): XpEvent {
  return {
    key: row.key,
    label: row.label,
    amount: row.amount,
    day: row.day,
    at: Number(row.at_ms),
  };
}

/* ---- profiles / fresh defaults --------------------------------------------- */

/** Profiles are created atomically by the auth.users trigger. */
export async function ensureProfile(): Promise<void> {}

export async function ensureSeeded(userId: string): Promise<void> {
  const supabase = await ownClient(userId);
  const { error } = await supabase.rpc("momentum_seed_defaults");
  if (error) supabaseError(error);
}

/* ---- habits + logs ---------------------------------------------------------- */

export async function getHabits(userId: string): Promise<HabitRecord[]> {
  const supabase = await ownClient(userId);
  const { data, error } = await supabase
    .from("habits")
    .select("id,user_id,name,icon,color,sort_order,created_key")
    .eq("user_id", userId)
    .order("sort_order", { ascending: true })
    .order("id", { ascending: true });
  if (error) supabaseError(error);
  return ((data ?? []) as HabitRow[]).map(habitRow);
}

export async function getLogs(userId: string): Promise<LogRecord[]> {
  const supabase = await ownClient(userId);
  const { data, error } = await supabase
    .from("habit_logs")
    .select("user_id,habit_id,date,status")
    .eq("user_id", userId)
    .order("date", { ascending: true });
  if (error) supabaseError(error);
  return ((data ?? []) as LogRow[]).map(logRow);
}

export async function createHabit(
  userId: string,
  input: { name: string; icon: string; color: string }
): Promise<HabitRecord> {
  const supabase = await ownClient(userId);
  const { data: tail, error: tailError } = await supabase
    .from("habits")
    .select("sort_order")
    .eq("user_id", userId)
    .order("sort_order", { ascending: false })
    .limit(1);
  if (tailError) supabaseError(tailError);
  const sortOrder = Number(tail?.[0]?.sort_order ?? 0) + 1;
  const { data, error } = await supabase
    .from("habits")
    .insert({
      user_id: userId,
      name: input.name,
      icon: input.icon,
      color: input.color,
      sort_order: sortOrder,
      created_key: dateKey(new Date()),
    })
    .select("id,user_id,name,icon,color,sort_order,created_key")
    .single();
  if (error) supabaseError(error);
  return habitRow(data as HabitRow);
}

export async function updateHabit(
  userId: string,
  habitId: number,
  patch: { name?: string; icon?: string; color?: string }
): Promise<void> {
  const supabase = await ownClient(userId);
  const { error } = await supabase
    .from("habits")
    .update(patch)
    .eq("user_id", userId)
    .eq("id", habitId);
  if (error) supabaseError(error);
}

export async function deleteHabit(userId: string, habitId: number): Promise<void> {
  const supabase = await ownClient(userId);
  const { error } = await supabase
    .from("habits")
    .delete()
    .eq("user_id", userId)
    .eq("id", habitId);
  if (error) supabaseError(error);
}

export async function setLog(
  userId: string,
  habitId: number,
  date: string,
  status: LogStatusValue | null
): Promise<void> {
  const supabase = await ownClient(userId);
  if (status === null) {
    const { error } = await supabase
      .from("habit_logs")
      .delete()
      .eq("user_id", userId)
      .eq("habit_id", habitId)
      .eq("date", date);
    if (error) supabaseError(error);
    return;
  }
  const { error } = await supabase.from("habit_logs").upsert(
    {
      user_id: userId,
      habit_id: habitId,
      date,
      status,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "user_id,habit_id,date" }
  );
  if (error) supabaseError(error);
}

/* ---- wallet ---------------------------------------------------------------- */

export async function getTxns(userId: string): Promise<Txn[]> {
  const supabase = await ownClient(userId);
  const { data, error } = await supabase
    .from("wallet_txns")
    .select("id,user_id,name,category,amount,type,date,created_at")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });
  if (error) supabaseError(error);
  return ((data ?? []) as TxnRow[]).map(txnRow);
}

export async function createTxn(userId: string, txn: Txn): Promise<Txn> {
  const supabase = await ownClient(userId);
  const payload = {
    id: txn.id,
    user_id: userId,
    name: txn.name,
    category: txn.category,
    amount: txn.amount,
    type: txn.type,
    date: txn.date,
    created_at: txn.createdAt,
  };
  const { data, error } = await supabase
    .from("wallet_txns")
    .upsert(payload, { onConflict: "id" })
    .select("id,user_id,name,category,amount,type,date,created_at")
    .single();
  if (error) supabaseError(error);
  return txnRow(data as TxnRow);
}

export async function updateTxn(
  userId: string,
  id: string,
  patch: Partial<Omit<Txn, "id" | "createdAt">>
): Promise<void> {
  const supabase = await ownClient(userId);
  const { error } = await supabase
    .from("wallet_txns")
    .update(patch)
    .eq("user_id", userId)
    .eq("id", id);
  if (error) supabaseError(error);
}

export async function deleteTxn(userId: string, id: string): Promise<void> {
  const supabase = await ownClient(userId);
  const { error } = await supabase
    .from("wallet_txns")
    .delete()
    .eq("user_id", userId)
    .eq("id", id);
  if (error) supabaseError(error);
}

/* ---- XP, levels, quests, achievements -------------------------------------- */

export async function getXpEvents(userId: string): Promise<XpEvent[]> {
  const ctx = await getSessionContext();
  if (!ctx) throw new Error("Unauthorized");
  // RLS permits both authenticated Momentum users to read either XP ledger.
  const { data, error } = await ctx.supabase
    .from("xp_events")
    .select("user_id,key,label,amount,day,at_ms")
    .eq("user_id", userId)
    .order("at_ms", { ascending: true });
  if (error) supabaseError(error);
  return ((data ?? []) as XpRow[]).map(xpRow);
}

export interface ServerGrant {
  key: string;
  label: string;
  amount: number;
}

export async function grantXp(
  userId: string,
  grants: ServerGrant[],
  day: string,
  nowMs: number
): Promise<{ gained: XpEvent[]; totalXp: number }> {
  const supabase = await ownClient(userId);
  const { data, error } = await supabase.rpc("momentum_grant_xp", {
    p_grants: grants,
    p_day: day,
    p_now: nowMs,
  });
  if (error) supabaseError(error);
  const result = (data ?? { gained: [], totalXp: 0 }) as {
    gained: XpEvent[];
    totalXp: number;
  };
  return { gained: result.gained ?? [], totalXp: Number(result.totalXp ?? 0) };
}

export async function getProgressState(userId: string) {
  const ctx = await getSessionContext();
  if (!ctx) throw new Error("Unauthorized");
  const { data, error } = await ctx.supabase
    .from("progress_state")
    .select("total_xp,level")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) supabaseError(error);
  return { totalXp: Number(data?.total_xp ?? 0), level: Number(data?.level ?? 1) };
}

export async function getOwnedProgressDetails(userId: string) {
  const supabase = await ownClient(userId);
  const [{ data: quests, error: questError }, { data: achievements, error: achievementError }] =
    await Promise.all([
      supabase
        .from("quest_claims")
        .select("event_key,quest_id,period_key,xp_awarded,claimed_at")
        .eq("user_id", userId),
      supabase
        .from("achievements")
        .select("achievement_id,unlocked_at,metadata")
        .eq("user_id", userId),
    ]);
  if (questError) supabaseError(questError);
  if (achievementError) supabaseError(achievementError);
  return { quests: quests ?? [], achievements: achievements ?? [] };
}

/* ---- controlled partner view ---------------------------------------------- */

export interface PartnerDataSnapshot {
  user: AccountUser;
  slice: { seeded: boolean; habits: HabitRecord[]; logs: LogRecord[] };
  xp: { totalXp: number; level?: number; events: XpEvent[] };
}

export async function getPartnerSnapshot(): Promise<PartnerDataSnapshot | null> {
  const ctx = await getSessionContext();
  if (!ctx) throw new Error("Unauthorized");
  const { data, error } = await ctx.supabase.rpc("momentum_partner_snapshot");
  if (error) supabaseError(error);
  return (data ?? null) as PartnerDataSnapshot | null;
}

/* ---- fresh-start import policy -------------------------------------------- */

export interface ImportPayload {
  habits?: HabitRecord[];
  logs?: LogRecord[];
  txns?: Txn[];
  xpEvents?: XpEvent[];
}

/** Existing browser data is intentionally not imported into the fresh install. */
export async function importLegacy() {
  return { habits: 0, logs: 0, txns: 0, xpEvents: 0, reset: true };
}

/* ---- backup / restore ------------------------------------------------------ */

export interface BackupDump {
  format: "momentum-backup";
  version: 1;
  exportedAt: string;
  user: { userId: string; name: string; color: string };
  profile: Record<string, unknown> | null;
  habits: HabitRecord[];
  logs: LogRecord[];
  txns: Txn[];
  xpEvents: XpEvent[];
}

export async function exportUser(userId: string): Promise<BackupDump> {
  const ctx = await getSessionContext();
  if (!ctx || ctx.user.id !== userId) throw new Error("Unauthorized");
  const [habits, logs, txns, xpEvents] = await Promise.all([
    getHabits(userId),
    getLogs(userId),
    getTxns(userId),
    getXpEvents(userId),
  ]);
  return {
    format: "momentum-backup",
    version: 1,
    exportedAt: new Date().toISOString(),
    user: { userId, name: ctx.user.name, color: ctx.user.color },
    profile: null,
    habits,
    logs,
    txns,
    xpEvents,
  };
}

/** Replace only the caller's own rows. RLS protects every operation. */
export async function restoreUser(userId: string, dump: BackupDump) {
  const supabase = await ownClient(userId);
  // Child rows first; deleting habits also cascades logs.
  for (const table of ["habit_logs", "wallet_txns", "xp_events", "habits"] as const) {
    const { error } = await supabase.from(table).delete().eq("user_id", userId);
    if (error) supabaseError(error);
  }

  if (dump.habits.length) {
    const { error } = await supabase.from("habits").insert(
      dump.habits.slice(0, 500).map((habit) => ({
        id: habit.id,
        user_id: userId,
        name: String(habit.name).slice(0, 200),
        icon: String(habit.icon).slice(0, 60),
        color: String(habit.color).slice(0, 40),
        sort_order: habit.sortOrder ?? habit.id,
        created_key: habit.createdKey,
      }))
    );
    if (error) supabaseError(error);
  }
  if (dump.logs.length) {
    const { error } = await supabase.from("habit_logs").insert(
      dump.logs.slice(0, 20000).map((log) => ({
        user_id: userId,
        habit_id: log.habitId,
        date: log.date,
        status: log.status,
      }))
    );
    if (error) supabaseError(error);
  }
  if (dump.txns.length) {
    const { error } = await supabase.from("wallet_txns").insert(
      dump.txns.slice(0, 20000).map((txn) => ({
        id: txn.id,
        user_id: userId,
        name: txn.name,
        category: txn.category,
        amount: txn.amount,
        type: txn.type,
        date: txn.date,
        created_at: txn.createdAt,
      }))
    );
    if (error) supabaseError(error);
  }
  if (dump.xpEvents.length) {
    const { error } = await supabase.from("xp_events").insert(
      dump.xpEvents.slice(0, 20000).map((event) => ({
        user_id: userId,
        key: event.key,
        label: event.label,
        amount: event.amount,
        day: event.day,
        at_ms: event.at,
      }))
    );
    if (error) supabaseError(error);
  }
}
