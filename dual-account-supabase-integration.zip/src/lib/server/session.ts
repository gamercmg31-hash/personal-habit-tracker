// Server-only Supabase Auth session verification.

import type { SupabaseClient, User } from "@supabase/supabase-js";
import type { AccountUser } from "@/lib/accounts";
import { getSupabaseServerClient } from "@/lib/supabase/server";
import { accountById } from "@/lib/server/accounts";

export interface SessionContext {
  supabase: SupabaseClient;
  authUser: User;
  user: AccountUser;
}

/** Verify the cookie JWT against Supabase Auth, then load the RLS profile. */
export async function getSessionContext(): Promise<SessionContext | null> {
  const supabase = await getSupabaseServerClient();
  const {
    data: { user: authUser },
    error,
  } = await supabase.auth.getUser();
  if (error || !authUser) return null;
  const user = await accountById(authUser.id, supabase);
  if (!user) return null;
  return { supabase, authUser, user };
}

export async function getSessionUser(): Promise<AccountUser | null> {
  return (await getSessionContext())?.user ?? null;
}
