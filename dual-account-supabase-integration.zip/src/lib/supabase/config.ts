// Public Supabase project configuration. The publishable/anon key is designed
// to be shipped to browsers; database security comes from Auth + RLS.
// No database password and no service-role key are used anywhere in Momentum.

export const SUPABASE_URL =
  process.env.NEXT_PUBLIC_SUPABASE_URL ??
  "https://uxawqcrwbkckhldtdiwv.supabase.co";

export const SUPABASE_PUBLISHABLE_KEY =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ??
  "sb_publishable_nwQK2NJYLlkhAaEOT1xvKQ_jSclb19X";

export function assertSupabaseConfigured() {
  if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
    throw new Error(
      "NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY are required."
    );
  }
}
