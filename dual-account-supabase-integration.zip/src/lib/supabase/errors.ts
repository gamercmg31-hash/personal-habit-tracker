export function supabaseError(error: { message: string; code?: string } | null): never {
  if (!error) throw new Error("Unknown Supabase error.");
  if (error.code === "PGRST205" || error.message.includes("schema cache")) {
    throw new Error(
      "Supabase tables are not installed yet. Run supabase/migrations/0001_momentum_fresh.sql in the Supabase SQL Editor."
    );
  }
  throw new Error(error.message);
}
