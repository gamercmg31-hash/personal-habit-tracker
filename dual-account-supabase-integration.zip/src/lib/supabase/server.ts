import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import { SUPABASE_PUBLISHABLE_KEY, SUPABASE_URL } from "@/lib/supabase/config";

/**
 * Cookie-backed server client. Every table request runs as the signed-in user,
 * so auth.uid() is available to PostgreSQL RLS policies.
 */
export async function getSupabaseServerClient() {
  const store = await cookies();
  return createServerClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    cookies: {
      getAll() {
        return store.getAll();
      },
      setAll(values) {
        try {
          for (const { name, value, options } of values) {
            store.set(name, value, options);
          }
        } catch {
          // Read-only server rendering may not permit cookie writes. Route
          // handlers (the callers here) can write them normally.
        }
      },
    },
  });
}
