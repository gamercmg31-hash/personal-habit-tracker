# Momentum — Personal Habit Tracker (for two)

A private habit tracker for Alex & Sam: daily rituals, streaks, a shared wallet,
and the Ascend leveling system (XP, levels, ranks, daily/weekly quests).

## Architecture (where your data lives)

**All important records live in PostgreSQL — never in the browser.** Updating,
redeploying, or redesigning the site cannot touch your history. The browser only
keeps cosmetic flags (e.g. "celebration already shown today").

| Table          | Contents                                                        |
| -------------- | --------------------------------------------------------------- |
| `profiles`     | One row per account — name, color, seeded flag, settings (jsonb) |
| `habits`       | Rituals, keyed per user with their original numeric ids          |
| `habit_logs`   | Every check-off/skip ever made — the long-term history           |
| `wallet_txns`  | Full income & expense ledger per account                         |
| `xp_events`    | The XP ledger — levels/ranks are derived from these rows         |
| `app_meta`     | App-level bookkeeping                                            |

Design rules baked into the schema:

- **Every row belongs to a `user_id`** — both people's data is isolated forever.
- **Natural composite keys + `ON CONFLICT`** make every write idempotent, so
  retries, double-clicks, re-imports, and redeploys can never duplicate or wipe
  history.
- **Additive-only evolution**: new features add columns/tables, never drop them.

## Auth

Sign-in is verified server-side; the session is an HMAC-signed httpOnly cookie
(survives redeploys). Defaults are the original passwords; rotate them via env:

```
SESSION_SECRET="any-long-random-string"      # signs session cookies
MOMENTUM_PASSWORD_U1="…"                     # Alex
MOMENTUM_PASSWORD_U2="…"                     # Sam
```

## Database changes — safe migration workflow

The project uses Drizzle with versioned SQL migrations in `drizzle/`.
**Never reset the database.** To change the schema:

```bash
# 1. edit src/db/schema.ts (add a table/column — keep existing ones)
# 2. generate a migration (never edit old migration files)
npx drizzle-kit generate --name describe-your-change
# 3. apply it (adds the change, preserves all data)
npx drizzle-kit push
```

Before a risky change, take a backup first (below).

## Backups & restore

Three layers of safety:

1. **In-app (per user)** — Ascend (Leveling) → *Data & backup*: download a full
   JSON snapshot of your own account and restore it from the same panel.
2. **Server script (everything)** — dumps all tables of both users:

   ```bash
   node scripts/backup.mjs   # writes backups/momentum-<timestamp>.json
   ```

3. **Raw PostgreSQL** — full database dump:

   ```bash
   pg_dump "$DATABASE_URL" > backups/momentum-$(date +%F).sql
   ```

## Legacy browser data

On first sign-in, the app automatically imports any pre-database `localStorage`
records (habits, logs, wallet, XP) into PostgreSQL — idempotently, so nothing is
ever duplicated and nothing you already earned is lost.

## Development

```bash
npm run dev        # local dev server
npm run build      # production build
npx tsc --noEmit   # typecheck
```

API surface (all session-scoped, server-verified):

- `POST /api/auth/signin|signout`, `GET /api/auth/me`
- `GET /api/bootstrap` (own data + partner read-only), `GET /api/partner`
- `POST|PATCH|DELETE /api/habits[...]`, `PUT /api/habits/[id]/log`
- `POST|PATCH|DELETE /api/wallet[...]`
- `POST /api/xp/grant` (idempotent by event key)
- `POST /api/import` (one-time legacy bridge)
- `GET /api/backup`, `POST /api/backup/restore`
