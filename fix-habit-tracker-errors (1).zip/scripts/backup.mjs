#!/usr/bin/env node
// ---------------------------------------------------------------------------
// Momentum server-side backup.
//
// Dumps EVERY table (both users) to a timestamped JSON file in ./backups/.
// Safe to run any time; restores are handled per-user inside the app
// (Ascend → Data & backup) or can be re-imported with the app's restore flow.
//
// Usage:  node scripts/backup.mjs
// ---------------------------------------------------------------------------

import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import "dotenv/config";
import pg from "pg";

const __dirname = dirname(fileURLToPath(import.meta.url));

const url = process.env.DATABASE_URL;
if (!url) {
  console.error("DATABASE_URL is required (see .env)");
  process.exit(1);
}

const TABLES = ["profiles", "habits", "habit_logs", "wallet_txns", "xp_events", "app_meta"];

const pool = new pg.Pool({ connectionString: url });
try {
  const dump = {
    format: "momentum-full-backup",
    version: 1,
    exportedAt: new Date().toISOString(),
    tables: {},
  };
  for (const t of TABLES) {
    const { rows } = await pool.query(`SELECT * FROM ${t}`);
    dump.tables[t] = rows;
  }
  const dir = resolve(__dirname, "..", "backups");
  mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const file = resolve(dir, `momentum-${stamp}.json`);
  writeFileSync(file, JSON.stringify(dump, null, 2));
  const counts = TABLES.map((t) => `${t}: ${dump.tables[t].length}`).join(", ");
  console.log(`✓ Backup written to ${file}`);
  console.log(`  ${counts}`);
} finally {
  await pool.end();
}
