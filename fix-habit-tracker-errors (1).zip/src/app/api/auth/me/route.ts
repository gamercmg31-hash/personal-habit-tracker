import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/server/session";
import { ensureProfile } from "@/lib/server/data";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ user: null });
  await ensureProfile(user.id, user.name, user.color);
  return NextResponse.json({ user });
}
