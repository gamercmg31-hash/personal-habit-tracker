import { NextResponse } from "next/server";
import { verifyCredentials } from "@/lib/server/accounts";
import { setSessionCookie } from "@/lib/server/session";
import { ensureProfile } from "@/lib/server/data";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  let body: { key?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Bad request." }, { status: 400 });
  }
  const { key, password } = body;
  if (typeof key !== "string" || typeof password !== "string") {
    return NextResponse.json({ ok: false, error: "Bad request." }, { status: 400 });
  }
  const res = verifyCredentials(key, password);
  if (!res.ok || !res.user) {
    return NextResponse.json(
      { ok: false, error: "Wrong password for that person." },
      { status: 401 }
    );
  }
  await ensureProfile(res.user.id, res.user.name, res.user.color);
  await setSessionCookie(res.user.id);
  return NextResponse.json({ ok: true, user: res.user });
}
