import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/server/session";
import {
  ensureSeeded,
  getHabits,
  getLogs,
  getTxns,
  getXpEvents,
} from "@/lib/server/data";
import { partnerOf } from "@/lib/accounts";

export const dynamic = "force-dynamic";

/**
 * One request to hydrate the whole app: own data + partner read-only.
 * Seeds default rituals on the account's first ever visit.
 */
export async function GET() {
  const me = await getSessionUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await ensureSeeded(me.id);

  const [habits, logs, txns, xpEvts] = await Promise.all([
    getHabits(me.id),
    getLogs(me.id),
    getTxns(me.id),
    getXpEvents(me.id),
  ]);

  const other = partnerOf(me.id);
  const partner = other
    ? {
        user: other,
        slice: {
          seeded: true,
          habits: await getHabits(other.id),
          logs: await getLogs(other.id),
        },
        xp: {
          totalXp: 0,
          events: await getXpEvents(other.id),
        },
      }
    : null;
  if (partner) {
    partner.xp.totalXp = partner.xp.events.reduce((s, e) => s + e.amount, 0);
  }

  return NextResponse.json({
    me,
    slice: { seeded: true, habits, logs },
    txns,
    xp: {
      totalXp: xpEvts.reduce((s, e) => s + e.amount, 0),
      events: xpEvts,
    },
    partner,
  });
}
