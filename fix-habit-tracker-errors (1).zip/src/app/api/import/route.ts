import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/server/session";
import { importLegacy, type ImportPayload } from "@/lib/server/data";

export const dynamic = "force-dynamic";

/**
 * One-time migration of legacy browser (localStorage) data into PostgreSQL.
 * Safe to run any number of times — every insert is ON CONFLICT DO NOTHING,
 * so nothing already in the database is ever overwritten or duplicated.
 */
export async function POST(req: Request) {
  const me = await getSessionUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = (await req.json().catch(() => null)) as ImportPayload | null;
  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "Invalid payload." }, { status: 400 });
  }
  const counts = await importLegacy(me.id, {
    habits: Array.isArray(body.habits) ? body.habits : [],
    logs: Array.isArray(body.logs) ? body.logs : [],
    txns: Array.isArray(body.txns) ? body.txns : [],
    xpEvents: Array.isArray(body.xpEvents) ? body.xpEvents : [],
  });
  return NextResponse.json({ ok: true, imported: counts });
}
