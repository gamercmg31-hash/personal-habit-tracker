import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/server/session";
import { getHabits, getLogs, getXpEvents } from "@/lib/server/data";
import { partnerOf } from "@/lib/accounts";

export const dynamic = "force-dynamic";

/** The other account's data, read-only — powers the partner pulse panels. */
export async function GET() {
  const me = await getSessionUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const other = partnerOf(me.id);
  if (!other) return NextResponse.json({ partner: null });

  const [habits, logs, xpEvts] = await Promise.all([
    getHabits(other.id),
    getLogs(other.id),
    getXpEvents(other.id),
  ]);
  return NextResponse.json({
    partner: {
      user: other,
      slice: { seeded: true, habits, logs },
      xp: {
        totalXp: xpEvts.reduce((s, e) => s + e.amount, 0),
        events: xpEvts,
      },
    },
  });
}
