import { useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Eye, EyeOff, Loader2, Lock, ShieldCheck } from "lucide-react";
import type { AccountUser } from "@/lib/accounts";
import { api } from "@/lib/api";

export default function LoginScreen({
  users,
  onSuccess,
}: {
  users: AccountUser[];
  onSuccess: (user: AccountUser) => void;
}) {
  const [selected, setSelected] = useState<AccountUser | null>(null);
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shake, setShake] = useState(0);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!selected || !password || loading) return;
    setLoading(true);
    setError(null);

    // Brief pause so the "Signing in…" state feels deliberate, then verify
    // against the server (which sets the session cookie).
    window.setTimeout(() => {
      api<{ ok: boolean; user: AccountUser }>("/api/auth/signin", {
        method: "POST",
        body: JSON.stringify({ key: selected.key, password }),
      })
        .then((res) => {
          onSuccess(res.user);
        })
        .catch((err) => {
          setError(err instanceof Error ? err.message : "Could not sign in.");
          setShake((s) => s + 1);
          setLoading(false);
        });
    }, 420);
  };

  return (
    <main className="relative grid min-h-screen place-items-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-md"
      >
        {/* brand */}
        <div className="mb-8 text-center">
          <motion.div
            initial={{ scale: 0, rotate: -20 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 18, delay: 0.15 }}
            className="mx-auto grid size-14 place-items-center rounded-2xl bg-lime-400 text-lime-950 shadow-[0_0_40px_rgba(163,230,53,0.4)]"
          >
            <Check size={30} strokeWidth={3.2} />
          </motion.div>
          <h1 className="font-display mt-5 text-3xl font-semibold tracking-tight text-white">
            Momentum
          </h1>
          <p className="mt-1.5 text-sm text-zinc-500">
            A private habit tracker for two. Who’s tracking today?
          </p>
        </div>

        <motion.div
          key={shake}
          animate={shake > 0 ? { x: [0, -9, 9, -6, 6, 0] } : false}
          transition={{ duration: 0.4 }}
          className="rounded-3xl border border-white/[0.08] bg-white/[0.03] p-6 backdrop-blur sm:p-7"
        >
          {/* user picker */}
          <div className="grid grid-cols-2 gap-3">
            {users.map((u, i) => {
              const active = selected?.id === u.id;
              return (
                <motion.button
                  key={u.id}
                  type="button"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.25 + i * 0.08 }}
                  onClick={() => {
                    setSelected(u);
                    setError(null);
                  }}
                  className={`group flex flex-col items-center gap-2.5 rounded-2xl border px-4 py-5 transition-all ${
                    active
                      ? "border-transparent bg-white/[0.06]"
                      : "border-white/[0.07] bg-white/[0.02] hover:border-white/[0.16] hover:bg-white/[0.05]"
                  }`}
                  style={active ? { boxShadow: `0 0 0 2px ${u.color}, 0 12px 36px ${u.color}33` } : undefined}
                >
                  <span
                    className="font-display grid size-12 place-items-center rounded-full text-lg font-semibold text-zinc-950 transition-transform group-hover:scale-105"
                    style={{ background: u.color }}
                  >
                    {u.name.charAt(0).toUpperCase()}
                  </span>
                  <span className={`text-sm font-medium ${active ? "text-white" : "text-zinc-300"}`}>
                    {u.name}
                  </span>
                  <span className="sr-only">Sign in as {u.name}</span>
                </motion.button>
              );
            })}
          </div>

          <AnimatePresence>
            {selected && (
              <motion.form
                key={selected.id}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                onSubmit={submit}
                className="overflow-hidden"
              >
                <div className="pt-5">
                  <label
                    htmlFor="login-password"
                    className="text-[11px] font-semibold tracking-[0.16em] text-zinc-500 uppercase"
                  >
                    {selected.name}’s password
                  </label>
                  <div className="relative mt-2">
                    <Lock size={15} className="absolute top-1/2 left-4 -translate-y-1/2 text-zinc-500" />
                    <input
                      id="login-password"
                      type={showPw ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      autoFocus
                      autoComplete="current-password"
                      placeholder="Enter password"
                      className="w-full rounded-xl border border-white/10 bg-white/[0.04] py-3 pr-12 pl-11 text-[15px] text-white placeholder-zinc-600 transition outline-none focus:border-lime-400/50 focus:ring-2 focus:ring-lime-400/20"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPw((v) => !v)}
                      aria-label={showPw ? "Hide password" : "Show password"}
                      className="absolute top-1/2 right-3 grid size-8 -translate-y-1/2 place-items-center rounded-full text-zinc-500 transition hover:text-white"
                    >
                      {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>

                  {error && (
                    <motion.p
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-2.5 text-xs font-medium text-rose-400"
                    >
                      {error}
                    </motion.p>
                  )}

                  <button
                    type="submit"
                    disabled={!password || loading}
                    className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-lime-400 py-3 text-sm font-semibold text-lime-950 transition hover:bg-lime-300 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    {loading ? <Loader2 size={16} className="animate-spin" /> : <ShieldCheck size={16} />}
                    {loading ? "Signing in…" : `Continue as ${selected.name}`}
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          <p className="mt-5 rounded-xl border border-white/[0.07] bg-white/[0.02] px-4 py-3 text-center text-[11px] leading-relaxed text-zinc-500">
            Local preview accounts —{" "}
            <span className="font-semibold text-zinc-300">{users[0]?.name ?? "User 1"}: momentum1</span>
            {" · "}
            <span className="font-semibold text-zinc-300">{users[1]?.name ?? "User 2"}: momentum2</span>
          </p>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-6 flex items-center justify-center gap-1.5 text-center text-[11px] tracking-wide text-zinc-600"
        >
          <Lock size={11} />
          Private space · 2 people only · no public profiles, followers, or leaderboards
        </motion.p>
      </motion.div>
    </main>
  );
}
