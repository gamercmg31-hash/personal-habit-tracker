import {
  bigint,
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  text,
  timestamp,
  doublePrecision,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Momentum — persistent data model.
//
// Design rules:
//   · every row belongs to a userId — both people's data lives side by side,
//     fully isolated, forever
//   · natural/composite primary keys make every write idempotent, so imports,
//     retries and re-deploys can never duplicate or wipe history
//   · additive-only changes: new features extend this schema, existing columns
//     are never dropped — pair every change with `npx drizzle-kit generate`
// ---------------------------------------------------------------------------

/** One row per account — profile + extensible settings bag for future features. */
export const profiles = pgTable("profiles", {
  userId: text("user_id").primaryKey(),
  name: text("name").notNull(),
  color: text("color").notNull(),
  /** default rituals are seeded exactly once, then this flips true forever */
  seeded: boolean("seeded").notNull().default(false),
  /** free-form per-user settings (theme, preferences…) without schema churn */
  settings: jsonb("settings").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

/** Rituals. The per-user numeric id matches what the client has always used. */
export const habits = pgTable(
  "habits",
  {
    userId: text("user_id").notNull(),
    id: integer("id").notNull(),
    name: text("name").notNull(),
    icon: text("icon").notNull(),
    color: text("color").notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
    /** local date key (YYYY-MM-DD) the habit was created on */
    createdKey: text("created_key").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.id] })]
);

/** Daily check-off history — the long-term record that must never be lost. */
export const habitLogs = pgTable(
  "habit_logs",
  {
    userId: text("user_id").notNull(),
    habitId: integer("habit_id").notNull(),
    /** local date key (YYYY-MM-DD) */
    date: text("date").notNull(),
    status: text("status").notNull(), // 'completed' | 'skipped'
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    primaryKey({ columns: [t.userId, t.habitId, t.date] }),
    index("habit_logs_user_date_idx").on(t.userId, t.date),
  ]
);

/** Wallet ledger — full income/expense history per account. */
export const walletTxns = pgTable(
  "wallet_txns",
  {
    /** client-generated uuid */
    id: text("id").primaryKey(),
    userId: text("user_id").notNull(),
    name: text("name").notNull(),
    category: text("category").notNull(),
    amount: doublePrecision("amount").notNull(),
    type: text("type").notNull(), // 'income' | 'expense'
    /** local date key (YYYY-MM-DD) */
    date: text("date").notNull(),
    /** epoch ms, preserved from the client for stable ordering */
    createdAt: bigint("created_at", { mode: "number" }).notNull(),
  },
  (t) => [index("wallet_txns_user_idx").on(t.userId)]
);

/**
 * XP ledger — every award ever earned. The event key is the idempotency
 * guard: one award per key per user, forever. Total XP and levels are derived
 * from this table, so progression can be rebuilt at any time.
 */
export const xpEvents = pgTable(
  "xp_events",
  {
    userId: text("user_id").notNull(),
    key: text("key").notNull(),
    label: text("label").notNull(),
    amount: integer("amount").notNull(),
    /** local date key the XP was earned on */
    day: text("day").notNull(),
    /** epoch ms */
    at: bigint("at", { mode: "number" }).notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.userId, t.key] }),
    index("xp_events_user_day_idx").on(t.userId, t.day),
  ]
);

/** Simple key/value table for app-level bookkeeping (schema markers, etc.). */
export const appMeta = pgTable("app_meta", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
