// ---------------------------------------------------------------------------
// Account identities — public, non-secret info (safe for client bundles).
// Passwords live ONLY on the server (src/lib/server/accounts.ts).
// ---------------------------------------------------------------------------

export interface AccountUser {
  id: string;
  key: string;
  name: string;
  color: string;
}

export const LOGIN_USERS: AccountUser[] = [
  { id: "u1", key: "u1", name: "Alex", color: "#a3e635" },
  { id: "u2", key: "u2", name: "Sam", color: "#38bdf8" },
];

export function partnerOf(userId: string): AccountUser | null {
  const other = LOGIN_USERS.find((u) => u.id !== userId);
  return other ?? null;
}

export function accountById(userId: string): AccountUser | null {
  return LOGIN_USERS.find((u) => u.id === userId) ?? null;
}
