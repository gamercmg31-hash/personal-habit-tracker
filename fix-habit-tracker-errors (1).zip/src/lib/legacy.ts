// ---------------------------------------------------------------------------
// One-time bridge: reads any pre-database (localStorage) data this browser
// still holds, so it can be imported into PostgreSQL. The originals are left
// untouched as an emergency local copy — the database is the source of truth.
// ---------------------------------------------------------------------------

import type { HabitRecord, LogRecord } from "@/lib/types";
import type { Txn } from "@/lib/wallet";
import type { XpEvent } from "@/lib/xp";

export interface LegacyData {
  habits: HabitRecord[];
  logs: LogRecord[];
  txns: Txn[];
  xpEvents: XpEvent[];
}

const importedFlag = (userId: string) => `momentum:db-imported:v1:${userId}`;

export function alreadyImported(userId: string): boolean {
  try {
    return localStorage.getItem(importedFlag(userId)) === "1";
  } catch {
    return false;
  }
}

export function markImported(userId: string) {
  try {
    localStorage.setItem(importedFlag(userId), "1");
  } catch {
    /* private mode — import stays idempotent server-side anyway */
  }
}

function readJson<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

/** Collect everything the old localStorage era may have stored for this user. */
export function readLegacyData(userId: string): LegacyData {
  const out: LegacyData = { habits: [], logs: [], txns: [], xpEvents: [] };
  if (typeof window === "undefined") return out;

  // habits + logs (momentum:data:v2:{userId})
  const slice = readJson<{ habits?: HabitRecord[]; logs?: LogRecord[] }>(
    `momentum:data:v2:${userId}`
  );
  if (slice && Array.isArray(slice.habits)) out.habits = slice.habits;
  if (slice && Array.isArray(slice.logs)) out.logs = slice.logs;

  // wallet — per-user v2 first, then the original shared v1 (claimed once)
  const v2 = readJson<{ txns?: Txn[] }>(`momentum:wallet:v2:${userId}`);
  if (v2 && Array.isArray(v2.txns) && v2.txns.length) {
    out.txns = v2.txns;
  } else {
    const v1 = readJson<{ txns?: Txn[] }>("momentum:wallet:v1");
    if (v1 && Array.isArray(v1.txns) && v1.txns.length) {
      out.txns = v1.txns;
      // claimed — don't hand the shared wallet to the second account later
      try {
        localStorage.setItem(
          `momentum:wallet:v1-claimed-by:${userId}`,
          new Date().toISOString()
        );
        localStorage.removeItem("momentum:wallet:v1");
      } catch {
        /* ignore */
      }
    }
  }

  // xp events (momentum:xp:v1:{userId})
  const xp = readJson<{ totalXp?: number; events?: XpEvent[] }>(
    `momentum:xp:v1:${userId}`
  );
  if (xp && Array.isArray(xp.events)) out.xpEvents = xp.events;

  return out;
}

/** True when this browser holds anything worth importing for the user. */
export function hasLegacyData(userId: string): boolean {
  if (alreadyImported(userId)) return false;
  const d = readLegacyData(userId);
  return (
    d.habits.length > 0 ||
    d.logs.length > 0 ||
    d.txns.length > 0 ||
    d.xpEvents.length > 0
  );
}
