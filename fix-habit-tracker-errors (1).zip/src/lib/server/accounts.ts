// Server-only: credential verification. Never imported by client bundles.
//
// Passwords default to the original credentials so nothing changes for the
// two of you, and can be rotated any time via environment variables without
// touching the database:
//   MOMENTUM_PASSWORD_U1="…"  MOMENTUM_PASSWORD_U2="…"

import { LOGIN_USERS, type AccountUser } from "@/lib/accounts";

const PASSWORDS: Record<string, string | undefined> = {
  u1: process.env.MOMENTUM_PASSWORD_U1,
  u2: process.env.MOMENTUM_PASSWORD_U2,
};

const DEFAULTS: Record<string, string> = {
  u1: "momentum1",
  u2: "momentum2",
};

export function verifyCredentials(
  key: string,
  password: string
): { ok: boolean; user?: AccountUser } {
  const user = LOGIN_USERS.find((u) => u.key === key);
  if (!user) return { ok: false };
  const expected = PASSWORDS[user.id] ?? DEFAULTS[user.id];
  if (!expected || password !== expected) return { ok: false };
  return { ok: true, user };
}
