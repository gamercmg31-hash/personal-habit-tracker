// Server-only data layer — the single place that talks to PostgreSQL.
// Every mutation is scoped by userId (from the session, never from the
// client) and every insert is idempotent via natural keys / ON CONFLICT.

import { and, asc, desc, eq, max, sql } from "drizzle-orm";
import { db } from "@/db";
import { habitLogs, habits, profiles, walletTxns, xpEvents } from "@/db/schema";
import { dateKey } from "@/lib/dates";
import type { HabitRecord, LogRecord, LogStatusValue } from "@/lib/types";
import type { Txn } from "@/lib/wallet";
import type { XpEvent } from "@/lib/xp";
import { DEFAULT_HABITS } from "@/lib/visuals";

/* ---- profiles -------------------------------------------------------------- */

export async function ensureProfile(
  userId: string,
  name: string,
  color: string
) {
  await db
    .insert(profiles)
    .values({ userId, name, color, seeded: false })
    .onConflictDoNothing();
}

/* ---- habits + logs ----------------------------------------------------------- */

function habitRow(r: typeof habits.$inferSelect): HabitRecord {
  return {
    id: r.id,
    userId: r.userId,
    name: r.name,
    icon: r.icon,
    color: r.color,
    sortOrder: r.sortOrder,
    createdKey: r.createdKey,
  };
}

export async function getHabits(userId: string): Promise<HabitRecord[]> {
  const rows = await db
    .select()
    .from(habits)
    .where(eq(habits.userId, userId))
    .orderBy(asc(habits.sortOrder), asc(habits.id));
  return rows.map(habitRow);
}

export async function getLogs(userId: string): Promise<LogRecord[]> {
  const rows = await db
    .select()
    .from(habitLogs)
    .where(eq(habitLogs.userId, userId))
    .orderBy(asc(habitLogs.date));
  return rows.map((r) => ({
    habitId: r.habitId,
    userId: r.userId,
    date: r.date,
    status: r.status as LogStatusValue,
  }));
}

/** Seed the default rituals exactly once per account (flagged in profiles). */
export async function ensureSeeded(userId: string): Promise<void> {
  const [profile] = await db
    .select({ seeded: profiles.seeded })
    .from(profiles)
    .where(eq(profiles.userId, userId));
  if (!profile || profile.seeded) return;

  const todayKey = dateKey(new Date());
  await db.transaction(async (tx) => {
    const existing = await tx
      .select({ id: habits.id })
      .from(habits)
      .where(eq(habits.userId, userId))
      .limit(1);
    if (existing.length === 0) {
      await tx.insert(habits).values(
        DEFAULT_HABITS.map((h, i) => ({
          userId,
          id: i + 1,
          name: h.name,
          icon: h.icon,
          color: h.color,
          sortOrder: i + 1,
          createdKey: todayKey,
        }))
      );
    }
    await tx
      .update(profiles)
      .set({ seeded: true, updatedAt: new Date() })
      .where(eq(profiles.userId, userId));
  });
}

export async function createHabit(
  userId: string,
  input: { name: string; icon: string; color: string }
): Promise<HabitRecord> {
  const todayKey = dateKey(new Date());
  const [row] = await db.transaction(async (tx) => {
    const [idRow] = await tx
      .select({ value: max(habits.id) })
      .from(habits)
      .where(eq(habits.userId, userId));
    const [sortRow] = await tx
      .select({ value: max(habits.sortOrder) })
      .from(habits)
      .where(eq(habits.userId, userId));
    const id = (idRow?.value ?? 0) + 1;
    const sortOrder = (sortRow?.value ?? 0) + 1;
    return tx
      .insert(habits)
      .values({ userId, id, sortOrder, createdKey: todayKey, ...input })
      .returning();
  });
  return habitRow(row);
}

export async function updateHabit(
  userId: string,
  habitId: number,
  patch: { name?: string; icon?: string; color?: string }
): Promise<void> {
  await db
    .update(habits)
    .set(patch)
    .where(and(eq(habits.userId, userId), eq(habits.id, habitId)));
}

export async function deleteHabit(userId: string, habitId: number) {
  await db.transaction(async (tx) => {
    await tx
      .delete(habitLogs)
      .where(and(eq(habitLogs.userId, userId), eq(habitLogs.habitId, habitId)));
    await tx
      .delete(habits)
      .where(and(eq(habits.userId, userId), eq(habits.id, habitId)));
  });
}

/** status null = un-mark (delete the row); otherwise upsert the day record. */
export async function setLog(
  userId: string,
  habitId: number,
  date: string,
  status: LogStatusValue | null
): Promise<void> {
  // ownership guard — never let one account write another's habit
  const [own] = await db
    .select({ id: habits.id })
    .from(habits)
    .where(and(eq(habits.userId, userId), eq(habits.id, habitId)))
    .limit(1);
  if (!own) return;

  if (status === null) {
    await db
      .delete(habitLogs)
      .where(
        and(
          eq(habitLogs.userId, userId),
          eq(habitLogs.habitId, habitId),
          eq(habitLogs.date, date)
        )
      );
    return;
  }
  await db
    .insert(habitLogs)
    .values({ userId, habitId, date, status, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: [habitLogs.userId, habitLogs.habitId, habitLogs.date],
      set: { status, updatedAt: new Date() },
    });
}

/* ---- wallet -------------------------------------------------------------------- */

function txnRow(r: typeof walletTxns.$inferSelect): Txn {
  return {
    id: r.id,
    name: r.name,
    category: r.category,
    amount: r.amount,
    type: r.type as Txn["type"],
    date: r.date,
    createdAt: Number(r.createdAt),
  };
}

export async function getTxns(userId: string): Promise<Txn[]> {
  const rows = await db
    .select()
    .from(walletTxns)
    .where(eq(walletTxns.userId, userId))
    .orderBy(desc(walletTxns.createdAt));
  return rows.map(txnRow);
}

export async function createTxn(userId: string, t: Txn): Promise<Txn> {
  const [row] = await db
    .insert(walletTxns)
    .values({ ...t, userId })
    .onConflictDoUpdate({
      target: walletTxns.id,
      set: {
        name: t.name,
        category: t.category,
        amount: t.amount,
        type: t.type,
        date: t.date,
      },
    })
    .returning();
  return txnRow(row);
}

export async function updateTxn(
  userId: string,
  id: string,
  patch: Partial<Omit<Txn, "id" | "createdAt">>
): Promise<void> {
  await db
    .update(walletTxns)
    .set(patch)
    .where(and(eq(walletTxns.id, id), eq(walletTxns.userId, userId)));
}

export async function deleteTxn(userId: string, id: string): Promise<void> {
  await db
    .delete(walletTxns)
    .where(and(eq(walletTxns.id, id), eq(walletTxns.userId, userId)));
}

/* ---- XP ------------------------------------------------------------------------- */

function xpRow(r: typeof xpEvents.$inferSelect): XpEvent {
  return {
    key: r.key,
    label: r.label,
    amount: r.amount,
    at: Number(r.at),
    day: r.day,
  };
}

export async function getXpEvents(userId: string): Promise<XpEvent[]> {
  const rows = await db
    .select()
    .from(xpEvents)
    .where(eq(xpEvents.userId, userId))
    .orderBy(asc(xpEvents.at));
  return rows.map(xpRow);
}

export interface ServerGrant {
  key: string;
  label: string;
  amount: number;
}

/**
 * Idempotent XP grant: only keys that don't exist yet are inserted.
 * Returns the actually-gained events and the user's new total XP.
 */
export async function grantXp(
  userId: string,
  grants: ServerGrant[],
  day: string,
  nowMs: number
): Promise<{ gained: XpEvent[]; totalXp: number }> {
  const clean = grants.filter(
    (g) =>
      g &&
      typeof g.key === "string" &&
      g.key.length > 0 &&
      g.key.length < 300 &&
      typeof g.amount === "number" &&
      Number.isFinite(g.amount) &&
      g.amount > 0 &&
      g.amount <= 10000 &&
      typeof g.label === "string"
  );
  if (clean.length === 0) {
    const [{ total }] = await db
      .select({ total: sql<number>`coalesce(sum(${xpEvents.amount}),0)::int` })
      .from(xpEvents)
      .where(eq(xpEvents.userId, userId));
    return { gained: [], totalXp: total };
  }

  const gained = await db.transaction(async (tx) => {
    const inserted: XpEvent[] = [];
    for (const [i, g] of clean.entries()) {
      const rows = await tx
        .insert(xpEvents)
        .values({
          userId,
          key: g.key,
          label: g.label.slice(0, 300),
          amount: Math.round(g.amount),
          day,
          at: nowMs + i,
        })
        .onConflictDoNothing()
        .returning();
      if (rows[0]) inserted.push(xpRow(rows[0]));
    }
    return inserted;
  });

  const [{ total }] = await db
    .select({ total: sql<number>`coalesce(sum(${xpEvents.amount}),0)::int` })
    .from(xpEvents)
    .where(eq(xpEvents.userId, userId));
  return { gained, totalXp: total };
}

/* ---- legacy import (one-time, localStorage → PostgreSQL) --------------------------- */

export interface ImportPayload {
  habits?: HabitRecord[];
  logs?: LogRecord[];
  txns?: Txn[];
  xpEvents?: XpEvent[];
}

/**
 * Bulk-upsert legacy browser data. Every insert uses ON CONFLICT DO NOTHING,
 * so it is safe to run repeatedly — existing history is never overwritten.
 */
export async function importLegacy(userId: string, payload: ImportPayload) {
  const counts = { habits: 0, logs: 0, txns: 0, xpEvents: 0 };

  const hs = (payload.habits ?? []).filter(
    (h) => h && Number.isInteger(h.id) && h.name && h.createdKey
  );
  const ls = (payload.logs ?? []).filter(
    (l) =>
      l &&
      Number.isInteger(l.habitId) &&
      typeof l.date === "string" &&
      (l.status === "completed" || l.status === "skipped")
  );
  const ts = (payload.txns ?? []).filter(
    (t) => t && typeof t.id === "string" && typeof t.amount === "number"
  );
  const xs = (payload.xpEvents ?? []).filter(
    (e) => e && typeof e.key === "string" && typeof e.amount === "number"
  );

  await db.transaction(async (tx) => {
    for (const h of hs.slice(0, 500)) {
      const r = await tx
        .insert(habits)
        .values({
          userId,
          id: h.id,
          name: String(h.name).slice(0, 200),
          icon: String(h.icon).slice(0, 60),
          color: String(h.color).slice(0, 40),
          sortOrder: h.sortOrder ?? h.id,
          createdKey: h.createdKey,
        })
        .onConflictDoNothing()
        .returning({ id: habits.id });
      if (r.length) counts.habits++;
    }
    for (const l of ls.slice(0, 20000)) {
      const r = await tx
        .insert(habitLogs)
        .values({
          userId,
          habitId: l.habitId,
          date: l.date,
          status: l.status,
          updatedAt: new Date(),
        })
        .onConflictDoNothing()
        .returning({ habitId: habitLogs.habitId });
      if (r.length) counts.logs++;
    }
    for (const t of ts.slice(0, 20000)) {
      const r = await tx
        .insert(walletTxns)
        .values({
          id: t.id.slice(0, 80),
          userId,
          name: String(t.name).slice(0, 200),
          category: String(t.category).slice(0, 60),
          amount: t.amount,
          type: t.type === "income" ? "income" : "expense",
          date: t.date,
          createdAt: t.createdAt || Date.now(),
        })
        .onConflictDoNothing()
        .returning({ id: walletTxns.id });
      if (r.length) counts.txns++;
    }
    for (const e of xs.slice(0, 20000)) {
      const r = await tx
        .insert(xpEvents)
        .values({
          userId,
          key: e.key.slice(0, 300),
          label: String(e.label).slice(0, 300),
          amount: Math.round(e.amount),
          day: typeof e.day === "string" ? e.day : dateKey(new Date(e.at || Date.now())),
          at: e.at || Date.now(),
        })
        .onConflictDoNothing()
        .returning({ key: xpEvents.key });
      if (r.length) counts.xpEvents++;
    }
  });

  return counts;
}

/* ---- backup / restore ---------------------------------------------------------------- */

export interface BackupDump {
  format: "momentum-backup";
  version: 1;
  exportedAt: string;
  user: { userId: string; name: string; color: string };
  profile: Record<string, unknown> | null;
  habits: HabitRecord[];
  logs: LogRecord[];
  txns: Txn[];
  xpEvents: XpEvent[];
}

export async function exportUser(userId: string): Promise<BackupDump> {
  const [profile] = await db
    .select()
    .from(profiles)
    .where(eq(profiles.userId, userId));
  const hs = await getHabits(userId);
  const ls = await getLogs(userId);
  const ts = await getTxns(userId);
  const xs = await getXpEvents(userId);
  return {
    format: "momentum-backup",
    version: 1,
    exportedAt: new Date().toISOString(),
    user: profile
      ? { userId: profile.userId, name: profile.name, color: profile.color }
      : { userId, name: userId, color: "#a3e635" },
    profile: (profile?.settings as Record<string, unknown>) ?? null,
    habits: hs,
    logs: ls,
    txns: ts,
    xpEvents: xs,
  };
}

/**
 * Restore replaces the account's current data with the dump — intentionally,
 * inside one transaction. Only ever touches the signed-in user's own rows.
 */
export async function restoreUser(userId: string, dump: BackupDump) {
  await db.transaction(async (tx) => {
    await tx.delete(habitLogs).where(eq(habitLogs.userId, userId));
    await tx.delete(habits).where(eq(habits.userId, userId));
    await tx.delete(walletTxns).where(eq(walletTxns.userId, userId));
    await tx.delete(xpEvents).where(eq(xpEvents.userId, userId));

    for (const h of dump.habits ?? []) {
      await tx
        .insert(habits)
        .values({
          userId,
          id: h.id,
          name: String(h.name).slice(0, 200),
          icon: String(h.icon).slice(0, 60),
          color: String(h.color).slice(0, 40),
          sortOrder: h.sortOrder ?? h.id,
          createdKey: h.createdKey,
        })
        .onConflictDoNothing();
    }
    for (const l of dump.logs ?? []) {
      await tx
        .insert(habitLogs)
        .values({
          userId,
          habitId: l.habitId,
          date: l.date,
          status: l.status,
          updatedAt: new Date(),
        })
        .onConflictDoNothing();
    }
    for (const t of dump.txns ?? []) {
      await tx
        .insert(walletTxns)
        .values({ ...t, id: t.id.slice(0, 80), userId })
        .onConflictDoNothing();
    }
    for (const e of dump.xpEvents ?? []) {
      await tx
        .insert(xpEvents)
        .values({
          userId,
          key: e.key.slice(0, 300),
          label: String(e.label).slice(0, 300),
          amount: Math.round(e.amount),
          day: e.day,
          at: e.at,
        })
        .onConflictDoNothing();
    }
    await tx
      .update(profiles)
      .set({ seeded: true, updatedAt: new Date() })
      .where(eq(profiles.userId, userId));
  });
}
