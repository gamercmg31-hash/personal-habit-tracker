// Server-only: HMAC-signed session cookies.
//
// The cookie value is `userId.signature` — stateless, tamper-proof, and it
// survives redeploys (unlike in-memory sessions). Rotate SESSION_SECRET via
// the environment to invalidate all sessions at once.

import crypto from "node:crypto";
import { cookies } from "next/headers";
import { accountById, type AccountUser } from "@/lib/accounts";

const SECRET =
  process.env.SESSION_SECRET ?? "momentum-dev-secret-set-SESSION_SECRET";

export const SESSION_COOKIE = "momentum_session";
const MAX_AGE_S = 60 * 60 * 24 * 365; // 1 year — this is a 2-person private app

function sign(userId: string): string {
  return crypto.createHmac("sha256", SECRET).update(userId).digest("base64url");
}

export function encodeSession(userId: string): string {
  return `${userId}.${sign(userId)}`;
}

export function decodeSession(value: string | undefined): string | null {
  if (!value) return null;
  const idx = value.indexOf(".");
  if (idx <= 0) return null;
  const userId = value.slice(0, idx);
  const expected = encodeSession(userId);
  // timing-safe comparison, padded to equal length
  const a = Buffer.from(value);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  return accountById(userId) ? userId : null;
}

export async function setSessionCookie(userId: string) {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, encodeSession(userId), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: MAX_AGE_S,
  });
}

export async function clearSessionCookie() {
  const jar = await cookies();
  jar.delete(SESSION_COOKIE);
}

/** The signed-in account, or null. Used by every data route. */
export async function getSessionUser(): Promise<AccountUser | null> {
  const jar = await cookies();
  const userId = decodeSession(jar.get(SESSION_COOKIE)?.value);
  return userId ? accountById(userId) : null;
}
