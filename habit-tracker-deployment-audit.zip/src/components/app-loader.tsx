"use client";

import dynamic from "next/dynamic";

// The app is a fully client-side experience backed by localStorage.
// Rendering it without SSR avoids hydration mismatches for returning
// sessions (server has no localStorage, client may have one saved).
const App = dynamic(() => import("@/components/app"), {
  ssr: false,
  loading: () => (
    <div className="fixed inset-0 bg-[#0a0a0c]" aria-hidden />
  ),
});

export default function AppLoader() {
  return <App />;
}
