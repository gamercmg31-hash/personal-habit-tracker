// ---------------------------------------------------------------------------
// Account identities — public, non-secret info (safe for client bundles).
//
// Accounts are NOT hardcoded: the two owners create them themselves via the
// account-creation page. The list of accounts lives in PostgreSQL and is
// exposed to the client (without secrets) through GET /api/accounts.
// ---------------------------------------------------------------------------

export interface AccountUser {
  id: string;
  key: string;
  name: string;
  color: string;
}

/** This is a private tracker for exactly two people — never more. */
export const MAX_ACCOUNTS = 2;

/** Stable ids assigned in creation order. */
export const ACCOUNT_IDS = ["u1", "u2"] as const;

/** Display color assigned by creation order (overridable at creation). */
export const ACCOUNT_COLORS = ["#a3e635", "#38bdf8"] as const;

/** Palette offered on the account-creation page. */
export const ACCOUNT_COLOR_CHOICES = [
  "#a3e635",
  "#38bdf8",
  "#f472b6",
  "#fbbf24",
  "#a78bfa",
  "#34d399",
  "#fb7185",
  "#22d3ee",
] as const;

/** Shape returned by GET /api/accounts. */
export interface AccountsState {
  accounts: AccountUser[];
  /** how many slots are still open (0 → creation closed) */
  slotsOpen: number;
  maxAccounts: number;
}

export function nameKey(name: string): string {
  return name.trim().toLowerCase().replace(/\s+/g, " ");
}
