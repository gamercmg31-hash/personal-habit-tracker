// Provisions the two private users in your Supabase project.
//
// 1. Run supabase/schema.sql in the Supabase SQL Editor first.
// 2. Then run:
//      NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co \
//      SUPABASE_SERVICE_ROLE_KEY=eyJ... \
//      node scripts/supabase-setup.mjs
//
// Optional overrides:
//   APP_USER1_NAME / APP_USER2_NAME     display names (default: Alex / Sam)
//   APP_USER1_EMAIL / APP_USER2_EMAIL   login emails
//   APP_USER1_PASSWORD / APP_USER2_PASSWORD   login passwords

import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!url || !serviceKey) {
  console.error("Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY first.");
  process.exit(1);
}

const USERS = [
  {
    email: process.env.APP_USER1_EMAIL || "user1@momentum.app",
    password: process.env.APP_USER1_PASSWORD || "momentum1",
    name: process.env.APP_USER1_NAME || "Alex",
    color: "#a3e635",
  },
  {
    email: process.env.APP_USER2_EMAIL || "user2@momentum.app",
    password: process.env.APP_USER2_PASSWORD || "momentum2",
    name: process.env.APP_USER2_NAME || "Sam",
    color: "#38bdf8",
  },
];

const admin = createClient(url, serviceKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});

for (const u of USERS) {
  let userId;

  const { data, error } = await admin.auth.admin.createUser({
    email: u.email,
    password: u.password,
    email_confirm: true,
    user_metadata: { name: u.name },
  });

  if (error) {
    // Already registered? Find the existing user instead.
    const { data: list } = await admin.auth.admin.listUsers({ perPage: 200 });
    const existing = list?.users?.find((x) => x.email === u.email);
    if (!existing) {
      console.error(`Failed to create ${u.email}:`, error.message);
      process.exit(1);
    }
    userId = existing.id;
    console.log(`~ ${u.email} already exists (id ${userId}) — keeping as is`);
  } else {
    userId = data.user.id;
    console.log(`+ created ${u.email} (id ${userId})`);
  }

  const { error: pErr } = await admin.from("profiles").upsert({
    id: userId,
    email: u.email,
    name: u.name,
    color: u.color,
  });
  if (pErr) {
    console.error(`Failed to upsert profile for ${u.email}:`, pErr.message);
    process.exit(1);
  }
}

console.log("Done. Both users can now sign in to Momentum.");
