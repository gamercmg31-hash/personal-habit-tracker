import { NextRequest } from "next/server";
import { redirect } from "next/navigation";
import { backend } from "@/lib/backend";

export const dynamic = "force-dynamic";

/**
 * Bounce route: sends signed-in users to their target page, auto-signs-in
 * the default local user (preview convenience), otherwise goes to /login.
 * Cookie writing happens here (a route handler), since Server Components
 * can't set cookies. Redirects are relative so the cookie is always sent
 * to the same host the visitor used.
 */
export async function GET(req: NextRequest) {
  const nextParam = req.nextUrl.searchParams.get("next");
  const target =
    nextParam && nextParam.startsWith("/") && !nextParam.startsWith("//") ? nextParam : "/";

  const be = backend();
  const existing = await be.getUser();
  if (existing) redirect(target);

  const auto = await be.autoSignIn();
  if (auto) redirect(target);

  redirect("/login");
}
