import { NextRequest, NextResponse } from "next/server";
import { backend } from "@/lib/backend";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const key = typeof body?.key === "string" ? body.key.trim() : "";
  const password = typeof body?.password === "string" ? body.password : "";

  if (!key || !password) {
    return NextResponse.json({ error: "Pick a person and enter the password." }, { status: 400 });
  }

  const result = await backend().signIn(key, password);
  if (!result.ok) {
    return NextResponse.json({ error: result.error ?? "Sign in failed." }, { status: 401 });
  }
  return NextResponse.json({ ok: true });
}
