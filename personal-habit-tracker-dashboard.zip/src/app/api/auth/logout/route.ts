import { NextResponse } from "next/server";
import { backend } from "@/lib/backend";

export const dynamic = "force-dynamic";

export async function POST() {
  await backend().signOut();
  return NextResponse.json({ ok: true });
}
