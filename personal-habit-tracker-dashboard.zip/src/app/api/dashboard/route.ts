import { NextResponse } from "next/server";
import { backend, buildDashboard } from "@/lib/backend";

export const dynamic = "force-dynamic";

export async function GET() {
  const me = await backend().getUser();
  if (!me) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }
  const data = await buildDashboard(me);
  return NextResponse.json(data);
}
