import { NextRequest, NextResponse } from "next/server";
import { backend, buildDashboard } from "@/lib/backend";
import { COLOR_KEYS, ICON_KEYS } from "@/lib/visuals";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

async function parseId(ctx: Ctx): Promise<number | null> {
  const { id } = await ctx.params;
  const n = Number(id);
  return Number.isInteger(n) && n > 0 ? n : null;
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  const me = await backend().getUser();
  if (!me) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const id = await parseId(ctx);
  if (!id) return NextResponse.json({ error: "Invalid habit id." }, { status: 400 });

  const body = await req.json().catch(() => null);
  const patch: { name?: string; icon?: string; color?: string } = {};

  if (typeof body?.name === "string") {
    const name = body.name.trim();
    if (!name || name.length > 140) {
      return NextResponse.json(
        { error: "A habit name between 1 and 140 characters is required." },
        { status: 400 }
      );
    }
    patch.name = name;
  }
  if (typeof body?.icon === "string" && ICON_KEYS.includes(body.icon)) {
    patch.icon = body.icon;
  }
  if (typeof body?.color === "string" && COLOR_KEYS.includes(body.color)) {
    patch.color = body.color;
  }

  if (Object.keys(patch).length === 0) {
    return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  }

  // Only touches rows owned by the signed-in user — partner habits are safe.
  const ok = await backend().updateHabit(me.id, id, patch);
  if (!ok) {
    return NextResponse.json(
      { error: "You can only edit your own habits." },
      { status: 403 }
    );
  }

  const data = await buildDashboard(me);
  return NextResponse.json({ ok: true, data });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const me = await backend().getUser();
  if (!me) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const id = await parseId(ctx);
  if (!id) return NextResponse.json({ error: "Invalid habit id." }, { status: 400 });

  const ok = await backend().deleteHabit(me.id, id);
  if (!ok) {
    return NextResponse.json(
      { error: "You can only delete your own habits." },
      { status: 403 }
    );
  }

  const data = await buildDashboard(me);
  return NextResponse.json({ ok: true, data });
}
