import { NextRequest, NextResponse } from "next/server";
import { backend, buildDashboard } from "@/lib/backend";
import { COLOR_KEYS, ICON_KEYS } from "@/lib/visuals";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const me = await backend().getUser();
  if (!me) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const body = await req.json().catch(() => null);
  const name = typeof body?.name === "string" ? body.name.trim() : "";
  const icon = typeof body?.icon === "string" ? body.icon : "target";
  const color = typeof body?.color === "string" ? body.color : "lime";

  if (!name || name.length > 140) {
    return NextResponse.json(
      { error: "A habit name between 1 and 140 characters is required." },
      { status: 400 }
    );
  }

  await backend().createHabit(me.id, {
    name,
    icon: ICON_KEYS.includes(icon) ? icon : "target",
    color: COLOR_KEYS.includes(color) ? color : "lime",
  });

  const data = await buildDashboard(me);
  return NextResponse.json({ ok: true, data });
}
