import { NextRequest, NextResponse } from "next/server";
import { backend, buildDashboard } from "@/lib/backend";

export const dynamic = "force-dynamic";

const KEY_RE = /^\d{4}-\d{2}-\d{2}$/;

export async function POST(req: NextRequest) {
  const me = await backend().getUser();
  if (!me) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const body = await req.json().catch(() => null);
  const habitId = Number(body?.habitId);
  const date = typeof body?.date === "string" ? body.date : "";
  const status = body?.status as "completed" | "skipped" | null;

  if (!Number.isInteger(habitId) || habitId <= 0 || !KEY_RE.test(date)) {
    return NextResponse.json({ error: "Invalid payload." }, { status: 400 });
  }
  if (status !== "completed" && status !== "skipped" && status !== null) {
    return NextResponse.json({ error: "Invalid status." }, { status: 400 });
  }

  // Ownership is verified inside the backend (and by RLS in Supabase mode).
  const ok = await backend().setLog(me.id, habitId, date, status);
  if (!ok) {
    return NextResponse.json(
      { error: "You can only mark your own habits." },
      { status: 403 }
    );
  }

  const data = await buildDashboard(me);
  return NextResponse.json({ ok: true, data });
}
