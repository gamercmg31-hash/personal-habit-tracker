import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter, Space_Grotesk } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Momentum — Personal Habit Tracker",
  description:
    "A beautiful personal habit tracker: daily rituals, streaks, weekly progress and a consistency heatmap.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
    <body
      className={`${inter.variable} ${spaceGrotesk.variable} bg-[#0a0a0c] font-sans text-zinc-100 antialiased`}
    >
      {children}
    </body>
    </html>
  );
}
