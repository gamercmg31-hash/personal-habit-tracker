import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { backend, isSupabaseMode, showLocalHint } from "@/lib/backend";
import LoginForm from "@/components/login-form";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Sign in — Momentum",
  description: "A private habit tracker for two. Sign in to continue.",
};

export default async function LoginPage() {
  const be = backend();
  const me = await be.getUser();
  if (me) redirect("/");

  const users = await be.listUsers();

  return (
    <div className="grain relative">
      <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden>
        <div className="ambient-blob absolute -top-32 left-[15%] h-[380px] w-[520px] rounded-full bg-lime-400/[0.06] blur-[120px]" />
        <div
          className="ambient-blob absolute right-[10%] bottom-[10%] h-[320px] w-[420px] rounded-full bg-sky-400/[0.05] blur-[120px]"
          style={{ animationDelay: "-5s" }}
        />
      </div>
      <LoginForm users={users} supabaseMode={isSupabaseMode()} showHint={showLocalHint()} />
    </div>
  );
}
