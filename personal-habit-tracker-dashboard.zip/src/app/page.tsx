import { redirect } from "next/navigation";
import { backend, buildDashboard } from "@/lib/backend";
import DashboardClient from "@/components/dashboard-client";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const me = await backend().getUser();
  if (!me) redirect("/api/auth/continue?next=/");

  const data = await buildDashboard(me);

  return (
    <div className="grain relative">
      {/* ambient glow field */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden>
        <div className="ambient-blob absolute -top-40 left-[8%] h-[420px] w-[560px] rounded-full bg-lime-400/[0.055] blur-[120px]" />
        <div
          className="ambient-blob absolute top-[30%] right-[-6%] h-[380px] w-[460px] rounded-full bg-sky-400/[0.05] blur-[120px]"
          style={{ animationDelay: "-6s" }}
        />
        <div
          className="ambient-blob absolute bottom-[-12%] left-[30%] h-[360px] w-[520px] rounded-full bg-violet-400/[0.05] blur-[120px]"
          style={{ animationDelay: "-3s" }}
        />
      </div>
      <DashboardClient initial={data} />
    </div>
  );
}
