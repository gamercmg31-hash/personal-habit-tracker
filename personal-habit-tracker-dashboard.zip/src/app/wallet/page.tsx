import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { backend } from "@/lib/backend";
import WalletClient from "@/components/wallet/wallet-client";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Wallet — Momentum",
  description:
    "Track income and expenses in ৳, see your balance grow, and understand where your money goes. Saved locally in your browser.",
};

export default async function WalletPage() {
  const me = await backend().getUser();
  if (!me) redirect("/api/auth/continue?next=/wallet");
  return <WalletClient />;
}
