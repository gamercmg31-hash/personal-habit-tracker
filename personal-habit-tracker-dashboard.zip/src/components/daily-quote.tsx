"use client";

import { motion } from "framer-motion";
import { Flame, Heart, Sparkles } from "lucide-react";
import type { DailyQuoteDTO } from "@/lib/types";

const THEMES = {
  love: {
    tile: "bg-rose-400/10 text-rose-300",
    label: "text-rose-300",
    icon: Heart,
    bar: "from-rose-400/40",
  },
  motivation: {
    tile: "bg-amber-400/10 text-amber-300",
    label: "text-amber-300",
    icon: Flame,
    bar: "from-amber-400/40",
  },
} as const;

export default function DailyQuote({ quote }: { quote: DailyQuoteDTO }) {
  const theme = THEMES[quote.category];
  const Icon = theme.icon;

  return (
    <motion.div
      key={`${quote.category}-${quote.text}`}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, delay: 0.18, ease: [0.22, 1, 0.36, 1] }}
      className="relative mt-5 flex max-w-xl items-center gap-3.5 overflow-hidden rounded-2xl border border-white/[0.08] bg-white/[0.03] py-3.5 pr-4 pl-3.5 backdrop-blur sm:pr-5 sm:pl-4"
      aria-live="polite"
    >
      {/* soft accent glow on the leading edge */}
      <div
        className={`pointer-events-none absolute inset-y-0 left-0 w-16 bg-gradient-to-r ${theme.bar} to-transparent opacity-30`}
      />

      <motion.span
        initial={{ scale: 0.6, rotate: -10 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 18, delay: 0.3 }}
        className={`relative grid size-9 shrink-0 place-items-center rounded-xl ${theme.tile}`}
      >
        <Icon size={16} strokeWidth={2.2} />
      </motion.span>

      <div className="relative min-w-0">
        <div className="flex items-center gap-2">
          <span className={`text-[10px] font-bold tracking-[0.2em] uppercase ${theme.label}`}>
            {quote.category === "love" ? "Daily Love" : "Daily Motivation"}
          </span>
          <span className="flex items-center gap-1 text-[10px] tracking-[0.16em] text-zinc-600 uppercase">
            <Sparkles size={9} />
            new every day
          </span>
        </div>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.32 }}
          className="mt-1 line-clamp-2 text-sm leading-snug text-zinc-200 sm:text-[15px]"
        >
          &ldquo;{quote.text}&rdquo;
        </motion.p>
      </div>
    </motion.div>
  );
}
