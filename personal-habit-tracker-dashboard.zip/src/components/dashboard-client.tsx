"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import {
  CalendarDays,
  Check,
  CheckCircle2,
  CircleDashed,
  Flame,
  ListChecks,
  LogOut,
  Plus,
  Sparkles,
  Target,
  Trophy,
  Users,
  Wallet,
} from "lucide-react";
import type { DashboardData, HabitDTO } from "@/lib/types";
import CountUp from "@/components/count-up";
import ProgressRing from "@/components/progress-ring";
import Confetti from "@/components/confetti";
import Heatmap from "@/components/heatmap";
import WeeklyBars from "@/components/weekly-bars";
import HabitRow from "@/components/habit-row";
import HabitModal, { type HabitFormValues } from "@/components/habit-modal";
import PartnerCard from "@/components/partner-card";
import DailyQuote from "@/components/daily-quote";

type Filter = "all" | "left" | "done" | "skipped";

const FILTERS: { key: Filter; label: string }[] = [
  { key: "all", label: "All" },
  { key: "left", label: "To do" },
  { key: "done", label: "Done" },
  { key: "skipped", label: "Skipped" },
];

export default function DashboardClient({ initial }: { initial: DashboardData }) {
  const [data, setData] = useState(initial);
  const [filter, setFilter] = useState<Filter>("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<HabitDTO | null>(null);
  const [saving, setSaving] = useState(false);
  const [busyIds, setBusyIds] = useState<Set<number>>(new Set());
  const [celebrating, setCelebrating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const pendingRef = useRef(0);

  // ---- helpers -------------------------------------------------------------
  const showError = (msg: string) => {
    setError(msg);
    setTimeout(() => setError(null), 4000);
  };

  const refetch = useCallback(async () => {
    try {
      const res = await fetch("/api/dashboard", { cache: "no-store" });
      if (res.ok) setData(await res.json());
    } catch {
      /* keep stale data */
    }
  }, []);

  const mutate = useCallback(
    async (input: RequestInfo, init?: RequestInit) => {
      pendingRef.current++;
      try {
        const res = await fetch(input, init);
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          showError(json?.error ?? "Something went wrong.");
          await refetch();
          return false;
        }
        if (json?.data) setData(json.data);
        return true;
      } catch {
        showError("Network error — please try again.");
        await refetch();
        return false;
      } finally {
        pendingRef.current--;
      }
    },
    [refetch]
  );

  // keep today fresh when the tab refocuses / every 10 minutes (day rollover)
  useEffect(() => {
    const onFocus = () => {
      if (pendingRef.current === 0) refetch();
    };
    window.addEventListener("focus", onFocus);
    const t = setInterval(onFocus, 10 * 60 * 1000);
    return () => {
      window.removeEventListener("focus", onFocus);
      clearInterval(t);
    };
  }, [refetch]);

  // ---- optimistic log toggling ----------------------------------------------
  const applyLogOptimistic = (habitId: number, status: "completed" | "skipped" | null) => {
    setData((prev) => {
      const habitList = prev.habits.map((h) =>
        h.id === habitId ? { ...h, todayStatus: status } : h
      );
      const completed = habitList.filter((h) => h.todayStatus === "completed").length;
      const skipped = habitList.filter((h) => h.todayStatus === "skipped").length;
      const total = prev.totals.total;
      const pct = total === 0 ? 0 : Math.round((completed / total) * 100);
      const week = prev.week.map((d, i) =>
        i === prev.week.length - 1 ? { ...d, completed, skipped, pct, perfect: total > 0 && completed === total } : d
      );
      const heat = prev.heat.map((cell, i) =>
        i === prev.heat.length - 1 ? { ...cell, completed, pct } : cell
      );
      return {
        ...prev,
        habits: habitList,
        totals: { ...prev.totals, completed, skipped, left: total - completed, pct },
        week,
        heat,
      };
    });
  };

  const toggle = async (habit: HabitDTO, status: "completed" | "skipped" | null) => {
    applyLogOptimistic(habit.id, status);
    setBusyIds((s) => new Set(s).add(habit.id));
    await mutate("/api/logs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ habitId: habit.id, date: data.today, status }),
    });
    setBusyIds((s) => {
      const n = new Set(s);
      n.delete(habit.id);
      return n;
    });
  };

  // ---- CRUD ------------------------------------------------------------------
  const openCreate = () => {
    setEditing(null);
    setModalOpen(true);
  };
  const openEdit = (h: HabitDTO) => {
    setEditing(h);
    setModalOpen(true);
  };

  const submitModal = async (values: HabitFormValues) => {
    setSaving(true);
    const ok = await mutate(editing ? `/api/habits/${editing.id}` : "/api/habits", {
      method: editing ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    setSaving(false);
    if (ok) setModalOpen(false);
  };

  const deleteHabit = async (h: HabitDTO) => {
    setBusyIds((s) => new Set(s).add(h.id));
    await mutate(`/api/habits/${h.id}`, { method: "DELETE" });
    setBusyIds((s) => {
      const n = new Set(s);
      n.delete(h.id);
      return n;
    });
  };

  const logout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch {}
    window.location.href = "/login";
  };

  // ---- celebration ------------------------------------------------------------
  const { pct, total, completed, left } = data.totals;
  const prevPct = useRef(pct);
  useEffect(() => {
    const flag = `momentum:celebrated:${data.today}`;
    if (total > 0 && pct === 100) {
      const already = typeof window !== "undefined" && localStorage.getItem(flag);
      if ((prevPct.current < 100 || !already) && !celebrating) {
        setCelebrating(true);
        try {
          localStorage.setItem(flag, "1");
        } catch {}
        setTimeout(() => setCelebrating(false), 4600);
      }
    }
    prevPct.current = pct;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pct, total, data.today]);

  // ---- derived ------------------------------------------------------------------
  const visible = useMemo(() => {
    switch (filter) {
      case "left":
        return data.habits.filter((h) => h.todayStatus !== "completed");
      case "done":
        return data.habits.filter((h) => h.todayStatus === "completed");
      case "skipped":
        return data.habits.filter((h) => h.todayStatus === "skipped");
      default:
        return data.habits;
    }
  }, [data.habits, filter]);

  const headline =
    total > 0 && completed === total
      ? "Perfect day — everything is done."
      : left === 1
        ? "One ritual left. Finish strong."
        : `${left} ritual${left === 0 ? "s" : ""} left today.`;

  return (
    <div className="relative min-h-screen">
      {celebrating && <Confetti burstKey={data.today} />}

      {/* ---------- header ---------- */}
      <header className="sticky top-0 z-50 border-b border-white/[0.06] bg-[#0a0a0c]/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="grid size-9 place-items-center rounded-xl bg-lime-400 text-lime-950 shadow-[0_0_24px_rgba(163,230,53,0.35)]">
              <Check size={20} strokeWidth={3.2} />
            </div>
            <div>
              <div className="font-display text-[15px] font-semibold tracking-tight text-white">
                Momentum
              </div>
              <div className="text-[10px] font-medium tracking-[0.22em] text-zinc-500 uppercase">
                habit OS
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            <div className="hidden items-center gap-2 rounded-full border border-white/[0.08] bg-white/[0.03] px-3.5 py-2 text-xs font-medium text-zinc-400 md:flex">
              <CalendarDays size={13} className="text-lime-300" />
              {data.dateLine}
            </div>
            <Link
              href="/wallet"
              className="flex items-center gap-1.5 rounded-full border border-white/[0.08] bg-white/[0.03] px-4 py-2 text-[13px] font-medium text-zinc-300 transition hover:bg-white/[0.07] hover:text-white"
            >
              <Wallet size={14} className="text-amber-300" />
              <span className="hidden sm:inline">Wallet</span>
            </Link>
            <div
              className="flex items-center gap-1.5 rounded-full border border-white/[0.08] bg-white/[0.03] py-1.5 pr-1.5 pl-2"
              title={`Signed in as ${data.me.name}`}
            >
              <span
                className="font-display grid size-6 place-items-center rounded-full text-[11px] font-semibold text-zinc-950"
                style={{ background: data.me.color }}
              >
                {data.me.name.charAt(0).toUpperCase()}
              </span>
              <span className="hidden max-w-[90px] truncate text-[13px] font-medium text-zinc-300 lg:inline">
                {data.me.name}
              </span>
              <button
                onClick={logout}
                title="Switch account"
                aria-label="Sign out"
                className="grid size-7 place-items-center rounded-full text-zinc-500 transition hover:bg-white/[0.08] hover:text-white"
              >
                <LogOut size={13} />
              </button>
            </div>
            <button
              onClick={openCreate}
              className="flex items-center gap-1.5 rounded-full bg-lime-400 px-4 py-2 text-[13px] font-semibold text-lime-950 transition hover:bg-lime-300 active:scale-95"
            >
              <Plus size={15} strokeWidth={2.8} />
              <span className="hidden sm:inline">New habit</span>
              <span className="sm:hidden">New</span>
            </button>
          </div>
        </div>
      </header>

      <main className="relative mx-auto max-w-6xl px-4 pt-8 pb-20 sm:px-6 lg:pt-12">
        {/* ---------- hero ---------- */}
        <motion.section
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
          className="mb-10"
        >
          <p className="text-[11px] font-semibold tracking-[0.32em] text-lime-300/90 uppercase">
            {data.dateLine}
          </p>
          <h1 className="font-display mt-2 max-w-3xl text-[clamp(2.4rem,6vw,4.2rem)] leading-[1.02] font-semibold tracking-tight text-white">
            {data.greeting},{" "}
            <span className="text-lime-300">{data.me.name.split(" ")[0]}.</span>
          </h1>
          <DailyQuote quote={data.dailyQuote} />
          <div className="mt-6 flex flex-wrap items-center gap-2.5">
            <HeroChip icon={<CheckCircle2 size={14} className="text-lime-300" />} label={`${completed} done`} />
            <HeroChip icon={<CircleDashed size={14} className="text-sky-300" />} label={`${left} to go`} />
            <HeroChip
              icon={<Flame size={14} className="text-amber-300" />}
              label={`${data.streaks.current} day streak`}
            />
            {data.partner && (
              <HeroChip
                icon={<Users size={14} className="text-sky-300" />}
                label={`${data.partner.user.name}: ${data.partner.consistencyPct}% consistent`}
              />
            )}
            <span
              className={`ml-1 hidden text-xs font-medium transition sm:inline ${
                completed === total && total > 0 ? "text-lime-300" : "text-zinc-500"
              }`}
            >
              {headline}
            </span>
          </div>
        </motion.section>

        {/* ---------- main grid ---------- */}
        <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
          {/* habits column */}
          <section>
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.08 }}
              className="mb-4 flex flex-wrap items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3">
                <h2 className="font-display text-lg font-semibold tracking-tight text-white">
                  Today’s rituals
                </h2>
                <span className="rounded-full border border-white/[0.08] bg-white/[0.03] px-2.5 py-1 text-[11px] font-semibold text-zinc-400 tabular-nums">
                  {completed}/{total}
                </span>
              </div>
              <div className="flex rounded-full border border-white/[0.08] bg-white/[0.03] p-1">
                {FILTERS.map((f) => (
                  <button
                    key={f.key}
                    onClick={() => setFilter(f.key)}
                    className={`relative rounded-full px-3 py-1.5 text-xs font-medium transition ${
                      filter === f.key ? "text-lime-950" : "text-zinc-400 hover:text-white"
                    }`}
                  >
                    {filter === f.key && (
                      <motion.span
                        layoutId="filter-pill"
                        className="absolute inset-0 rounded-full bg-lime-400"
                        transition={{ type: "spring", stiffness: 400, damping: 32 }}
                      />
                    )}
                    <span className="relative">{f.label}</span>
                  </button>
                ))}
              </div>
            </motion.div>

            <div className="space-y-3">
              <AnimatePresence mode="popLayout">
                {visible.map((h, i) => (
                  <HabitRow
                    key={h.id}
                    habit={h}
                    index={i}
                    busy={busyIds.has(h.id)}
                    onToggle={toggle}
                    onEdit={openEdit}
                    onDelete={deleteHabit}
                  />
                ))}
              </AnimatePresence>

              {visible.length === 0 && data.habits.length > 0 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="grid place-items-center rounded-2xl border border-dashed border-white/10 py-12 text-center"
                >
                  <Sparkles size={20} className="mb-2 text-zinc-600" />
                  <p className="text-sm text-zinc-500">Nothing matches this filter.</p>
                </motion.div>
              )}

              {data.habits.length === 0 && (
                <motion.button
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  onClick={openCreate}
                  className="group grid w-full place-items-center rounded-2xl border border-dashed border-white/15 py-14 text-center transition hover:border-lime-400/40 hover:bg-lime-400/[0.03]"
                >
                  <div className="grid size-12 place-items-center rounded-full bg-lime-400/10 text-lime-300 transition group-hover:scale-110">
                    <Plus size={20} />
                  </div>
                  <p className="mt-3 text-sm font-medium text-white">Create your first habit</p>
                  <p className="mt-1 text-xs text-zinc-500">Rituals you track are rituals you keep.</p>
                </motion.button>
              )}
            </div>
          </section>

          {/* stats rail */}
          <aside className="space-y-5">
            {data.partner && <PartnerCard partner={data.partner} />}

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.12 }}
              className="relative overflow-hidden rounded-3xl border border-white/[0.07] bg-white/[0.03] p-6"
            >
              <div className="pointer-events-none absolute -top-20 -right-16 size-48 rounded-full bg-lime-400/[0.08] blur-3xl" />
              <CardTitle icon={<Target size={14} />} title="Today’s momentum" />
              <div className="mt-5 flex items-center gap-6">
                <ProgressRing pct={pct} />
                <div className="space-y-3">
                  <StatLine label="Completed" value={`${completed}/${total}`} tone="text-lime-300" />
                  <StatLine label="Remaining" value={`${left}`} tone="text-white" />
                  <StatLine label="Skipped" value={`${data.totals.skipped}`} tone="text-zinc-400" />
                </div>
              </div>
              <div className="mt-5 overflow-hidden rounded-full bg-white/[0.06]">
                <motion.div
                  className="h-1.5 rounded-full bg-gradient-to-r from-lime-500 to-emerald-400"
                  initial={false}
                  animate={{ width: `${pct}%` }}
                  transition={{ type: "spring", stiffness: 70, damping: 20 }}
                />
              </div>
              <p className="mt-3 text-xs leading-relaxed text-zinc-500">
                {completed === total && total > 0
                  ? "Flawless. Come back tomorrow and protect the streak."
                  : "Check off rituals as you go — the ring fills in real time."}
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.18 }}
              className="relative overflow-hidden rounded-3xl border border-white/[0.07] bg-white/[0.03] p-6"
            >
              <div className="pointer-events-none absolute -bottom-16 -left-10 size-44 rounded-full bg-amber-400/[0.07] blur-3xl" />
              <CardTitle icon={<Flame size={14} />} title="Perfect-day streak" tone="text-amber-300" />
              <div className="mt-4 flex items-end justify-between">
                <div>
                  <div className="flex items-baseline gap-2">
                    <CountUp
                      value={data.streaks.current}
                      className="font-display text-5xl font-semibold tracking-tight text-white tabular-nums"
                    />
                    <span className="text-sm font-medium text-zinc-500">
                      day{data.streaks.current === 1 ? "" : "s"}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-zinc-500">
                    Finish every ritual to grow the flame.
                  </p>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className="flex items-center gap-1.5 rounded-full bg-white/[0.05] px-3 py-1.5 text-xs font-semibold text-zinc-300">
                    <Trophy size={12} className="text-amber-300" />
                    Best {data.streaks.best}
                  </div>
                  <div className="text-[11px] text-zinc-500">
                    <span className="font-semibold text-lime-300">{data.streaks.perfectThisWeek}/7</span>{" "}
                    perfect this week
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.24 }}
              className="rounded-3xl border border-white/[0.07] bg-white/[0.03] p-6"
            >
              <CardTitle icon={<ListChecks size={14} />} title="This week" tone="text-sky-300" />
              <div className="mt-5">
                <WeeklyBars week={data.week} />
              </div>
            </motion.div>
          </aside>
        </div>

        {/* ---------- heatmap ---------- */}
        <motion.section
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-5 rounded-3xl border border-white/[0.07] bg-white/[0.03] p-6 sm:p-7"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle icon={<CalendarDays size={14} />} title="Consistency map" tone="text-emerald-300" />
            <span className="text-[11px] tracking-wide text-zinc-600 uppercase">
              last {data.heatWeeks} weeks · today outlined
            </span>
          </div>
          <div className="mt-5 overflow-x-auto pb-1">
            <Heatmap cells={data.heat} weeks={data.heatWeeks} />
          </div>
        </motion.section>

        <footer className="mt-10 flex items-center justify-between text-[11px] text-zinc-600">
          <span>Momentum — build the person, one ritual at a time.</span>
          <span className="hidden sm:inline">Resets automatically at midnight.</span>
        </footer>
      </main>

      {/* error toast */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.97 }}
            className="fixed bottom-6 left-1/2 z-[80] -translate-x-1/2 rounded-full border border-rose-400/30 bg-rose-500/90 px-5 py-2.5 text-sm font-medium text-white shadow-[0_10px_40px_rgba(244,63,94,0.4)] backdrop-blur"
          >
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      <HabitModal
        open={modalOpen}
        editing={editing}
        saving={saving}
        onClose={() => setModalOpen(false)}
        onSubmit={submitModal}
      />
    </div>
  );
}

function HeroChip({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <span className="flex items-center gap-1.5 rounded-full border border-white/[0.08] bg-white/[0.03] px-3 py-1.5 text-xs font-medium text-zinc-300">
      {icon}
      {label}
    </span>
  );
}

function CardTitle({
  icon,
  title,
  tone = "text-lime-300",
}: {
  icon: React.ReactNode;
  title: string;
  tone?: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className={`${tone}`}>{icon}</span>
      <h3 className="text-[11px] font-bold tracking-[0.22em] text-zinc-400 uppercase">{title}</h3>
    </div>
  );
}

function StatLine({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div>
      <div className={`font-display text-xl font-semibold tracking-tight tabular-nums ${tone}`}>
        {value}
      </div>
      <div className="text-[10px] font-medium tracking-[0.18em] text-zinc-500 uppercase">{label}</div>
    </div>
  );
}
