import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Local-mode auth (used only when Supabase env vars are NOT configured).
// In Supabase mode these rows are replaced by auth.users + public.profiles.
// ---------------------------------------------------------------------------
export const appUsers = pgTable("app_users", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 40 }).notNull().unique(), // "u1" | "u2"
  name: varchar("name", { length: 60 }).notNull(),
  color: varchar("color", { length: 16 }).notNull().default("#a3e635"),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at", { withTimezone: false })
    .notNull()
    .defaultNow(),
});

export const habits = pgTable("habits", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => appUsers.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 140 }).notNull(),
  icon: varchar("icon", { length: 48 }).notNull().default("target"),
  color: varchar("color", { length: 24 }).notNull().default("lime"),
  sortOrder: integer("sort_order").notNull().default(0),
  archived: boolean("archived").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: false })
    .notNull()
    .defaultNow(),
});

export const habitLogs = pgTable(
  "habit_logs",
  {
    id: serial("id").primaryKey(),
    habitId: integer("habit_id")
      .notNull()
      .references(() => habits.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => appUsers.id, { onDelete: "cascade" }),
    // Local calendar day key in YYYY-MM-DD format
    date: varchar("date", { length: 10 }).notNull(),
    status: varchar("status", { length: 12 }).notNull().default("completed"), // completed | skipped
    createdAt: timestamp("created_at", { withTimezone: false })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("habit_logs_habit_date_idx").on(t.habitId, t.date)]
);

export const LOG_STATUSES = ["completed", "skipped"] as const;
export type LogStatus = (typeof LOG_STATUSES)[number];
