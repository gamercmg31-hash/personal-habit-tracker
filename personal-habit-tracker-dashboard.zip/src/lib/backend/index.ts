import { computePartner, computeSelf } from "@/lib/compute";
import { dateLine, greetingFor } from "@/lib/dates";
import { quoteOfTheDay } from "@/lib/quotes";
import type { DashboardData } from "@/lib/types";
import type { Backend, UserRecord } from "@/lib/backend/types";
import { localBackend } from "@/lib/backend/local";
import { isSupabaseConfigured, supabaseBackend } from "@/lib/backend/supabase";

export function backend(): Backend {
  return isSupabaseConfigured() ? supabaseBackend : localBackend;
}

export function isSupabaseMode(): boolean {
  return isSupabaseConfigured();
}

/** Show default local passwords hint on the login page (only in local dev mode). */
export function showLocalHint(): boolean {
  return (
    !isSupabaseConfigured() &&
    !process.env.APP_USER1_PASSWORD &&
    !process.env.APP_USER2_PASSWORD
  );
}

const toSession = (u: UserRecord) => ({ id: u.id, name: u.name, color: u.color });

export async function buildDashboard(me: UserRecord): Promise<DashboardData> {
  const be = backend();

  // Seed the default rituals on first visit of this user
  await be.ensureDefaultHabits(me.id);

  const [partner, selfData] = await Promise.all([
    be.getPartner(me),
    be.fetchUserData(me.id),
  ]);

  const now = new Date();
  const self = computeSelf(selfData.habits, selfData.logs, now);

  let partnerSummary = null;
  if (partner) {
    const partnerData = await be.fetchUserData(partner.id);
    partnerSummary = computePartner(
      toSession(partner),
      partnerData.habits,
      partnerData.logs,
      now
    );
  }

  return {
    today: self.week.length > 0 ? self.week[self.week.length - 1].date : "",
    greeting: greetingFor(now),
    dateLine: dateLine(now),
    dailyQuote: quoteOfTheDay(now),
    me: toSession(me),
    partner: partnerSummary,
    totals: self.totals,
    streaks: self.streaks,
    week: self.week,
    heat: self.heat,
    heatWeeks: self.heatWeeks,
    habits: self.habits,
  };
}
