import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { and, asc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { appUsers, habitLogs, habits } from "@/db/schema";
import type {
  Backend,
  HabitInput,
  HabitRecord,
  LogRecord,
  UserRecord,
} from "@/lib/backend/types";
import { dateKey } from "@/lib/dates";
import { DEFAULT_HABITS } from "@/lib/visuals";

const COOKIE = "momentum_session";
const SESSION_DAYS = 30;
const SECRET =
  process.env.AUTH_SECRET || "momentum-local-dev-secret-change-me";

if (!process.env.AUTH_SECRET) {
  console.warn(
    "[momentum] AUTH_SECRET is not set — using a built-in development secret. Set AUTH_SECRET in production."
  );
}

// ---- passwords (scrypt) -----------------------------------------------------

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `scrypt:${salt}:${hash}`;
}

function verifyPassword(password: string, stored: string): boolean {
  const [scheme, salt, hash] = stored.split(":");
  if (scheme !== "scrypt" || !salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

// ---- sessions (HMAC-signed cookie) ------------------------------------------

function sign(payload: string): string {
  return createHmac("sha256", SECRET).update(payload).digest("hex");
}

async function setSessionCookie(userId: string) {
  const exp = Math.floor(Date.now() / 1000) + SESSION_DAYS * 86_400;
  const payload = `${userId}.${exp}`;
  const jar = await cookies();
  jar.set(COOKIE, `${payload}.${sign(payload)}`, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: SESSION_DAYS * 86_400,
    path: "/",
  });
}

function verifyToken(token: string): string | null {
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [userId, exp, sig] = parts;
  const payload = `${userId}.${exp}`;
  const expected = sign(payload);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  if (Number(exp) < Date.now() / 1000) return null;
  return userId;
}

// ---- seeding (runs once; uses env overrides when provided) --------------------

const DEFAULT_USERS = [
  { key: "u1", name: process.env.APP_USER1_NAME || "Alex", color: "#a3e635", password: process.env.APP_USER1_PASSWORD || "momentum1" },
  { key: "u2", name: process.env.APP_USER2_NAME || "Sam", color: "#38bdf8", password: process.env.APP_USER2_PASSWORD || "momentum2" },
];

let seeded = false;
async function ensureSeeded() {
  if (seeded) return;
  const existing = await db.select({ id: appUsers.id }).from(appUsers).limit(1);
  if (existing.length === 0) {
    await db.insert(appUsers).values(
      DEFAULT_USERS.map((u) => ({
        key: u.key,
        name: u.name,
        color: u.color,
        passwordHash: hashPassword(u.password),
      }))
    );
  }
  seeded = true;
}

// ---- mapping ------------------------------------------------------------------

type UserRow = typeof appUsers.$inferSelect;
const toUser = (r: UserRow): UserRecord => ({
  id: String(r.id),
  key: r.key,
  name: r.name,
  color: r.color,
});

const toHabit = (r: typeof habits.$inferSelect): HabitRecord => ({
  id: r.id,
  userId: String(r.userId),
  name: r.name,
  icon: r.icon,
  color: r.color,
  sortOrder: r.sortOrder,
  createdKey: dateKey(r.createdAt),
});

const toLog = (r: typeof habitLogs.$inferSelect): LogRecord => ({
  habitId: r.habitId,
  userId: String(r.userId),
  date: r.date,
  status: r.status === "skipped" ? "skipped" : "completed",
});

// ---- backend --------------------------------------------------------------------

export const localBackend: Backend = {
  mode: "local",

  async getUser() {
    await ensureSeeded();
    const jar = await cookies();
    const token = jar.get(COOKIE)?.value;
    if (!token) return null;
    const userId = verifyToken(token);
    if (!userId) return null;
    const rows = await db
      .select()
      .from(appUsers)
      .where(eq(appUsers.id, Number(userId)))
      .limit(1);
    return rows[0] ? toUser(rows[0]) : null;
  },

  async getPartner(me) {
    await ensureSeeded();
    const rows = await db.select().from(appUsers);
    const other = rows.find((r) => String(r.id) !== me.id);
    return other ? toUser(other) : null;
  },

  async listUsers() {
    await ensureSeeded();
    const rows = await db.select().from(appUsers).orderBy(asc(appUsers.id)).limit(2);
    return rows.map(toUser);
  },

  async signIn(key, password) {
    await ensureSeeded();
    const rows = await db.select().from(appUsers).where(eq(appUsers.key, key)).limit(1);
    const user = rows[0];
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return { ok: false, error: "Wrong password for that person." };
    }
    await setSessionCookie(String(user.id));
    return { ok: true };
  },

  async autoSignIn() {
    // Local demo convenience — skip the password for the default user.
    // Disable with LOCAL_AUTO_SIGNIN=false.
    if (process.env.LOCAL_AUTO_SIGNIN === "false" || process.env.LOCAL_AUTO_SIGNIN === "0") {
      return null;
    }
    await ensureSeeded();
    const rows = await db.select().from(appUsers).orderBy(asc(appUsers.id)).limit(1);
    const user = rows[0];
    if (!user) return null;
    await setSessionCookie(String(user.id));
    return toUser(user);
  },

  async signOut() {
    const jar = await cookies();
    jar.set(COOKIE, "", { httpOnly: true, maxAge: 0, path: "/" });
  },

  async fetchUserData(userId) {
    const uid = Number(userId);
    const habitRows = await db
      .select()
      .from(habits)
      .where(and(eq(habits.userId, uid), eq(habits.archived, false)))
      .orderBy(asc(habits.sortOrder));
    const logRows =
      habitRows.length === 0
        ? []
        : await db
            .select()
            .from(habitLogs)
            .where(
              inArray(
                habitLogs.habitId,
                habitRows.map((h) => h.id)
              )
            );
    return { habits: habitRows.map(toHabit), logs: logRows.map(toLog) };
  },

  async ensureDefaultHabits(userId) {
    const uid = Number(userId);
    const existing = await db
      .select({ id: habits.id })
      .from(habits)
      .where(eq(habits.userId, uid))
      .limit(1);
    if (existing.length > 0) return false;
    await db.insert(habits).values(
      DEFAULT_HABITS.map((h, i) => ({
        userId: uid,
        name: h.name,
        icon: h.icon,
        color: h.color,
        sortOrder: i + 1,
      }))
    );
    return true;
  },

  async createHabit(userId, input: HabitInput) {
    const uid = Number(userId);
    const rows = await db
      .select({ sortOrder: habits.sortOrder })
      .from(habits)
      .where(eq(habits.userId, uid));
    const max = rows.reduce((m, r) => Math.max(m, r.sortOrder), 0);
    await db.insert(habits).values({
      userId: uid,
      name: input.name,
      icon: input.icon,
      color: input.color,
      sortOrder: max + 1,
    });
  },

  async updateHabit(userId, habitId, patch) {
    const uid = Number(userId);
    const updated = await db
      .update(habits)
      .set(patch)
      .where(and(eq(habits.id, habitId), eq(habits.userId, uid))) // ownership enforced
      .returning({ id: habits.id });
    return updated.length > 0;
  },

  async deleteHabit(userId, habitId) {
    const uid = Number(userId);
    const deleted = await db
      .delete(habits)
      .where(and(eq(habits.id, habitId), eq(habits.userId, uid))) // ownership enforced
      .returning({ id: habits.id });
    return deleted.length > 0;
  },

  async setLog(userId, habitId, date, status) {
    const uid = Number(userId);
    // verify the habit belongs to this user
    const own = await db
      .select({ id: habits.id })
      .from(habits)
      .where(and(eq(habits.id, habitId), eq(habits.userId, uid)))
      .limit(1);
    if (own.length === 0) return false;

    if (status === null) {
      await db
        .delete(habitLogs)
        .where(and(eq(habitLogs.habitId, habitId), eq(habitLogs.date, date)));
    } else {
      await db
        .insert(habitLogs)
        .values({ habitId, userId: uid, date, status })
        .onConflictDoUpdate({
          target: [habitLogs.habitId, habitLogs.date],
          set: { status, userId: uid },
        });
    }
    return true;
  },
};
