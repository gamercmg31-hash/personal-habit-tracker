import { createServerClient } from "@supabase/ssr";
import { createClient as createAnon } from "@supabase/supabase-js";
import { cookies } from "next/headers";
import type {
  Backend,
  HabitInput,
  HabitRecord,
  LogRecord,
  UserRecord,
} from "@/lib/backend/types";
import { DEFAULT_HABITS } from "@/lib/visuals";

const URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const ANON = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

/** Session-bound client (respects RLS as the signed-in user). */
async function supa() {
  const jar = await cookies();
  return createServerClient(URL, ANON, {
    cookies: {
      getAll: () => jar.getAll(),
      setAll: (toSet) => {
        try {
          toSet.forEach(({ name, value, options }) => jar.set(name, value, options));
        } catch {
          /* called from a Server Component — cookies are refreshed by route handlers */
        }
      },
    },
  });
}

interface ProfileRow {
  id: string;
  email: string;
  name: string;
  color: string;
}

const toUser = (r: ProfileRow): UserRecord => ({
  id: r.id,
  key: r.email,
  name: r.name,
  color: r.color,
});

interface HabitRow {
  id: number;
  user_id: string;
  name: string;
  icon: string;
  color: string;
  sort_order: number;
  archived: boolean;
  created_at: string;
}

const toHabit = (r: HabitRow): HabitRecord => ({
  id: r.id,
  userId: r.user_id,
  name: r.name,
  icon: r.icon,
  color: r.color,
  sortOrder: r.sort_order,
  createdKey: r.created_at.slice(0, 10),
});

interface LogRow {
  habit_id: number;
  user_id: string;
  date: string;
  status: string;
}

const toLog = (r: LogRow): LogRecord => ({
  habitId: r.habit_id,
  userId: r.user_id,
  date: r.date,
  status: r.status === "skipped" ? "skipped" : "completed",
});

export const supabaseBackend: Backend = {
  mode: "supabase",

  async getUser() {
    const sb = await supa();
    const {
      data: { user },
    } = await sb.auth.getUser();
    if (!user) return null;
    const { data: profile } = await sb
      .from("profiles")
      .select("id,email,name,color")
      .eq("id", user.id)
      .maybeSingle();
    if (profile) return toUser(profile as ProfileRow);
    return {
      id: user.id,
      key: user.email ?? "",
      name: (user.user_metadata?.name as string) || user.email || "Me",
      color: "#a3e635",
    };
  },

  async getPartner(me) {
    const sb = await supa();
    const { data } = await sb
      .from("profiles")
      .select("id,email,name,color")
      .neq("id", me.id)
      .order("created_at", { ascending: true })
      .limit(1);
    return data?.[0] ? toUser(data[0] as ProfileRow) : null;
  },

  async listUsers() {
    // anon read: profiles exposes only names/colors (see supabase/schema.sql)
    const anon = createAnon(URL, ANON);
    const { data } = await anon
      .from("profiles")
      .select("id,email,name,color")
      .order("created_at", { ascending: true })
      .limit(2);
    return (data ?? []).map((r) => toUser(r as ProfileRow));
  },

  async signIn(email, password) {
    const sb = await supa();
    const { error } = await sb.auth.signInWithPassword({ email, password });
    if (error) return { ok: false, error: "Invalid email or password." };
    return { ok: true };
  },

  async autoSignIn() {
    // Production (Supabase) mode always requires a real login.
    return null;
  },

  async signOut() {
    const sb = await supa();
    await sb.auth.signOut();
  },

  async fetchUserData(userId) {
    const sb = await supa();
    const { data: habitRows } = await sb
      .from("habits")
      .select("id,user_id,name,icon,color,sort_order,archived,created_at")
      .eq("user_id", userId)
      .eq("archived", false)
      .order("sort_order", { ascending: true });
    const habits = ((habitRows ?? []) as HabitRow[]).map(toHabit);
    if (habits.length === 0) return { habits, logs: [] };
    const { data: logRows } = await sb
      .from("habit_logs")
      .select("habit_id,user_id,date,status")
      .eq("user_id", userId);
    const logs = ((logRows ?? []) as LogRow[]).map(toLog);
    return { habits, logs };
  },

  async ensureDefaultHabits(userId) {
    const sb = await supa();
    const { data } = await sb
      .from("habits")
      .select("id")
      .eq("user_id", userId)
      .limit(1);
    if (data && data.length > 0) return false;
    await sb.from("habits").insert(
      DEFAULT_HABITS.map((h, i) => ({
        user_id: userId,
        name: h.name,
        icon: h.icon,
        color: h.color,
        sort_order: i + 1,
      }))
    );
    return true;
  },

  async createHabit(userId, input: HabitInput) {
    const sb = await supa();
    const { data } = await sb
      .from("habits")
      .select("sort_order")
      .eq("user_id", userId);
    const max = (data ?? []).reduce((m: number, r: { sort_order: number }) => Math.max(m, r.sort_order), 0);
    await sb.from("habits").insert({
      user_id: userId,
      name: input.name,
      icon: input.icon,
      color: input.color,
      sort_order: max + 1,
    });
  },

  async updateHabit(userId, habitId, patch) {
    const sb = await supa();
    const dbPatch: Record<string, unknown> = {};
    if (patch.name !== undefined) dbPatch.name = patch.name;
    if (patch.icon !== undefined) dbPatch.icon = patch.icon;
    if (patch.color !== undefined) dbPatch.color = patch.color;
    const { data } = await sb
      .from("habits")
      .update(dbPatch)
      .eq("id", habitId)
      .eq("user_id", userId) // ownership enforced (RLS too)
      .select("id");
    return (data?.length ?? 0) > 0;
  },

  async deleteHabit(userId, habitId) {
    const sb = await supa();
    const { data } = await sb
      .from("habits")
      .delete()
      .eq("id", habitId)
      .eq("user_id", userId) // ownership enforced (RLS too)
      .select("id");
    return (data?.length ?? 0) > 0;
  },

  async setLog(userId, habitId, date, status) {
    const sb = await supa();
    // verify ownership of the habit first
    const { data: own } = await sb
      .from("habits")
      .select("id")
      .eq("id", habitId)
      .eq("user_id", userId)
      .limit(1);
    if (!own || own.length === 0) return false;

    if (status === null) {
      await sb
        .from("habit_logs")
        .delete()
        .eq("habit_id", habitId)
        .eq("date", date)
        .eq("user_id", userId);
    } else {
      await sb.from("habit_logs").upsert(
        { habit_id: habitId, user_id: userId, date, status },
        { onConflict: "habit_id,date" }
      );
    }
    return true;
  },
};

export function isSupabaseConfigured(): boolean {
  return Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  );
}
