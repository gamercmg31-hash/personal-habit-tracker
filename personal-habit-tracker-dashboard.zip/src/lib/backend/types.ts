// Backend abstraction: one interface, two implementations.
// - SupabaseBackend when NEXT_PUBLIC_SUPABASE_URL + NEXT_PUBLIC_SUPABASE_ANON_KEY exist
// - LocalBackend (built-in Postgres + cookie sessions) otherwise

export type BackendMode = "local" | "supabase";

export interface UserRecord {
  id: string;
  key: string; // login key: "u1"/"u2" locally, email in Supabase mode
  name: string;
  color: string; // avatar hex
}

export interface HabitRecord {
  id: number;
  userId: string;
  name: string;
  icon: string;
  color: string;
  sortOrder: number;
  createdKey: string; // YYYY-MM-DD
}

export interface LogRecord {
  habitId: number;
  userId: string;
  date: string; // YYYY-MM-DD
  status: "completed" | "skipped";
}

export interface UserData {
  habits: HabitRecord[];
  logs: LogRecord[];
}

export interface HabitInput {
  name: string;
  icon: string;
  color: string;
}

export interface Backend {
  mode: BackendMode;
  /** The currently signed-in user, or null. */
  getUser(): Promise<UserRecord | null>;
  /** The other person in this 2-person app. */
  getPartner(me: UserRecord): Promise<UserRecord | null>;
  /** Both users, for the login screen. */
  listUsers(): Promise<UserRecord[]>;
  /** key = user key (local) or email (supabase). Sets the session cookie. */
  signIn(key: string, password: string): Promise<{ ok: boolean; error?: string }>;
  /**
   * Password-less demo entry for the default user (local preview only).
   * Returns null when disabled or unsupported (Supabase mode never auto-signs).
   */
  autoSignIn(): Promise<UserRecord | null>;
  signOut(): Promise<void>;
  /** All habits + logs for a user (both users are trusted readers). */
  fetchUserData(userId: string): Promise<UserData>;
  /** Seed the 7 default habits on a user's first visit. */
  ensureDefaultHabits(userId: string): Promise<boolean>;
  /** Mutations — implementations MUST enforce ownership. */
  createHabit(userId: string, input: HabitInput): Promise<void>;
  updateHabit(userId: string, habitId: number, patch: Partial<HabitInput>): Promise<boolean>;
  deleteHabit(userId: string, habitId: number): Promise<boolean>;
  setLog(
    userId: string,
    habitId: number,
    date: string,
    status: "completed" | "skipped" | null
  ): Promise<boolean>;
}
