-- ============================================================================
-- Momentum — Supabase schema (private 2-person habit tracker)
-- Run this in your Supabase project's SQL Editor, then run
--   node scripts/supabase-setup.mjs   (creates the two login users)
-- ============================================================================

-- Profiles mirror auth.users (only the 2 people in this private app)
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text not null,
  name text not null,
  color text not null default '#a3e635',
  created_at timestamptz not null default now()
);

create table if not exists public.habits (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles (id) on delete cascade,
  name varchar(140) not null,
  icon varchar(48) not null default 'target',
  color varchar(24) not null default 'lime',
  sort_order integer not null default 0,
  archived boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.habit_logs (
  id bigint generated always as identity primary key,
  habit_id bigint not null references public.habits (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  date varchar(10) not null, -- YYYY-MM-DD
  status varchar(12) not null default 'completed', -- completed | skipped
  created_at timestamptz not null default now(),
  unique (habit_id, date)
);

alter table public.profiles enable row level security;
alter table public.habits enable row level security;
alter table public.habit_logs enable row level security;

-- ---------------------------------------------------------------------------
-- RLS: the two signed-in users may READ each other's rows (needed for the
-- read-only partner Consistency % view) but can only WRITE their own.
-- The app layer enforces ownership too; these policies are the backstop.
-- ---------------------------------------------------------------------------

-- Profiles: any signed-in user can read; the login screen (anon) may read
-- names/colors only via this policy — no personal data beyond that exists.
drop policy if exists "profiles read" on public.profiles;
create policy "profiles read"
  on public.profiles for select
  to anon, authenticated
  using (true);

drop policy if exists "habits read all" on public.habits;
create policy "habits read all"
  on public.habits for select
  to authenticated
  using (true);

drop policy if exists "habits owner insert" on public.habits;
create policy "habits owner insert"
  on public.habits for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "habits owner update" on public.habits;
create policy "habits owner update"
  on public.habits for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "habits owner delete" on public.habits;
create policy "habits owner delete"
  on public.habits for delete
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "logs read all" on public.habit_logs;
create policy "logs read all"
  on public.habit_logs for select
  to authenticated
  using (true);

drop policy if exists "logs owner insert" on public.habit_logs;
create policy "logs owner insert"
  on public.habit_logs for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "logs owner update" on public.habit_logs;
create policy "logs owner update"
  on public.habit_logs for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "logs owner delete" on public.habit_logs;
create policy "logs owner delete"
  on public.habit_logs for delete
  to authenticated
  using (auth.uid() = user_id);
