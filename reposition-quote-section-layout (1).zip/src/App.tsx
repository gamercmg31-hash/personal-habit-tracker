import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  CalendarDays,
  Check,
  CheckCircle2,
  CircleDashed,
  Flame,
  ListChecks,
  LogOut,
  Plus,
  Sparkles,
  Target,
  Trophy,
  Users,
  Wallet,
} from "lucide-react";
import type { HabitDTO } from "@/lib/types";
import {
  buildDashboard,
  createHabit,
  deleteHabit,
  ensureSlice,
  LOGIN_USERS,
  loadSession,
  partnerOf,
  persistSlice,
  saveSession,
  setLog,
  updateHabit,
  type AccountUser,
  type UserSlice,
} from "@/lib/store";
import CountUp from "@/components/count-up";
import ProgressRing from "@/components/progress-ring";
import Confetti from "@/components/confetti";
import Heatmap from "@/components/heatmap";
import WeeklyBars from "@/components/weekly-bars";
import HabitRow from "@/components/habit-row";
import HabitModal, { type HabitFormValues } from "@/components/habit-modal";
import PartnerCard from "@/components/partner-card";
import DailyQuote from "@/components/daily-quote";
import LoginScreen from "@/components/login-screen";
import WalletClient from "@/components/wallet/wallet-client";

type View = "habits" | "wallet";

export default function App() {
  const [me, setMe] = useState<AccountUser | null>(() => loadSession());
  const [view, setView] = useState<View>("habits");

  const handleSignedIn = (user: AccountUser) => {
    ensureSlice(user.id); // seed the default rituals on this person's first ever visit
    setMe(user);
    setView("habits");
  };

  const handleSignOut = () => {
    saveSession(null);
    setMe(null);
    setView("habits");
  };

  if (!me) {
    return (
      <div className="grain relative">
        <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden>
          <div className="ambient-blob absolute -top-32 left-[15%] h-[380px] w-[520px] rounded-full bg-lime-400/[0.06] blur-[120px]" />
          <div
            className="ambient-blob absolute right-[10%] bottom-[10%] h-[320px] w-[420px] rounded-full bg-sky-400/[0.05] blur-[120px]"
            style={{ animationDelay: "-5s" }}
          />
        </div>
        <LoginScreen users={LOGIN_USERS} onSuccess={handleSignedIn} />
      </div>
    );
  }

  if (view === "wallet") {
    return <WalletClient onBack={() => setView("habits")} />;
  }

  return (
    <Dashboard
      key={me.id} // full remount per person — clean slate when switching accounts
      me={me}
      onSignOut={handleSignOut}
      onOpenWallet={() => setView("wallet")}
    />
  );
}

/* ========================================================================== */
/*  Dashboard                                                                  */
/* ========================================================================== */

type Filter = "all" | "left" | "done" | "skipped";

const FILTERS: { key: Filter; label: string }[] = [
  { key: "all", label: "All" },
  { key: "left", label: "To do" },
  { key: "done", label: "Done" },
  { key: "skipped", label: "Skipped" },
];

function Dashboard({
  me,
  onSignOut,
  onOpenWallet,
}: {
  me: AccountUser;
  onSignOut: () => void;
  onOpenWallet: () => void;
}) {
  const [slice, setSlice] = useState<UserSlice>(() => ensureSlice(me.id));
  const [filter, setFilter] = useState<Filter>("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<HabitDTO | null>(null);
  const [saving, setSaving] = useState(false);
  const [celebrating, setCelebrating] = useState(false);
  const [tick, setTick] = useState(0);

  // ---- derived dashboard ----------------------------------------------------
  const data = useMemo(
    () => buildDashboard(me, slice),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [me, slice, tick]
  );

  const commit = (next: UserSlice) => {
    persistSlice(me.id, next);
    setSlice(next);
  };

  // Recompute on refocus / every 10 minutes — keeps the partner pulse fresh
  // (they may have tracked from their own account) and handles day rollover.
  useEffect(() => {
    const onFocus = () => setTick((t) => t + 1);
    window.addEventListener("focus", onFocus);
    const t = setInterval(onFocus, 10 * 60 * 1000);
    return () => {
      window.removeEventListener("focus", onFocus);
      clearInterval(t);
    };
  }, []);

  // ---- log toggling ----------------------------------------------------------
  const toggle = (habit: HabitDTO, status: "completed" | "skipped" | null) => {
    commit(setLog(slice, me.id, habit.id, data.today, status));
  };

  // ---- CRUD ------------------------------------------------------------------
  const openCreate = () => {
    setEditing(null);
    setModalOpen(true);
  };
  const openEdit = (h: HabitDTO) => {
    setEditing(h);
    setModalOpen(true);
  };

  const submitModal = (values: HabitFormValues) => {
    setSaving(true);
    commit(
      editing
        ? updateHabit(slice, editing.id, values)
        : createHabit(slice, me.id, values)
    );
    setSaving(false);
    setModalOpen(false);
  };

  const removeHabit = (h: HabitDTO) => {
    commit(deleteHabit(slice, h.id));
  };

  // ---- celebration ------------------------------------------------------------
  const { pct, total, completed, left } = data.totals;
  const prevPct = useRef(pct);
  useEffect(() => {
    const flag = `momentum:celebrated:${data.today}`;
    if (total > 0 && pct === 100) {
      const already = typeof window !== "undefined" && localStorage.getItem(flag);
      if ((prevPct.current < 100 || !already) && !celebrating) {
        setCelebrating(true);
        try {
          localStorage.setItem(flag, "1");
        } catch {}
        setTimeout(() => setCelebrating(false), 4600);
      }
    }
    prevPct.current = pct;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pct, total, data.today]);

  // ---- derived list -------------------------------------------------------------
  const visible = useMemo(() => {
    switch (filter) {
      case "left":
        return data.habits.filter((h) => h.todayStatus !== "completed");
      case "done":
        return data.habits.filter((h) => h.todayStatus === "completed");
      case "skipped":
        return data.habits.filter((h) => h.todayStatus === "skipped");
      default:
        return data.habits;
    }
  }, [data.habits, filter]);

  const partner = data.partner;
  const partnerName = partnerOf(me.id)?.name ?? "Partner";

  const headline =
    total > 0 && completed === total
      ? "Perfect day — everything is done."
      : left === 1
        ? "One ritual left. Finish strong."
        : `${left} ritual${left === 0 ? "s" : ""} left today.`;

  return (
    <div className="grain relative">
      {/* ambient glow field */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden>
        <div className="ambient-blob absolute -top-40 left-[8%] h-[420px] w-[560px] rounded-full bg-lime-400/[0.055] blur-[120px]" />
        <div
          className="ambient-blob absolute top-[30%] right-[-6%] h-[380px] w-[460px] rounded-full bg-sky-400/[0.05] blur-[120px]"
          style={{ animationDelay: "-6s" }}
        />
        <div
          className="ambient-blob absolute bottom-[-12%] left-[30%] h-[360px] w-[520px] rounded-full bg-violet-400/[0.05] blur-[120px]"
          style={{ animationDelay: "-3s" }}
        />
      </div>

      <div className="relative min-h-screen">
        {celebrating && <Confetti burstKey={data.today} />}

        {/* ---------- header ---------- */}
        <header className="sticky top-0 z-50 border-b border-white/[0.06] bg-[#0a0a0c]/80 backdrop-blur-xl">
          <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3.5 sm:px-6">
            <div className="flex items-center gap-3">
              <div className="grid size-9 place-items-center rounded-xl bg-lime-400 text-lime-950 shadow-[0_0_24px_rgba(163,230,53,0.35)]">
                <Check size={20} strokeWidth={3.2} />
              </div>
              <div>
                <div className="font-display text-[15px] font-semibold tracking-tight text-white">
                  Momentum
                </div>
                <div className="text-[10px] font-medium tracking-[0.22em] text-zinc-500 uppercase">
                  habit OS
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2.5">
              <div className="hidden items-center gap-2 rounded-full border border-white/[0.08] bg-white/[0.03] px-3.5 py-2 text-xs font-medium text-zinc-400 md:flex">
                <CalendarDays size={13} className="text-lime-300" />
                {data.dateLine}
              </div>
              <button
                onClick={onOpenWallet}
                className="flex items-center gap-1.5 rounded-full border border-white/[0.08] bg-white/[0.03] px-4 py-2 text-[13px] font-medium text-zinc-300 transition hover:bg-white/[0.07] hover:text-white"
              >
                <Wallet size={14} className="text-amber-300" />
                <span className="hidden sm:inline">Wallet</span>
              </button>
              <div
                className="flex items-center gap-1.5 rounded-full border border-white/[0.08] bg-white/[0.03] py-1.5 pr-1.5 pl-2"
                title={`Signed in as ${data.me.name}`}
              >
                <span
                  className="font-display grid size-6 place-items-center rounded-full text-[11px] font-semibold text-zinc-950"
                  style={{ background: data.me.color }}
                >
                  {data.me.name.charAt(0).toUpperCase()}
                </span>
                <span className="hidden max-w-[90px] truncate text-[13px] font-medium text-zinc-300 lg:inline">
                  {data.me.name}
                </span>
                <button
                  onClick={onSignOut}
                  title="Switch account"
                  aria-label="Sign out"
                  className="grid size-7 place-items-center rounded-full text-zinc-500 transition hover:bg-white/[0.08] hover:text-white"
                >
                  <LogOut size={13} />
                </button>
              </div>
              <button
                onClick={openCreate}
                className="flex items-center gap-1.5 rounded-full bg-lime-400 px-4 py-2 text-[13px] font-semibold text-lime-950 transition hover:bg-lime-300 active:scale-95"
              >
                <Plus size={15} strokeWidth={2.8} />
                <span className="hidden sm:inline">New habit</span>
                <span className="sm:hidden">New</span>
              </button>
            </div>
          </div>
        </header>

        <main className="relative mx-auto max-w-6xl px-4 pt-8 pb-20 sm:px-6 lg:pt-12">
          {/* ---------- hero ---------- */}
          <motion.section
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="mb-10"
          >
            <p className="text-[11px] font-semibold tracking-[0.32em] text-lime-300/90 uppercase">
              {data.dateLine}
            </p>
            <h1 className="font-display mt-2 max-w-3xl text-[clamp(2.4rem,6vw,4.2rem)] leading-[1.02] font-semibold tracking-tight text-white">
              {data.greeting},{" "}
              <span className="text-lime-300">{data.me.name.split(" ")[0]}.</span>
            </h1>
            <div className="mt-6 flex flex-wrap items-center gap-2.5">
              <HeroChip icon={<CheckCircle2 size={14} className="text-lime-300" />} label={`${completed} done`} />
              <HeroChip icon={<CircleDashed size={14} className="text-sky-300" />} label={`${left} to go`} />
              <HeroChip
                icon={<Flame size={14} className="text-amber-300" />}
                label={`${data.streaks.current} day streak`}
              />
              {partner && (
                <HeroChip
                  icon={<Users size={14} className="text-sky-300" />}
                  label={`${partnerName}: ${partner.consistencyPct}% consistent`}
                />
              )}
              <span
                className={`ml-1 hidden text-xs font-medium transition sm:inline ${
                  completed === total && total > 0 ? "text-lime-300" : "text-zinc-500"
                }`}
              >
                {headline}
              </span>
            </div>
          </motion.section>

          {/* ---------- main grid ---------- */}
          <div className="grid items-stretch gap-5 lg:grid-cols-[1fr_360px]">
            {/* habits column */}
            <section className="flex flex-col">
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.08 }}
                className="mb-4 flex flex-wrap items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  <h2 className="font-display text-lg font-semibold tracking-tight text-white">
                    Today’s rituals
                  </h2>
                  <span className="rounded-full border border-white/[0.08] bg-white/[0.03] px-2.5 py-1 text-[11px] font-semibold text-zinc-400 tabular-nums">
                    {completed}/{total}
                  </span>
                </div>
                <div className="flex rounded-full border border-white/[0.08] bg-white/[0.03] p-1">
                  {FILTERS.map((f) => (
                    <button
                      key={f.key}
                      onClick={() => setFilter(f.key)}
                      className={`relative rounded-full px-3 py-1.5 text-xs font-medium transition ${
                        filter === f.key ? "text-lime-950" : "text-zinc-400 hover:text-white"
                      }`}
                    >
                      {filter === f.key && (
                        <motion.span
                          layoutId="filter-pill"
                          className="absolute inset-0 rounded-full bg-lime-400"
                          transition={{ type: "spring", stiffness: 400, damping: 32 }}
                        />
                      )}
                      <span className="relative">{f.label}</span>
                    </button>
                  ))}
                </div>
              </motion.div>

              <div className="space-y-3">
                <AnimatePresence mode="popLayout">
                  {visible.map((h, i) => (
                    <HabitRow
                      key={h.id}
                      habit={h}
                      index={i}
                      busy={false}
                      onToggle={toggle}
                      onEdit={openEdit}
                      onDelete={removeHabit}
                    />
                  ))}
                </AnimatePresence>

                {visible.length === 0 && data.habits.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="grid place-items-center rounded-2xl border border-dashed border-white/10 py-12 text-center"
                  >
                    <Sparkles size={20} className="mb-2 text-zinc-600" />
                    <p className="text-sm text-zinc-500">Nothing matches this filter.</p>
                  </motion.div>
                )}

                {data.habits.length === 0 && (
                  <motion.button
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    onClick={openCreate}
                    className="group grid w-full place-items-center rounded-2xl border border-dashed border-white/15 py-14 text-center transition hover:border-lime-400/40 hover:bg-lime-400/[0.03]"
                  >
                    <div className="grid size-12 place-items-center rounded-full bg-lime-400/10 text-lime-300 transition group-hover:scale-110">
                      <Plus size={20} />
                    </div>
                    <p className="mt-3 text-sm font-medium text-white">Create your first habit</p>
                    <p className="mt-1 text-xs text-zinc-500">Rituals you track are rituals you keep.</p>
                  </motion.button>
                )}
              </div>

              {/* ---------- daily quote (below the habits section) ---------- */}
              <div className="mt-5 flex-1">
                <DailyQuote quote={data.dailyQuote} className="mt-0 h-full max-w-none" />
              </div>
            </section>

            {/* stats rail */}
            <aside className="space-y-5">
              {partner && <PartnerCard partner={partner} />}

              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.12 }}
                className="relative overflow-hidden rounded-3xl border border-white/[0.07] bg-white/[0.03] p-6"
              >
                <div className="pointer-events-none absolute -top-20 -right-16 size-48 rounded-full bg-lime-400/[0.08] blur-3xl" />
                <CardTitle icon={<Target size={14} />} title="Today’s momentum" />
                <div className="mt-5 flex items-center gap-6">
                  <ProgressRing pct={pct} />
                  <div className="space-y-3">
                    <StatLine label="Completed" value={`${completed}/${total}`} tone="text-lime-300" />
                    <StatLine label="Remaining" value={`${left}`} tone="text-white" />
                    <StatLine label="Skipped" value={`${data.totals.skipped}`} tone="text-zinc-400" />
                  </div>
                </div>
                <div className="mt-5 overflow-hidden rounded-full bg-white/[0.06]">
                  <motion.div
                    className="h-1.5 rounded-full bg-gradient-to-r from-lime-500 to-emerald-400"
                    initial={false}
                    animate={{ width: `${pct}%` }}
                    transition={{ type: "spring", stiffness: 70, damping: 20 }}
                  />
                </div>
                <p className="mt-3 text-xs leading-relaxed text-zinc-500">
                  {completed === total && total > 0
                    ? "Flawless. Come back tomorrow and protect the streak."
                    : "Check off rituals as you go — the ring fills in real time."}
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.18 }}
                className="relative overflow-hidden rounded-3xl border border-white/[0.07] bg-white/[0.03] p-6"
              >
                <div className="pointer-events-none absolute -bottom-16 -left-10 size-44 rounded-full bg-amber-400/[0.07] blur-3xl" />
                <CardTitle icon={<Flame size={14} />} title="Perfect-day streak" tone="text-amber-300" />
                <div className="mt-4 flex items-end justify-between">
                  <div>
                    <div className="flex items-baseline gap-2">
                      <CountUp
                        value={data.streaks.current}
                        className="font-display text-5xl font-semibold tracking-tight text-white tabular-nums"
                      />
                      <span className="text-sm font-medium text-zinc-500">
                        day{data.streaks.current === 1 ? "" : "s"}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-zinc-500">
                      Finish every ritual to grow the flame.
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="flex items-center gap-1.5 rounded-full bg-white/[0.05] px-3 py-1.5 text-xs font-semibold text-zinc-300">
                      <Trophy size={12} className="text-amber-300" />
                      Best {data.streaks.best}
                    </div>
                    <div className="text-[11px] text-zinc-500">
                      <span className="font-semibold text-lime-300">{data.streaks.perfectThisWeek}/7</span>{" "}
                      perfect this week
                    </div>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.24 }}
                className="rounded-3xl border border-white/[0.07] bg-white/[0.03] p-6"
              >
                <CardTitle icon={<ListChecks size={14} />} title="This week" tone="text-sky-300" />
                <div className="mt-5">
                  <WeeklyBars week={data.week} />
                </div>
              </motion.div>
            </aside>
          </div>

          {/* ---------- heatmap ---------- */}
          <motion.section
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mt-5 rounded-3xl border border-white/[0.07] bg-white/[0.03] p-6 sm:p-7"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <CardTitle icon={<CalendarDays size={14} />} title="Consistency map" tone="text-emerald-300" />
              <span className="text-[11px] tracking-wide text-zinc-600 uppercase">
                last {data.heatWeeks} weeks · today outlined
              </span>
            </div>
            <div className="mt-5 overflow-x-auto pb-1">
              <Heatmap cells={data.heat} weeks={data.heatWeeks} />
            </div>
          </motion.section>

          <footer className="mt-10 flex items-center justify-between text-[11px] text-zinc-600">
            <span>Momentum — build the person, one ritual at a time.</span>
            <span className="hidden sm:inline">Resets automatically at midnight.</span>
          </footer>
        </main>

        <HabitModal
          open={modalOpen}
          editing={editing}
          saving={saving}
          onClose={() => setModalOpen(false)}
          onSubmit={submitModal}
        />
      </div>
    </div>
  );
}

function HeroChip({ icon, label }: { icon: ReactNode; label: string }) {
  return (
    <span className="flex items-center gap-1.5 rounded-full border border-white/[0.08] bg-white/[0.03] px-3 py-1.5 text-xs font-medium text-zinc-300">
      {icon}
      {label}
    </span>
  );
}

function CardTitle({
  icon,
  title,
  tone = "text-lime-300",
}: {
  icon: ReactNode;
  title: string;
  tone?: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className={`${tone}`}>{icon}</span>
      <h3 className="text-[11px] font-bold tracking-[0.22em] text-zinc-400 uppercase">{title}</h3>
    </div>
  );
}

function StatLine({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div>
      <div className={`font-display text-xl font-semibold tracking-tight tabular-nums ${tone}`}>
        {value}
      </div>
      <div className="text-[10px] font-medium tracking-[0.18em] text-zinc-500 uppercase">{label}</div>
    </div>
  );
}
