// ---------------------------------------------------------------------------
// Local data layer — the 2-person backend of Momentum, running entirely on
// localStorage. Mirrors the original Next.js backend exactly:
//   · two accounts (Alex / Sam) with passwords
//   · default rituals seeded ONCE, the first time each person signs in
//   · every log, habit and streak is earned from real usage — no fake history
//   · each person sees the other's progress read-only
// ---------------------------------------------------------------------------

import { dateKey, dateLine, greetingFor } from "@/lib/dates";
import { quoteOfTheDay } from "@/lib/quotes";
import { computePartner, computeSelf } from "@/lib/compute";
import { DEFAULT_HABITS } from "@/lib/visuals";
import type {
  DashboardData,
  HabitRecord,
  LogRecord,
  LogStatusValue,
} from "@/lib/types";

/* ---- accounts --------------------------------------------------------------- */

export interface AccountUser {
  id: string;
  key: string;
  name: string;
  color: string;
}

interface AccountWithSecret extends AccountUser {
  password: string;
}

const ACCOUNTS: AccountWithSecret[] = [
  { id: "u1", key: "u1", name: "Alex", color: "#a3e635", password: "momentum1" },
  { id: "u2", key: "u2", name: "Sam", color: "#38bdf8", password: "momentum2" },
];

export const LOGIN_USERS: AccountUser[] = ACCOUNTS.map(({ id, key, name, color }) => ({
  id,
  key,
  name,
  color,
}));

export function signIn(
  key: string,
  password: string
): { ok: boolean; error?: string; user?: AccountUser } {
  const acc = ACCOUNTS.find((a) => a.key === key);
  if (!acc || acc.password !== password) {
    return { ok: false, error: "Wrong password for that person." };
  }
  const user: AccountUser = { id: acc.id, key: acc.key, name: acc.name, color: acc.color };
  saveSession(user.id);
  return { ok: true, user };
}

export function partnerOf(userId: string): AccountUser | null {
  const other = LOGIN_USERS.find((u) => u.id !== userId);
  return other ?? null;
}

/* ---- session ------------------------------------------------------------------ */

const SESSION_KEY = "momentum:session";

export function loadSession(): AccountUser | null {
  try {
    const id = localStorage.getItem(SESSION_KEY);
    return LOGIN_USERS.find((u) => u.id === id) ?? null;
  } catch {
    return null;
  }
}

export function saveSession(userId: string | null) {
  try {
    if (userId) localStorage.setItem(SESSION_KEY, userId);
    else localStorage.removeItem(SESSION_KEY);
  } catch {}
}

/* ---- per-user data -------------------------------------------------------------- */

export interface UserSlice {
  seeded: boolean;
  habits: HabitRecord[];
  logs: LogRecord[];
}

const dataKeyFor = (userId: string) => `momentum:data:v2:${userId}`;
const LEGACY_KEY = "momentum:state:v1";

function emptySlice(): UserSlice {
  return { seeded: false, habits: [], logs: [] };
}

function seedDefaults(userId: string): UserSlice {
  const todayKey = dateKey(new Date());
  const habits: HabitRecord[] = DEFAULT_HABITS.map((h, i) => ({
    id: i + 1,
    userId,
    name: h.name,
    icon: h.icon,
    color: h.color,
    sortOrder: i + 1,
    createdKey: todayKey,
  }));
  return { seeded: true, habits, logs: [] };
}

/** Read-only load — never writes (safe for peeking at the partner's data). */
export function loadSlice(userId: string): UserSlice {
  try {
    // one-time cleanup of the old pre-account storage shape
    if (localStorage.getItem(LEGACY_KEY)) localStorage.removeItem(LEGACY_KEY);
    const raw = localStorage.getItem(dataKeyFor(userId));
    if (!raw) return emptySlice();
    const parsed = JSON.parse(raw) as UserSlice;
    if (!parsed || !Array.isArray(parsed.habits) || !Array.isArray(parsed.logs)) {
      return emptySlice();
    }
    return { seeded: !!parsed.seeded, habits: parsed.habits, logs: parsed.logs };
  } catch {
    return emptySlice();
  }
}

export function persistSlice(userId: string, slice: UserSlice) {
  try {
    localStorage.setItem(dataKeyFor(userId), JSON.stringify(slice));
  } catch {
    /* private mode — state stays in memory */
  }
}

/**
 * Load a user's data for their own session — seeds the default rituals once,
 * on first ever sign-in, exactly like ensureDefaultHabits in the original.
 */
export function ensureSlice(userId: string): UserSlice {
  const existing = loadSlice(userId);
  if (existing.seeded) return existing;
  const fresh = seedDefaults(userId);
  persistSlice(userId, fresh);
  return fresh;
}

/* ---- mutations (pure — return the next slice) ------------------------------------ */

export function setLog(
  slice: UserSlice,
  userId: string,
  habitId: number,
  date: string,
  status: LogStatusValue | null
): UserSlice {
  const mine = slice.habits.some((h) => h.id === habitId);
  if (!mine) return slice;
  const rest = slice.logs.filter(
    (l) => !(l.habitId === habitId && l.date === date)
  );
  const logs =
    status === null ? rest : [...rest, { habitId, userId, date, status }];
  return { ...slice, logs };
}

export function createHabit(
  slice: UserSlice,
  userId: string,
  input: { name: string; icon: string; color: string }
): UserSlice {
  const todayKey = dateKey(new Date());
  const nextId = slice.habits.reduce((m, h) => Math.max(m, h.id), 0) + 1;
  const sortOrder = slice.habits.reduce((m, h) => Math.max(m, h.sortOrder), 0) + 1;
  const habit: HabitRecord = {
    id: nextId,
    userId,
    name: input.name,
    icon: input.icon,
    color: input.color,
    sortOrder,
    createdKey: todayKey,
  };
  return { ...slice, habits: [...slice.habits, habit] };
}

export function updateHabit(
  slice: UserSlice,
  habitId: number,
  patch: { name?: string; icon?: string; color?: string }
): UserSlice {
  const habits = slice.habits.map((h) =>
    h.id === habitId ? { ...h, ...patch } : h
  );
  return { ...slice, habits };
}

export function deleteHabit(slice: UserSlice, habitId: number): UserSlice {
  const habits = slice.habits.filter((h) => h.id !== habitId);
  const logs = slice.logs.filter((l) => l.habitId !== habitId);
  return { ...slice, habits, logs };
}

/* ---- dashboard assembly ------------------------------------------------------------ */

export function buildDashboard(me: AccountUser, slice: UserSlice): DashboardData {
  const now = new Date();
  const self = computeSelf(slice.habits, slice.logs, now);

  const partnerUser = partnerOf(me.id);
  let partner = null;
  if (partnerUser) {
    const theirSlice = loadSlice(partnerUser.id);
    partner = computePartner(
      { id: partnerUser.id, name: partnerUser.name, color: partnerUser.color },
      theirSlice.habits,
      theirSlice.logs,
      now
    );
  }

  return {
    today: dateKey(now),
    greeting: greetingFor(now),
    dateLine: dateLine(now),
    dailyQuote: quoteOfTheDay(now),
    me: { id: me.id, name: me.name, color: me.color },
    partner,
    totals: self.totals,
    streaks: self.streaks,
    week: self.week,
    heat: self.heat,
    heatWeeks: self.heatWeeks,
    habits: self.habits,
  };
}
